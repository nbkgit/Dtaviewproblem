USE [Komm6976_Intervet]
GO
/****** Object:  Table [dbo].[AuditTrail_Charge]    Script Date: 13.12.2024 23:14:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AuditTrail_Charge](
	[AudiTrailID] [varchar](50) NOT NULL,
	[Charge] [varchar](255) NOT NULL,
	[AenderungsGrund] [varchar](255) NOT NULL,
	[AngelegtAm] [datetime] NOT NULL,
	[AngelegtDurch] [varchar](50) NOT NULL,
 CONSTRAINT [PK_AuditTrail] PRIMARY KEY CLUSTERED 
(
	[AudiTrailID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AuditTrail_Detail]    Script Date: 13.12.2024 23:14:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AuditTrail_Detail](
	[AudiTrailID] [varchar](50) NULL,
	[Feldname] [varchar](255) NOT NULL,
	[AlterWert] [varchar](255) NULL,
	[NeuerWert] [nchar](255) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[AuditTrail_Visu]    Script Date: 13.12.2024 23:14:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AuditTrail_Visu](
	[Time] [datetime] NULL,
	[mSec] [int] NULL,
	[Status] [varchar](2) NULL,
	[M_No] [int] IDENTITY(1,1) NOT NULL,
	[Text] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Chargen]    Script Date: 13.12.2024 23:14:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Chargen](
	[Auftragsnummer] [varchar](255) NOT NULL,
	[ProduktNummer] [varchar](255) NOT NULL,
	[Produkt] [varchar](255) NOT NULL,
	[Chargennummer] [varchar](255) NOT NULL,
	[Kabine] [tinyint] NOT NULL,
	[Messposition] [varchar](255) NULL,
	[PZ1Auswerten] [bit] NOT NULL,
	[PZ2Auswerten] [bit] NOT NULL,
	[PZ3Auswerten] [bit] NOT NULL,
	[StartZeit] [datetime] NULL,
	[EndZeit] [datetime] NULL,
	[Produktionstyp] [varchar](50) NOT NULL,
	[AngelegtAm] [datetime] NOT NULL,
	[AngelegtDurch] [varchar](50) NOT NULL,
	[GeändertAm] [datetime] NOT NULL,
	[GeändertDurch] [varchar](50) NOT NULL,
	[Kurzauswertung] [varchar](255) NULL,
	[Kommentar] [varchar](255) NULL,
	[StartZeit_Vorbereitung] [datetime] NULL,
	[EndZeit_Vorbereitung] [datetime] NULL,
 CONSTRAINT [Chargen$PrimaryKey] PRIMARY KEY CLUSTERED 
(
	[Auftragsnummer] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Ereignisse]    Script Date: 13.12.2024 23:14:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Ereignisse](
	[Time] [datetime] NULL,
	[mSec] [int] NULL,
	[Status] [varchar](2) NULL,
	[M_No] [int] NULL,
	[Text] [varchar](1024) NULL,
	[Auto_ID] [bigint] IDENTITY(1,1) NOT NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Meldesystem]    Script Date: 13.12.2024 23:14:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Meldesystem](
	[Auto_ID] [bigint] IDENTITY(1,1) NOT NULL,
	[Time] [datetime] NULL,
	[mSec] [int] NULL,
	[Status] [varchar](2) NULL,
	[M_No] [int] NULL,
	[Text] [varchar](1024) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Meldesystem_Temp]    Script Date: 13.12.2024 23:14:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Meldesystem_Temp](
	[Auto_ID] [bigint] IDENTITY(1,1) NOT NULL,
	[Time] [datetime] NULL,
	[mSec] [int] NULL,
	[Status] [varchar](2) NULL,
	[M_No] [int] NULL,
	[Text] [varchar](1024) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[NullZaehlung]    Script Date: 13.12.2024 23:14:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[NullZaehlung](
	[DatZeit] [datetime] NULL,
	[PZ_0_5] [int] NULL,
	[PZ_5] [int] NULL,
	[SerialNumber] [nchar](255) NULL,
	[ModBusVersion] [smallint] NULL,
	[FirmwareVersion] [smallint] NULL,
	[Linie] [smallint] NULL,
	[Laser_Status] [smallint] NULL,
	[Flow_Status] [smallint] NULL,
	[Hardware_Status] [smallint] NULL,
	[Calibration_Date] [nchar](12) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PZ_E172]    Script Date: 13.12.2024 23:14:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PZ_E172](
	[Auto_ID] [bigint] IDENTITY(1,1) NOT NULL,
	[DatZeit] [datetime] NULL,
	[Counter_ID] [smallint] NULL,
	[TaktZaehler] [int] NULL,
	[PZ_0_5] [int] NULL,
	[PZ_0_5_SUM] [int] NULL,
	[PZ_0_5_High_Limit] [real] NULL,
	[PZ_5] [int] NULL,
	[PZ_5_SUM] [int] NULL,
	[PZ_5_High_Limit] [real] NULL,
	[PZ_Anz_Intervall] [smallint] NULL,
	[PZ_Status] [smallint] NULL,
 CONSTRAINT [PK_PZ_E172] PRIMARY KEY CLUSTERED 
(
	[Auto_ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[SQL_CheckTbl]    Script Date: 13.12.2024 23:14:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SQL_CheckTbl](
	[IDNr] [bigint] NOT NULL,
	[DatZeit] [datetime] NULL,
	[Text] [varchar](1024) NULL,
	[Schlepp_MinWert] [nchar](10) NULL,
	[Schlepp_MaxWert] [nchar](10) NULL,
	[Zustaendigkeit] [nchar](256) NULL,
	[DatZeitQuitt] [datetime] NULL,
	[Zustaendigkeit_komplett] [nchar](256) NULL,
	[Quittierbar] [int] NULL,
 CONSTRAINT [PK_SQL_CheckTbl] PRIMARY KEY CLUSTERED 
(
	[IDNr] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Chargen] ADD  DEFAULT ((1)) FOR [Kabine]
GO
ALTER TABLE [dbo].[Chargen] ADD  DEFAULT ((1)) FOR [PZ1Auswerten]
GO
ALTER TABLE [dbo].[Chargen] ADD  DEFAULT ((1)) FOR [PZ2Auswerten]
GO
ALTER TABLE [dbo].[Chargen] ADD  DEFAULT ((1)) FOR [PZ3Auswerten]
GO
ALTER TABLE [dbo].[Chargen] ADD  CONSTRAINT [DF_Chargen_Produktionstyp]  DEFAULT ('None') FOR [Produktionstyp]
GO
ALTER TABLE [dbo].[Ereignisse] ADD  CONSTRAINT [DF_Ereignisse_mSec]  DEFAULT ((0)) FOR [mSec]
GO
ALTER TABLE [dbo].[AuditTrail_Charge]  WITH CHECK ADD FOREIGN KEY([Charge])
REFERENCES [dbo].[Chargen] ([Auftragsnummer])
ON UPDATE CASCADE
GO
ALTER TABLE [dbo].[Chargen]  WITH CHECK ADD  CONSTRAINT [SSMA_CC$Chargen$AngelegtDurch$disallow_zero_length] CHECK  ((len([AngelegtDurch])>(0)))
GO
ALTER TABLE [dbo].[Chargen] CHECK CONSTRAINT [SSMA_CC$Chargen$AngelegtDurch$disallow_zero_length]
GO
ALTER TABLE [dbo].[Chargen]  WITH CHECK ADD  CONSTRAINT [SSMA_CC$Chargen$BatchNummer$disallow_zero_length] CHECK  ((len([Chargennummer])>(0)))
GO
ALTER TABLE [dbo].[Chargen] CHECK CONSTRAINT [SSMA_CC$Chargen$BatchNummer$disallow_zero_length]
GO
ALTER TABLE [dbo].[Chargen]  WITH CHECK ADD  CONSTRAINT [SSMA_CC$Chargen$Charge$disallow_zero_length] CHECK  ((len([Auftragsnummer])>(0)))
GO
ALTER TABLE [dbo].[Chargen] CHECK CONSTRAINT [SSMA_CC$Chargen$Charge$disallow_zero_length]
GO
ALTER TABLE [dbo].[Chargen]  WITH CHECK ADD  CONSTRAINT [SSMA_CC$Chargen$GeändertDurch$disallow_zero_length] CHECK  ((len([GeändertDurch])>(0)))
GO
ALTER TABLE [dbo].[Chargen] CHECK CONSTRAINT [SSMA_CC$Chargen$GeändertDurch$disallow_zero_length]
GO
ALTER TABLE [dbo].[Chargen]  WITH CHECK ADD  CONSTRAINT [SSMA_CC$Chargen$Messposition$disallow_zero_length] CHECK  ((len([Messposition])>(0)))
GO
ALTER TABLE [dbo].[Chargen] CHECK CONSTRAINT [SSMA_CC$Chargen$Messposition$disallow_zero_length]
GO
ALTER TABLE [dbo].[Chargen]  WITH CHECK ADD  CONSTRAINT [SSMA_CC$Chargen$Produkt$disallow_zero_length] CHECK  ((len([Produkt])>(0)))
GO
ALTER TABLE [dbo].[Chargen] CHECK CONSTRAINT [SSMA_CC$Chargen$Produkt$disallow_zero_length]
GO
ALTER TABLE [dbo].[Chargen]  WITH CHECK ADD  CONSTRAINT [SSMA_CC$Chargen$Produktionstyp$disallow_zero_length] CHECK  ((len([Produktionstyp])>(0)))
GO
ALTER TABLE [dbo].[Chargen] CHECK CONSTRAINT [SSMA_CC$Chargen$Produktionstyp$disallow_zero_length]
GO
ALTER TABLE [dbo].[Chargen]  WITH CHECK ADD  CONSTRAINT [SSMA_CC$Chargen$ProduktNummer$disallow_zero_length] CHECK  ((len([ProduktNummer])>(0)))
GO
ALTER TABLE [dbo].[Chargen] CHECK CONSTRAINT [SSMA_CC$Chargen$ProduktNummer$disallow_zero_length]
GO
