Imports System.Data.SqlClient

Public Class Frm_chrg_prot_detail

  'Markiert ob ein Feld ge�ndert wurde, wird bein Speicehrn und beim beneden kontrolliert
  Private Felder_ge�ndert_xpb As Boolean = False

  'bei der initilisiereungspahse, sollen keine changed ereignisse gefuertert werden
  Private initialisierung_xpb As Boolean = True

  'Aktueller Datensatz der Angezeigt bzw. gespeichert wird
  Private drCurrent As DataRow

  'Variablen f�r die Alten Werte, damit diese bei Bedarf im Audittrail gespeichert werden k��ne
  Private charge_alt_xps As String = String.Empty

  Private prodnummer_alt_xps As String = String.Empty
  Private prodbez_alt_xps As String = String.Empty
  Private batchnummer_alt_xps As String = String.Empty
  Private startzeit_alt_xps As String = String.Empty
  Private endzeit_alt_xps As String = String.Empty
  Private startzeit_Vorbereitung_alt_xps As String = String.Empty
  Private endzeit_Vorbereitung_alt_xps As String = String.Empty
  Private Kommentar_alt_xps As String = String.Empty
  Private kabinennummer_alt_xpi As Integer = 0
  Private pz1_alt_xpb As Boolean = True
  Private pz2_alt_xpb As Boolean = True

  'Private pz3_alt_xpb As Boolean = True
  Private Sub Frm_chrg_prot_detail_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    ' Die buttons vergr�ssern usw. werden nicht ben�tigt
    Me.ControlBox = False
    'Belege Zeitpunkte mit aktuellen Zeitwert
    ds_chartprotmdb_xbo.Tables("Chargen").PrimaryKey = New DataColumn() {ds_chartprotmdb_xbo.Tables("Chargen").Columns("Auftragsnummer")}
    If neue_charge_xpb = True Then
      Me.Tb_endzeit.Text = Now.ToString
      Me.Tb_startzeit.Text = Now.ToString
      Me.Tb_EndZeit_Vorbereitung.Text = Now.ToString
      Me.Tb_StartZeit_Vorbereitung.Text = Now.ToString
      'Me.Chb_pz1.Checked = True
      'Me.Chb_pz2.Checked = True
      '      Me.Chb_pz3.Checked = True
      GroupBox1.Visible = True
      Me.Cb_kabinennummer.SelectedIndex = 0
      Me.cmd_print.Enabled = False
      Me.cmd_speichern.Enabled = False
    Else
      drCurrent = ds_chartprotmdb_xbo.Tables("Chargen").Rows.Find(chargenname_xos)
      'dv.RowFilter = "Charge = '" & chargenname_xos & "'"
      Me.tb_charge.Text = drCurrent("Auftragsnummer").ToString
      charge_alt_xps = drCurrent("Auftragsnummer").ToString
      Me.Tb_produktnummer.Text = drCurrent("ProduktNummer").ToString
      prodnummer_alt_xps = drCurrent("ProduktNummer").ToString
      Me.Tb_produktbez.Text = drCurrent("Produkt").ToString
      prodbez_alt_xps = drCurrent("Produkt").ToString
      Me.tb_batchnummer.Text = drCurrent("Chargennummer").ToString
      batchnummer_alt_xps = drCurrent("Chargennummer").ToString

      Me.Tb_startzeit.Text = drCurrent("StartZeit").ToString
      startzeit_alt_xps = drCurrent("StartZeit").ToString
      Me.Tb_endzeit.Text = drCurrent("EndZeit").ToString
      endzeit_alt_xps = drCurrent("EndZeit").ToString

      Me.Tb_StartZeit_Vorbereitung.Text = drCurrent("StartZeit_Vorbereitung").ToString
      startzeit_Vorbereitung_alt_xps = drCurrent("StartZeit_Vorbereitung").ToString
      Me.Tb_EndZeit_Vorbereitung.Text = drCurrent("EndZeit_Vorbereitung").ToString
      endzeit_Vorbereitung_alt_xps = drCurrent("EndZeit_Vorbereitung").ToString
      Me.tb_kurzauswertung.Text = drCurrent("Kurzauswertung").ToString
      Me.Tb_kommentar.Text = drCurrent("Kommentar").ToString
      Kommentar_alt_xps = drCurrent("Kommentar").ToString
      Me.Cb_kabinennummer.SelectedIndex = CInt(drCurrent("Kabine")) - 1
      kabinennummer_alt_xpi = CInt(drCurrent("Kabine")) - 1
      Me.Tb_angelegtam.Text = drCurrent("AngelegtAm").ToString
      Me.Tb_angelegtDurch.Text = drCurrent("AngelegtDurch").ToString

      Me.Tb_geaendertam.Text = drCurrent("Ge�ndertAm").ToString
      Me.Tb_geaendertdurch.Text = drCurrent("Ge�ndertDurch").ToString
      GroupBox1.Visible = True
      If modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString() <> String.Empty Then
        If System.IO.Directory.Exists(modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString()) Then
          Me.Lb_Filelist.Items.Clear()
          Dim verzeichnis_xps As String = String.Empty
          If modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString().EndsWith("\") Then
            verzeichnis_xps = modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString()
          Else
            verzeichnis_xps = modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString() & "\"
          End If
          Dim pdfDatei_xps As String = FileSystem.Dir(verzeichnis_xps & drCurrent("Auftragsnummer").ToString & "___" & "*.pdf")

          If pdfDatei_xps <> String.Empty Then

            Do While pdfDatei_xps <> String.Empty
              If (Strings.Left(pdfDatei_xps, pdfDatei_xps.Length - 24)) = drCurrent("Auftragsnummer").ToString Then
                Me.Lb_Filelist.Items.Add(pdfDatei_xps)
              End If
              pdfDatei_xps = Dir()
            Loop


          End If
        End If
      End If
        Listview_aktualisieren_sob()
      End If
      'Initialisierung abgeschlossen
      initialisierung_xpb = False
  End Sub

#Region " Form Elemente wurden ge�ndert "

  Private Sub Tb_produktnummer_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tb_produktnummer.TextChanged
    If initialisierung_xpb = False Then
      If Me.cmd_speichern.Enabled = False Then
        Me.cmd_speichern.Enabled = True
      End If
      Felder_ge�ndert_xpb = True
    End If
  End Sub

  Private Sub Tb_produktbez_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tb_produktbez.TextChanged
    If initialisierung_xpb = False Then
      If Me.cmd_speichern.Enabled = False Then
        Me.cmd_speichern.Enabled = True
      End If
      Felder_ge�ndert_xpb = True
    End If
  End Sub

  Private Sub Cb_kabinnennummer_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_kabinennummer.SelectedIndexChanged
    If initialisierung_xpb = False Then
      If Me.cmd_speichern.Enabled = False Then
        Me.cmd_speichern.Enabled = True
      End If
      Felder_ge�ndert_xpb = True
    End If

  End Sub

  Private Sub Chb_pz1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    If initialisierung_xpb = False Then
      If Me.cmd_speichern.Enabled = False Then
        Me.cmd_speichern.Enabled = True
      End If
      Felder_ge�ndert_xpb = True
    End If
  End Sub

  Private Sub Chb_pz2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    If initialisierung_xpb = False Then
      If Me.cmd_speichern.Enabled = False Then
        Me.cmd_speichern.Enabled = True
      End If
      Felder_ge�ndert_xpb = True
    End If
  End Sub

  Private Sub Chb_pz3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    If initialisierung_xpb = False Then
      If Me.cmd_speichern.Enabled = False Then
        Me.cmd_speichern.Enabled = True
      End If
      Felder_ge�ndert_xpb = True
    End If
  End Sub

  Private Sub Tb_startzeit_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tb_startzeit.TextChanged
    If initialisierung_xpb = False Then
      If Me.cmd_speichern.Enabled = False Then
        Me.cmd_speichern.Enabled = True
      End If
      Felder_ge�ndert_xpb = True
    End If
  End Sub

  Private Sub Tb_endzeit_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tb_endzeit.TextChanged
    If initialisierung_xpb = False Then
      If Me.cmd_speichern.Enabled = False Then
        Me.cmd_speichern.Enabled = True
      End If
      Felder_ge�ndert_xpb = True
    End If
  End Sub

  Private Sub Tb_StartZeit_Vorbereitung_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tb_StartZeit_Vorbereitung.TextChanged
    If initialisierung_xpb = False Then
      If Me.cmd_speichern.Enabled = False Then
        Me.cmd_speichern.Enabled = True
      End If
      Felder_ge�ndert_xpb = True
    End If
  End Sub

  Private Sub Tb_EndZeit_Vorbereitung_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tb_EndZeit_Vorbereitung.TextChanged
    If initialisierung_xpb = False Then
      If Me.cmd_speichern.Enabled = False Then
        Me.cmd_speichern.Enabled = True
      End If
      Felder_ge�ndert_xpb = True
    End If
  End Sub

  Private Sub Tb_kommentar_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tb_kommentar.TextChanged
    If initialisierung_xpb = False Then
      If Me.cmd_speichern.Enabled = False Then
        Me.cmd_speichern.Enabled = True
      End If
      Felder_ge�ndert_xpb = True
    End If
  End Sub

  Private Sub Cb_prod_typ_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    If initialisierung_xpb = False Then
      If Me.cmd_speichern.Enabled = False Then
        Me.cmd_speichern.Enabled = True
      End If
      Felder_ge�ndert_xpb = True
    End If
  End Sub

  Private Sub Tb_batchnummer_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tb_batchnummer.TextChanged
    If initialisierung_xpb = False Then
      If Me.cmd_speichern.Enabled = False Then
        Me.cmd_speichern.Enabled = True
      End If
      Felder_ge�ndert_xpb = True
    End If
  End Sub

  Private Sub Tb_charge_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tb_charge.TextChanged
    If initialisierung_xpb = False Then
      If Me.cmd_speichern.Enabled = False Then
        Me.cmd_speichern.Enabled = True
      End If
      Felder_ge�ndert_xpb = True
    End If
  End Sub

#End Region

  Private Sub Cmd_neu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_neu.Click
    ' L�sche alle Eingaben
    'Deklariere Variablen
    Dim ctl As Control
    If (MessageBox.Show("Sind Sie sicher, dass Sie " & vbNewLine &
       "einen neuen Datensatz erzeugen m�chten?", "Neuen Chargenprotokoll erstellen", MessageBoxButtons.YesNo,
      MessageBoxIcon.Question)) = Windows.Forms.DialogResult.Yes Then
      For Each ctl In Me.Controls
        If TypeOf ctl Is TextBox Then
          CType(ctl, TextBox).Clear()
        End If
        If TypeOf ctl Is CheckBox Then
          CType(ctl, CheckBox).Checked = False
        End If
        If TypeOf ctl Is ListView Then
          CType(ctl, ListView).Clear()
        End If
        If TypeOf ctl Is ComboBox Then
          CType(ctl, ComboBox).ResetText()
        End If
      Next
      Me.cmd_print.Enabled = False
      Me.cmd_speichern.Enabled = False
      Me.Tb_endzeit.Text = Now.ToString
      Me.Tb_startzeit.Text = Now.ToString
      Me.Tb_EndZeit_Vorbereitung.Text = Now.ToString
      Me.Tb_StartZeit_Vorbereitung.Text = Now.ToString
      'Me.Chb_pz1.Checked = True
      'Me.Chb_pz2.Checked = True
      '      Me.Chb_pz3.Checked = True
      Me.Cb_kabinennummer.SelectedIndex = -1
      Me.Cb_kabinennummer.SelectedIndex = 0
      GroupBox1.Visible = True
      Me.Refresh()
      Felder_ge�ndert_xpb = False
      neue_charge_xpb = True
    End If
  End Sub

  Private Sub Cmd_close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_close.Click
    'Schliesse Fenster und kehre zur �bersicht zur�ck
    If neue_charge_xpb = True Then
      Dim mdichild As New startfenster_nycomed_frm With {
        .MdiParent = Me.MdiParent
      }
      mdichild.Show()
      Me.Close()
    Else
      If (Felder_ge�ndert_xpb = True) And ((batchnummer_alt_xps <> Me.tb_batchnummer.Text) _
        Or (prodbez_alt_xps <> Me.Tb_produktbez.Text) _
        Or (prodnummer_alt_xps <> Me.Tb_produktnummer.Text) _
        Or (charge_alt_xps <> Me.tb_charge.Text) _
        Or (startzeit_alt_xps <> Me.Tb_startzeit.Text) _
        Or (endzeit_alt_xps <> Me.Tb_endzeit.Text) _
        Or (startzeit_Vorbereitung_alt_xps <> Me.Tb_StartZeit_Vorbereitung.Text) _
        Or (endzeit_Vorbereitung_alt_xps <> Me.Tb_EndZeit_Vorbereitung.Text) _
        Or (Kommentar_alt_xps <> Me.Tb_kommentar.Text) _
        Or (kabinennummer_alt_xpi <> Me.Cb_kabinennummer.SelectedIndex)) Then
        If (MessageBox.Show("Daten wurden ge�ndert. Wollen Sie das Fenster trotzdem schlie�en?" _
    , "Chargendetail schliessen", MessageBoxButtons.YesNo,
    MessageBoxIcon.Question)) = Windows.Forms.DialogResult.Yes Then
          Dim mdichild As New startfenster_nycomed_frm With {
            .MdiParent = Me.MdiParent
          }
          mdichild.Show()
          Me.Close()
        End If
      Else
        Dim mdichild As New startfenster_nycomed_frm With {
          .MdiParent = Me.MdiParent
        }
        mdichild.Show()
        Me.Close()
      End If
    End If
  End Sub

  Private Sub Cmd_speichern_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_speichern.Click
    'Speichere Charge mit allen Anforderungen
    Dim Ergebnis_xpi As Integer
    Dim drtest As DataRow
    Dim draudittrail As DataRow
    Dim Guid As String = System.Guid.NewGuid().ToString()
    If (Felder_ge�ndert_xpb = False) Or
      ((neue_charge_xpb = False) And (batchnummer_alt_xps = Me.tb_batchnummer.Text) _
      And (prodbez_alt_xps = Me.Tb_produktbez.Text) _
      And (prodnummer_alt_xps = Me.Tb_produktnummer.Text) _
      And (charge_alt_xps = Me.tb_charge.Text) _
      And (startzeit_alt_xps = Me.Tb_startzeit.Text) _
      And (endzeit_Vorbereitung_alt_xps = Me.Tb_EndZeit_Vorbereitung.Text) _
      And (startzeit_Vorbereitung_alt_xps = Me.Tb_StartZeit_Vorbereitung.Text) _
      And (endzeit_alt_xps = Me.Tb_endzeit.Text) _
      And (Kommentar_alt_xps = Me.Tb_kommentar.Text) _
      And (kabinennummer_alt_xpi = Me.Cb_kabinennummer.SelectedIndex)) Then
      MsgBox("Es wurden keine Details ver�ndert", MsgBoxStyle.Critical)
      Exit Sub
    End If
    'Nur authentifizierte User d�rfen speichern
    If Mdimain.User_Ckeck() > 0 Then
      '�berpr�fe G�ltigkeit aller werte
      If Me.tb_charge.Text = String.Empty Then
        MsgBox("Sie haben keine Auftrags-Nr. festgelegt.", MsgBoxStyle.Critical)
        Me.tb_charge.Focus()
        Exit Sub
      End If
      If IsValidFileNameOrPath(Me.tb_charge.Text) = False Then
        MsgBox("Die Auftrags-Nr. enth�lt ung�ltige Zeichen.", MsgBoxStyle.Critical)
        Me.tb_charge.Focus()
        Exit Sub
      End If

      If Me.Tb_produktnummer.Text = String.Empty Then
          MsgBox("Sie haben keine Material-Nr. festgelegt.", MsgBoxStyle.Critical)
          Me.Tb_produktnummer.Focus()
          Exit Sub
        End If
        If Me.Tb_produktbez.Text = String.Empty Then
          MsgBox("Sie haben keine Produktbezeichnung festgelegt.", MsgBoxStyle.Critical)
          Me.Tb_produktbez.Focus()
          Exit Sub
        End If
        If Me.tb_batchnummer.Text = String.Empty Then
          MsgBox("Sie haben keine Chargen-Nr. festgelegt.", MsgBoxStyle.Critical)
          Me.tb_batchnummer.Focus()
          Exit Sub
        End If
        If Me.Cb_kabinennummer.SelectedIndex = -1 Then
          MsgBox("Sie haben keine Abf�lllinie festgelegt.", MsgBoxStyle.Critical)
          Me.Cb_kabinennummer.Focus()
          Exit Sub
        End If
        'If Me.Chb_pz1.Checked = False And Me.Chb_pz2.Checked = False Then
        '  MsgBox("Sie m�ssen mindestens einen Patikelz�hler ausgew�hlt haben.", MsgBoxStyle.Critical)
        '  Me.Chb_pz1.Focus()
        '  Exit Sub
        'End If

        If Me.Tb_startzeit.Text = String.Empty Then
          If Me.Tb_startzeit.Text = String.Empty Then
          Else
            MsgBox(" Das Datumsformat der Startzeit muss von folgender Form sein tt.mm.jjjj hh:mm:ss," & vbCrLf & "Bitte �berpr�fen Sie die Angaben")
            Me.Tb_startzeit.Focus()
            Exit Sub
          End If
        Else
          If IsDate(Me.Tb_startzeit.Text) = False Then
            MsgBox(" Das Datumsformat der Startzeit muss von folgender Form sein tt.mm.jjjj hh:mm:ss," & vbCrLf & "Bitte �berpr�fen Sie die Angaben")
            Me.Tb_startzeit.Focus()
            Exit Sub
          End If
          If IsDate(Me.Tb_endzeit.Text) = False Then
            MsgBox(" Das Datumsformat der Endezeit muss von folgender Form sein tt.mm.jjjj hh:mm:ss," & vbCrLf & "Bitte �berpr�fen Sie die Angaben")
            Me.Tb_endzeit.Focus()
            Exit Sub
          End If
          Ergebnis_xpi = DateTime.Compare(System.DateTime.Parse(Me.Tb_startzeit.Text), System.DateTime.Parse(Me.Tb_endzeit.Text))
          Select Case Ergebnis_xpi
            Case -1 'Kleiner alles Ok
              'Datum ist ok
            Case 0 'Identsuch
              MsgBox("Das Start-und Endzeitpunkt unterscheiden sich nicht, bitte �berpr�fen Sie Ihre Angaben!")
              Me.Tb_startzeit.Focus()
              Exit Sub
            Case Else '1 gr�sser
              MsgBox("Der Endzeitpunkt liegt vor dem Startzeitpunkt, bitte �berpr�fen Sie Ihre Angaben!")
              Me.Tb_startzeit.Focus()
              Exit Sub
          End Select
          'NEU Version 1.0.0.1: Abfrage Dauer Charge hinzugef�gt
          'Pedro 27.04.2006
          If DateDiff("d", System.DateTime.Parse(Me.Tb_startzeit.Text), System.DateTime.Parse(Me.Tb_endzeit.Text)) > 8 Then
            If MsgBox("Das Start-und Endzeitpunkt liegen �ber eine Woche auseinader, die Auswertung kann sehr zeitaufwendioig sein!" & vbCrLf & "Wollen Sie die Daten korrigieren?", MsgBoxStyle.YesNo, "Anwenderhinweis") = Windows.Forms.DialogResult.Yes Then
              Me.Tb_endzeit.Focus()
              Exit Sub
            End If
          End If
        End If
            If DateDiff("s", System.DateTime.Parse(Me.Tb_startzeit.Text), System.DateTime.Parse(Me.Tb_endzeit.Text)) < Zeitintervall_Charge_xoi Then
                MsgBox("Der Endzeitpunkt Produktion muss mindestens " & Zeitintervall_Charge_xoi.ToString & " Sekunden nach dem Startzeitpunkt Produktion liegen!", MsgBoxStyle.Exclamation, "Anwenderhinweis")
                Return
            End If
            If Me.Tb_StartZeit_Vorbereitung.Text = String.Empty Then

                    If Me.Tb_StartZeit_Vorbereitung.Text = String.Empty Then
                        MsgBox("Die Starteit Vorbereitung daef nicht leer sein," & vbCrLf & "Bitte �berpr�fen Sie die Angaben")
                        Me.Tb_StartZeit_Vorbereitung.Focus()
                        Exit Sub
                    End If
                    If Me.Tb_EndZeit_Vorbereitung.Text = String.Empty Then
                    Else
                        MsgBox(" Das Datumsformat der Endzeit Vorbereitung muss von folgender Form sein tt.mm.jjjj hh:mm:ss," & vbCrLf & "Bitte �berpr�fen Sie die Angaben")
                        Me.Tb_StartZeit_Vorbereitung.Focus()
                        Exit Sub
                    End If
                Else
                    If IsDate(Me.Tb_StartZeit_Vorbereitung.Text) = False Then
                        MsgBox(" Das Datumsformat der Startzeit Vorbereitung muss von folgender Form sein tt.mm.jjjj hh:mm:ss," & vbCrLf & "Bitte �berpr�fen Sie die Angaben")
                        Me.Tb_StartZeit_Vorbereitung.Focus()
                        Exit Sub
                    End If
                    If IsDate(Me.Tb_EndZeit_Vorbereitung.Text) = False Then
                        MsgBox(" Das Datumsformat der Endezeit Vorbereitung muss von folgender Form sein tt.mm.jjjj hh:mm:ss," & vbCrLf & "Bitte �berpr�fen Sie die Angaben")
                        Me.Tb_EndZeit_Vorbereitung.Focus()
                        Exit Sub
                    End If
                    Ergebnis_xpi = DateTime.Compare(System.DateTime.Parse(Me.Tb_StartZeit_Vorbereitung.Text), System.DateTime.Parse(Me.Tb_EndZeit_Vorbereitung.Text))
                    Select Case Ergebnis_xpi
                        Case -1 'Kleiner alles Ok
              'Datum ist ok
                        Case 0 'Identsuch
                            MsgBox("Das Start-und Endzeitpunkt Vorbereitungunterscheiden sich nicht, bitte �berpr�fen Sie Ihre Angaben!")
                            Me.Tb_StartZeit_Vorbereitung.Focus()
                            Exit Sub
                        Case Else '1 gr�sser
                            MsgBox("Der Endzeitpunkt Vorbereitung liegt vor dem Startzeitpunkt Vorbereitung, bitte �berpr�fen Sie Ihre Angaben!")
                            Me.Tb_StartZeit_Vorbereitung.Focus()
                            Exit Sub
                    End Select
                If DateDiff("d", System.DateTime.Parse(Me.Tb_StartZeit_Vorbereitung.Text), System.DateTime.Parse(Me.Tb_EndZeit_Vorbereitung.Text)) > 8 Then
                    If MsgBox("Das Start-und Endzeitpunkt Vorbereitung liegen �ber eine Woche auseinader, die Auswertung kann sehr zeitaufwendioig sein!" & vbCrLf & "Wollen Sie die Daten korrigieren?", MsgBoxStyle.YesNo, "Anwenderhinweis") = Windows.Forms.DialogResult.Yes Then
                        Me.Tb_EndZeit_Vorbereitung.Focus()
                        Exit Sub
                    End If
                End If
                If DateDiff("s", System.DateTime.Parse(Me.Tb_StartZeit_Vorbereitung.Text), System.DateTime.Parse(Me.Tb_EndZeit_Vorbereitung.Text)) < Zeitintervall_Charge_xoi Then
                    MsgBox("Start-und Endzeitpunkt Vorbereitung liegen unter der eingestellten Grenze von " & Zeitintervall_Charge_xoi.ToString & " Sekunden, das kann dazu f�hren, dass keine Messwerte im Report stehen!", MsgBoxStyle.Exclamation, "Anwenderhinweis")
                    Me.Tb_EndZeit_Vorbereitung.Focus()
                    Return
                End If
            End If
                If DateTime.Compare(System.DateTime.Parse(Me.Tb_EndZeit_Vorbereitung.Text), System.DateTime.Parse(Me.Tb_startzeit.Text)) > 0 Then
                MsgBox("Endzeitpunkt Vorbereitung muss vor der Startzeit Produktion liegen", MsgBoxStyle.Critical, "Anwenderhinweis")
                Me.Tb_startzeit.Focus()
                    Exit Sub
                End If
                If neue_charge_xpb = True Or charge_alt_xps <> Me.tb_charge.Text Then
                    drtest = ds_chartprotmdb_xbo.Tables("Chargen").Rows.Find(Me.tb_charge.Text)
                    If drtest Is Nothing Then
                    Else
                        MsgBox("Die Auftrags-Nr. existiert bereits in der Datenbank.", MsgBoxStyle.Critical)
                        Me.tb_charge.Focus()
                        Exit Sub
                    End If
                End If
                If Felder_ge�ndert_xpb = True And neue_charge_xpb = False Then
                    Dim nDlg As Dlg_aenderungsgrund
                    nDlg = New Dlg_aenderungsgrund
                    If nDlg.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
                        'Begr�ndung f�r Auittrail wurde festgelegt
                    Else
                        MsgBox("Ohne Begr�ndung, d�fen keine �nderungen gespeichert werden!")
                        Exit Sub
                    End If
                End If
                'Werte Zuweisen
                If neue_charge_xpb = True Then
                    drCurrent = ds_chartprotmdb_xbo.Tables("Chargen").NewRow()
                Else
                    drCurrent.BeginEdit()
                End If
                drCurrent("Auftragsnummer") = Me.tb_charge.Text
                drCurrent("ProduktNummer") = Me.Tb_produktnummer.Text
                drCurrent("Produkt") = Me.Tb_produktbez.Text
                drCurrent("Chargennummer") = Me.tb_batchnummer.Text
                drCurrent("StartZeit") = Me.Tb_startzeit.Text
                drCurrent("EndZeit") = Me.Tb_endzeit.Text
                drCurrent("StartZeit_Vorbereitung") = Me.Tb_StartZeit_Vorbereitung.Text
                drCurrent("EndZeit_Vorbereitung") = Me.Tb_EndZeit_Vorbereitung.Text
                drCurrent("Kurzauswertung") = String.Empty
                drCurrent("Kommentar") = Me.Tb_kommentar.Text
                drCurrent("Kabine") = Me.Cb_kabinennummer.SelectedIndex + 1
                drCurrent("Ge�ndertAm") = Now

                'PEDRO
                'Nur damit's bei neuen Datens�tzen nicht knallt, da diese felder
                drCurrent("PZ1Auswerten") = True
                drCurrent("PZ2Auswerten") = True
                drCurrent("PZ3Auswerten") = True
                drCurrent("Produktionstyp") = "None"

                drCurrent("Ge�ndertDurch") = Username_xos
                If neue_charge_xpb = True Then
                    drCurrent("AngelegtAm") = Now
                    drCurrent("AngelegtDurch") = Username_xos
                    Try
                        ds_chartprotmdb_xbo.Tables("Chargen").Rows.Add(drCurrent)
                    Catch ex As Exception
                        MsgBox("Die Auftrags-Nr. existiert bereits in der Datenbank.", MsgBoxStyle.Critical)
                        Me.tb_charge.Focus()
                        Exit Sub
                    End Try
                Else
                    drCurrent.EndEdit()
                End If

                'per SQL-Anweisung Datenstz �ndern:
                'Neuen DS per SqlCommandBuilder hinzuf�gen
                'Erstelle automatisch Databank insert und update befehle f�r die Tabelle Chargen
                Dim objCommandBuilder As New SqlCommandBuilder(Da_chartprot_xbo)
                Try
                Da_chartprot_xbo.Update(ds_chartprotmdb_xbo, "Chargen")
                If neue_charge_xpb = False Then
                    Dim da_charge_aktuell As New SqlDataAdapter
                    Dim Dt_charge_aktuell As New DataTable
                    Dim repeat_changes_xpb As Boolean = False
                    da_charge_aktuell = New SqlDataAdapter("SELECT * FROM [Chargen] WHERE [Auftragsnummer ] LIKE '" & drCurrent("Auftragsnummer").ToString & "';", cn_chargeprot_xbo) '[AuditTrail],[AuditTrail_Detail],,[Benutzer_AuditTrail],[LastDownload]
                    da_charge_aktuell.Fill(Dt_charge_aktuell)
                    For n_xpi As Integer = 0 To Dt_charge_aktuell.Columns.Count - 1
                        If drCurrent(n_xpi).ToString <> Dt_charge_aktuell.Rows(0).Item(n_xpi).ToString Then
                            drCurrent(n_xpi) = Dt_charge_aktuell.Rows(0).Item(n_xpi)
                            repeat_changes_xpb = True
                        End If
                    Next
                    If repeat_changes_xpb = True Then
                        drCurrent.BeginEdit()
                        drCurrent("Auftragsnummer") = Me.tb_charge.Text
                        drCurrent("ProduktNummer") = Me.Tb_produktnummer.Text
                        drCurrent("Produkt") = Me.Tb_produktbez.Text
                        drCurrent("Chargennummer") = Me.tb_batchnummer.Text
                        drCurrent("StartZeit") = Me.Tb_startzeit.Text
                        drCurrent("EndZeit") = Me.Tb_endzeit.Text
                        drCurrent("StartZeit_Vorbereitung") = Me.Tb_StartZeit_Vorbereitung.Text
                        drCurrent("EndZeit_Vorbereitung") = Me.Tb_EndZeit_Vorbereitung.Text
                        drCurrent("Kurzauswertung") = String.Empty
                        drCurrent("Kommentar") = Me.Tb_kommentar.Text
                        drCurrent("Kabine") = Me.Cb_kabinennummer.SelectedIndex + 1
                        drCurrent("Ge�ndertAm") = Now

                        'PEDRO
                        'Nur damit's bei neuen Datens�tzen nicht knallt, da diese felder
                        drCurrent("PZ1Auswerten") = True
                        drCurrent("PZ2Auswerten") = True
                        drCurrent("PZ3Auswerten") = True
                        drCurrent("Produktionstyp") = "None"

                        drCurrent("Ge�ndertDurch") = Username_xos
                        drCurrent.EndEdit()
                        Dim objCommandBuilder1 As New SqlCommandBuilder(Da_chartprot_xbo)
                        Try
                            Da_chartprot_xbo.Update(ds_chartprotmdb_xbo, "Chargen")
                            Dt_charge_aktuell.Clear()
                            da_charge_aktuell.Fill(Dt_charge_aktuell)
                            For n_xpi As Integer = 0 To Dt_charge_aktuell.Columns.Count - 1
                                If drCurrent(n_xpi).ToString <> Dt_charge_aktuell.Rows(0).Item(n_xpi).ToString Then
                                    drCurrent(n_xpi) = Dt_charge_aktuell.Rows(0).Item(n_xpi)
                                    MsgBox("Der Datensatz konnte nicht in der Datenbank gespeichert werden." & vbCrLf & "Bitte schliessen Sie das Chargenprotokolldetailfenster und rufen sie es anschliessend neu auf.")
                                    Exit Sub
                                End If
                            Next
                        Catch ex As Exception
                            MsgBox("Der Datensatz ist bereits von einem anderen User ge�ndert worden." & vbCrLf & "Bitte schliessen Sie das Chargenprotokolldetailfenster und rufen sie es anschliessend neu auf.")
                            'Aktualiesiere Datenadapter, damit der grid wieder stimmig ist
                            Me.Cursor = System.Windows.Forms.Cursors.WaitCursor
                            ds_chartprotmdb_xbo.Tables("Chargen").Clear()
                            Da_chartprot_xbo = New SqlDataAdapter("SELECT * FROM [Chargen];", cn_chargeprot_xbo) '[AuditTrail],[AuditTrail_Detail],,[Benutzer_AuditTrail],[LastDownload]
                            Da_chartprot_xbo.Fill(ds_chartprotmdb_xbo, "Chargen")

                            Me.Cursor = System.Windows.Forms.Cursors.Default
                            Exit Sub
                        End Try
                    End If
                End If
            Catch ex As Exception
                    MsgBox("Der Datensatz ist bereits von einem anderen User ge�ndert worden." & vbCrLf & "Bitte schliessen Sie das Chargenprotokolldetailfenster und rufen sie es anschliessend neu auf.")
                    'Aktualiesiere Datenadapter, damit der grid wieder stimmig ist
                    Me.Cursor = System.Windows.Forms.Cursors.WaitCursor
                    ds_chartprotmdb_xbo.Tables("Chargen").Clear()
                    Da_chartprot_xbo = New SqlDataAdapter("SELECT * FROM [Chargen];", cn_chargeprot_xbo) '[AuditTrail],[AuditTrail_Detail],,[Benutzer_AuditTrail],[LastDownload]
                    Da_chartprot_xbo.Fill(ds_chartprotmdb_xbo, "Chargen")
                    Me.Cursor = System.Windows.Forms.Cursors.Default
                    Exit Sub
                End Try

                If (neue_charge_xpb = False) Then
                    'audittrail anlegen
                    draudittrail = ds_chartprotmdb_xbo.Tables("AuditTrail").NewRow()
                    draudittrail("AudiTrailID") = Guid
                    draudittrail("Charge") = Me.tb_charge.Text
                    draudittrail("AenderungsGrund") = Begruendung_xos
                    Dim datum_xpd As Date = Now
                    datum_xpd = datum_xpd.AddMilliseconds(-(datum_xpd.Millisecond))
                    draudittrail("AngelegtAm") = datum_xpd
                    draudittrail("AngelegtDurch") = Username_xos
                    ds_chartprotmdb_xbo.Tables("AuditTrail").Rows.Add(draudittrail)
                    'Autitraildetails f�llen
                    If charge_alt_xps <> Me.tb_charge.Text Then
                        draudittrail = ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").NewRow()
                        draudittrail("AudiTrailID") = Guid
                        draudittrail("Feldname") = "Auftrags-Nr."
                        draudittrail("AlterWert") = charge_alt_xps
                        draudittrail("NeuerWert") = Me.tb_charge.Text
                        ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Rows.Add(draudittrail)
                    End If
                    If prodnummer_alt_xps <> Me.Tb_produktnummer.Text Then
                        draudittrail = ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").NewRow()
                        draudittrail("AudiTrailID") = Guid
                        draudittrail("Feldname") = "Material-Nr."
                        draudittrail("AlterWert") = prodnummer_alt_xps
                        draudittrail("NeuerWert") = Me.Tb_produktnummer.Text
                        ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Rows.Add(draudittrail)
                    End If
                    If prodbez_alt_xps <> Me.Tb_produktbez.Text Then
                        draudittrail = ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").NewRow()
                        draudittrail("AudiTrailID") = Guid
                        draudittrail("Feldname") = "Produktbezeichnung"
                        draudittrail("AlterWert") = prodbez_alt_xps
                        draudittrail("NeuerWert") = Me.Tb_produktbez.Text
                        ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Rows.Add(draudittrail)
                    End If
                    If batchnummer_alt_xps <> Me.tb_batchnummer.Text Then
                        draudittrail = ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").NewRow()
                        draudittrail("AudiTrailID") = Guid
                        draudittrail("Feldname") = "Chargen-Nr."
                        draudittrail("AlterWert") = batchnummer_alt_xps
                        draudittrail("NeuerWert") = Me.tb_batchnummer.Text
                        ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Rows.Add(draudittrail)
                    End If
                    If startzeit_alt_xps <> Me.Tb_startzeit.Text Then
                        draudittrail = ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").NewRow()
                        draudittrail("AudiTrailID") = Guid
                        draudittrail("Feldname") = "StartZeit"
                        If Len(startzeit_alt_xps) = 0 Then
                            draudittrail("AlterWert") = "<-- Datum leer -->"
                        Else
                            If CDate(startzeit_alt_xps).Year = 1971 Then
                                draudittrail("AlterWert") = "<-- Datum leer -->"
                            Else
                                draudittrail("AlterWert") = startzeit_alt_xps
                            End If
                        End If
                        draudittrail("NeuerWert") = Me.Tb_startzeit.Text
                        ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Rows.Add(draudittrail)
                    End If
                    If endzeit_alt_xps <> Me.Tb_endzeit.Text Then
                        draudittrail = ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").NewRow()
                        draudittrail("AudiTrailID") = Guid
                        draudittrail("Feldname") = "EndZeit"
                        If Len(endzeit_alt_xps) = 0 Then
                            draudittrail("AlterWert") = "<-- Datum leer -->"
                        Else
                            If CDate(endzeit_alt_xps).Year = 1971 Then
                                draudittrail("AlterWert") = "<-- Datum leer -->"
                            Else
                                draudittrail("AlterWert") = endzeit_alt_xps
                            End If
                        End If
                        draudittrail("NeuerWert") = Me.Tb_endzeit.Text
                        ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Rows.Add(draudittrail)
                    End If
                    If startzeit_Vorbereitung_alt_xps <> Me.Tb_StartZeit_Vorbereitung.Text Then
                        draudittrail = ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").NewRow()
                        draudittrail("AudiTrailID") = Guid
                        draudittrail("Feldname") = "StartZeit Setup"
                        If Len(startzeit_Vorbereitung_alt_xps) = 0 Then
                            draudittrail("AlterWert") = "<-- Datum leer -->"
                        Else
                            If CDate(startzeit_Vorbereitung_alt_xps).Year = 1971 Then
                                draudittrail("AlterWert") = "<-- Datum leer -->"
                            Else
                                draudittrail("AlterWert") = startzeit_Vorbereitung_alt_xps
                            End If
                        End If
                        draudittrail("NeuerWert") = Me.Tb_StartZeit_Vorbereitung.Text
                        ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Rows.Add(draudittrail)
                    End If
                    If endzeit_Vorbereitung_alt_xps <> Me.Tb_EndZeit_Vorbereitung.Text Then
                        draudittrail = ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").NewRow()
                        draudittrail("AudiTrailID") = Guid
                        draudittrail("Feldname") = "EndZeit Setup"
                        If Len(endzeit_Vorbereitung_alt_xps) = 0 Then
                            draudittrail("AlterWert") = "<-- Datum leer -->"
                        Else
                            If CDate(endzeit_Vorbereitung_alt_xps).Year = 1971 Then
                                draudittrail("AlterWert") = "<-- Datum leer -->"
                            Else
                                draudittrail("AlterWert") = endzeit_Vorbereitung_alt_xps
                            End If
                        End If
                        draudittrail("NeuerWert") = Me.Tb_EndZeit_Vorbereitung.Text
                        ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Rows.Add(draudittrail)
                    End If
                    If Kommentar_alt_xps <> Me.Tb_kommentar.Text Then
                        If Len(Kommentar_alt_xps) = 0 Then
                            Kommentar_alt_xps = "<-- kein Kommentar -->"
                        End If
                        draudittrail = ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").NewRow()
                        draudittrail("AudiTrailID") = Guid
                        draudittrail("Feldname") = "Kommentar"
                        draudittrail("AlterWert") = Kommentar_alt_xps
                        draudittrail("NeuerWert") = Me.Tb_kommentar.Text
                        ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Rows.Add(draudittrail)
                    End If
                    If kabinennummer_alt_xpi <> Me.Cb_kabinennummer.SelectedIndex Then
                        draudittrail = ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").NewRow()
                        draudittrail("AudiTrailID") = Guid
                        draudittrail("Feldname") = "Linie"
                        Select Case kabinennummer_alt_xpi + 1
                            Case 1
                                draudittrail("AlterWert") = "E172"

                            Case Else
                        End Select
                        draudittrail("NeuerWert") = "E72"
                        ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Rows.Add(draudittrail)
                    End If
                    'Speichere Autitrail und detail
                    'Erstelle automatisch Databank insertbefehle f�r die Tabelle Audittrail
                    Dim objCommandBuilder1 As New SqlCommandBuilder(Da_audittrail_xbo)
                    Try
                        Da_audittrail_xbo.Update(ds_chartprotmdb_xbo, "AuditTrail")
                    Catch ex As Exception
                        MsgBox("Ein Fehler ist beim schreiben auf die Datenbank aufgetreten." & vbCrLf & "Die Applikation wird beendet und es werden keine �nderungen �bernommen." & vbCrLf & "Bitte vermerken Sie das Problem im Kommentarfeld, wenn sie dei Charge erneut speichern.!", MsgBoxStyle.Critical)
                        Fehlerupdate_xob = True
                        Application.Exit()
                    End Try
                    'Erstelle automatisch Databank insert Befehle f�r die Tabelle Auditraildetail
                    Dim objCommandBuilder2 As New SqlCommandBuilder(Da_audittrail_detail_xbo)
                    Try
                        Da_audittrail_detail_xbo.Update(ds_chartprotmdb_xbo, "AuditTrail_Detail")
                    Catch ex As Exception
                        MsgBox("Ein Fehler ist beim schreiben auf die Datenbank aufgetreten." & vbCrLf & "Die Applikation wird beendet und es werden keine �nderungen �bernommen." & vbCrLf & "Bitte vermerken Sie das Problem im Kommentarfeld, wenn sie dei Charge erneut speichern.!", MsgBoxStyle.Critical)
                        Fehlerupdate_xob = True
                        Application.Exit()
                    End Try
                    'Erneuere Datenwquelen Audittrail udn detail
                    Me.Cursor = System.Windows.Forms.Cursors.WaitCursor
                    ds_chartprotmdb_xbo.Tables("AuditTrail").Clear()
                    Da_audittrail_xbo = New SqlDataAdapter("SELECT * FROM [AuditTrail_Charge];", cn_chargeprot_xbo) ',[AuditTrail_Detail],,[Benutzer_AuditTrail],[LastDownload]
                    Da_audittrail_xbo.Fill(ds_chartprotmdb_xbo, "AuditTrail")
                    ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Clear()
                    Da_audittrail_detail_xbo = New SqlDataAdapter("SELECT * FROM [AuditTrail_Detail];", cn_chargeprot_xbo) ',,,[Benutzer_AuditTrail],[LastDownload]
                    Da_audittrail_detail_xbo.Fill(ds_chartprotmdb_xbo, "AuditTrail_Detail")
                    Me.Cursor = System.Windows.Forms.Cursors.Default
                Else
                    Me.cmd_print.Enabled = True
                    Me.cmd_speichern.Enabled = True
                End If
                'Datensatz und alle audit gespeichert, setze alt Variablen f�r �nderungen
                charge_alt_xps = Me.tb_charge.Text
                prodnummer_alt_xps = Me.Tb_produktnummer.Text
                prodbez_alt_xps = Me.Tb_produktbez.Text
                batchnummer_alt_xps = Me.tb_batchnummer.Text
                startzeit_alt_xps = Me.Tb_startzeit.Text
                endzeit_alt_xps = Me.Tb_endzeit.Text
                startzeit_Vorbereitung_alt_xps = Me.Tb_StartZeit_Vorbereitung.Text
                endzeit_Vorbereitung_alt_xps = Me.Tb_EndZeit_Vorbereitung.Text
                Kommentar_alt_xps = Me.Tb_kommentar.Text
                kabinennummer_alt_xpi = Me.Cb_kabinennummer.SelectedIndex
                'pz1_alt_xpb = Me.Chb_pz1.Checked
                'pz2_alt_xpb = Me.Chb_pz2.Checked
                'pz3_alt_xpb = Me.Chb_pz3.Checked
                Me.tb_kurzauswertung.Text = String.Empty
                Listview_aktualisieren_sob()
                neue_charge_xpb = False
            End If
  End Sub
  Function IsValidFileNameOrPath(ByVal name As String) As Boolean
    ' Determines if the name is Nothing.
    If name Is Nothing Then
      Return False
    End If

    ' Determines if there are bad characters in the name.
    For Each badChar As Char In System.IO.Path.GetInvalidFileNameChars()
      If InStr(name, badChar) > 0 Then
        Return False
      End If
    Next

    ' The name passes basic validation.
    Return True
  End Function

  Private Sub Cmd_print_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_print.Click
    'Reports
    If neue_charge_xpb = False Then
      chargenname_xos = Me.tb_charge.Text
      Liniennummer_xoi = Me.Cb_kabinennummer.SelectedIndex + 1
      aufruf_form_xos = "Chargedetail"
      Me.Hide()
      Dim mdichild As New Frm_Print_Combit With {
        .MdiParent = Me.MdiParent
      }
      mdichild.Show()
    End If
  End Sub

  Private Sub Cmd_beenden_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_beenden.Click
    'Schliesse Applikation
    Application.Exit()
  End Sub

  Private Sub Listview_aktualisieren_sob()
    'Audittrial listview wird gef�llt
    Try
      Dim rows As DataRow() = ds_chartprotmdb_xbo.Tables("AuditTrail").Select("Charge = '" & charge_alt_xps & "'", "AngelegtAm DESC")
      Dim rowsaudittraildetail As DataRow()
      '      Liestview(l�schen)
      ListView1.Clear()
      'Spalten festlegen
      With ListView1
        .View = View.Details
        .Columns.Add("�nderungsgrund", 300, HorizontalAlignment.Left)
        .Columns.Add("Angelegt an", 150, HorizontalAlignment.Left)
        .Columns.Add("Angelegt durch", 130, HorizontalAlignment.Left)
        .Columns.Add("Feldname", 175, HorizontalAlignment.Left)
        .Columns.Add("alter Wert", 175, HorizontalAlignment.Left)
        .Columns.Add("neuer Wert", 175, HorizontalAlignment.Left)
      End With
      'Spalten f�llen
      For Each row As DataRow In rows
        rowsaudittraildetail = ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Select("AudiTrailID = '" & row("AudiTrailID").ToString() & "'")
        For Each row2 As DataRow In rowsaudittraildetail
          Dim item As ListViewItem = New ListViewItem(row("Aenderungsgrund").ToString())
          item.SubItems.Add(row("AngelegtAm").ToString())
          item.SubItems.Add(row("AngelegtDurch").ToString())
          item.SubItems.Add(row2("Feldname").ToString())
          item.SubItems.Add(row2("AlterWert").ToString())
          item.SubItems.Add(row2("NeuerWert").ToString())
          ListView1.Items.Add(item)
        Next
      Next
    Catch e As Exception
      'MessageBox.Show(e.Message)
      'Wenn keine Eintr�ge vorhanden sind, zeige nichts an
    End Try
  End Sub

  Private Sub Lb_Filelist_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Lb_Filelist.SelectedIndexChanged
    Try

      Dim verzeichnis_xps As String = String.Empty
      If modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString().EndsWith("\") Then
        verzeichnis_xps = modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString()
      Else
        verzeichnis_xps = modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString() & "\"
      End If
      Dim p As New System.Diagnostics.Process
      Dim s As New System.Diagnostics.ProcessStartInfo(verzeichnis_xps & Lb_Filelist.SelectedItems(0).ToString) With {
        .UseShellExecute = True,
        .WindowStyle = ProcessWindowStyle.Normal
      }
      p.StartInfo = s
      p.Start()

    Catch ex As Exception

    End Try

  End Sub
End Class