﻿'
Imports combit.Reporting



Partial Public Class Frm_Print_Combit
  Inherits Form

  Public Sub New()
    InitializeComponent()

    ' here the selected data source will be created
    AttachDataSource()
  End Sub

  Private Sub AttachDataSource()
    Try
      ' set a valid data source to List & Label
      ' hint: You can also use LL.SetDataBinding(); instead of the following two properties
      ' hint: Here you have to specify a valid data source for the List & Label component. Details can be found in the .NET Help
      LL.DataSource = Ds_Rohdat_xo
      LL.DataMember = ""
    Catch exc As ListLabelException
      'MessageBox.Show(exc.Message, exc.Source, MessageBoxButtons.OK, MessageBoxIcon.[Error])
    End Try
  End Sub

  Private Sub BtnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    Try
      ' we need to 'free' the displayed preview file from preview control and detach the preview control from the List & Label component
      previewControl.FileName = String.Empty
      LL.PreviewControl = Nothing

      LL.AutoShowPrintOptions = True
      LL.AutoDestination = LlPrintMode.Export
      LL.Print()
    Catch exc As ListLabelException
      MessageBox.Show(exc.Message, exc.Source, MessageBoxButtons.OK, MessageBoxIcon.[Error])
    End Try
  End Sub

  Private Sub BtnDesign_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDesign.Click
        LL = New ListLabel With {
      .LicensingInfo = ""
    }
        LL.Core.LlSetOption(231, 1)
    Try
      If cboDruckUmfang.SelectedIndex < 0 Then
        MsgBox("Wählen Sie bitte einen gültigen Protokolltyp!", MsgBoxStyle.Critical, "UNGÜLTIGER PROTOKOLLTYP")
        Exit Sub
      End If
      Select Case cboDruckUmfang.SelectedIndex
        Case 0
                    'Chargenprotokoll 2015 (Verwendete Tabellen: Charge, Rohdaten, Auswertung; Kurzauswertung ausführen)

                    If ReadRohdaten_foi(chargenname_xos, CByte(cboDruckUmfang.SelectedIndex), 0) = -1 Then
                        'Report nur aufrufen, wenn Rohdaten erfolgreich gelesen wurden
                        AttachDataSource()
                    Else
                        Exit Sub
          End If
        Case 1
                    'Mit Rohdaten 2015 (Verwendete Tabellen: Charge, Rohdaten, Auswertung; Kurzauswertung ausführen)
                    If ReadRohdaten_foi(chargenname_xos, CByte(cboDruckUmfang.SelectedIndex), 0) = -1 Then
                        'Report nur aufrufen, wenn Rohdaten erfolgreich gelesen wurden
                        AttachDataSource()
                    Else
                        Exit Sub
          End If
        Case 2
                    If ReadRohdaten_foi(chargenname_xos, CByte(cboDruckUmfang.SelectedIndex), 0) = -1 Then
                        'Report nur aufrufen, wenn Rohdaten erfolgreich gelesen wurden
                        AttachDataSource()
                    Else
                        Exit Sub
          End If
        Case 3
                    'Mit Rohdaten 2015 (Verwendete Tabellen: Charge, Rohdaten, Auswertung; Kurzauswertung ausführen)
                    If ReadRohdaten_foi(chargenname_xos, CByte(cboDruckUmfang.SelectedIndex), 0) = -1 Then
                        'Report nur aufrufen, wenn Rohdaten erfolgreich gelesen wurden
                        AttachDataSource()
                    Else
                        Exit Sub
          End If
        Case 4
                    'Audit trail (Verwendete Tabellen: Charge, Audittrail; Kurzauswertung nicht ausführen)
                    If ReadRohdaten_foi(chargenname_xos, CByte(cboDruckUmfang.SelectedIndex), 0) = -1 Then
                        'Report nur aufrufen, wenn Rohdaten erfolgreich gelesen wurden
                        AttachDataSource()
                    Else
                        Exit Sub
          End If
      End Select
      LL.AutoProjectType = LlProject.List Or LlProject.FileAlsoNew
      LL.Variables.Add(“@Versionsnummer", "V. " & Application.ProductVersion.ToString)
      LL.Design()
    Catch exc As ListLabelException
      MessageBox.Show(exc.Message, exc.Source, MessageBoxButtons.OK, MessageBoxIcon.[Error])
    End Try
  End Sub

  Private Sub BtnExportTo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    Try
      ' show FileOpenDialog to select the List & Label project file
      Using openFileDlg As New OpenFileDialog()
        openFileDlg.CheckFileExists = True
        openFileDlg.CheckPathExists = True
        openFileDlg.Filter = "Listenprojekt (*.lst)|*.lst"
        If openFileDlg.ShowDialog() = DialogResult.OK Then
          ' prepare the export parameters
          Dim projectFileName As String = openFileDlg.FileName
          Dim exportFileName As String = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "export.pdf")

          Dim exportTarget As LlExportTarget = LlExportTarget.Pdf
          ' here you can specify other formats e.g. Xlsx
          Dim exportConfiguration As New ExportConfiguration(exportTarget, exportFileName, projectFileName) With {
            .ShowResult = True
          }
          ' without any interaction set this property to false
          ' start exporting
          LL.Export(exportConfiguration)
        End If
      End Using
    Catch exc As ListLabelException
      MessageBox.Show(exc.Message, exc.Source, MessageBoxButtons.OK, MessageBoxIcon.[Error])
    End Try
  End Sub

  Private Sub BtnPrintToPreviewControl_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrintToPreviewControl.Click
    Dim reportdatei_xps As String = String.Empty
        LL = New ListLabel With {
      .LicensingInfo = ""
    }
        Try
      If cboDruckUmfang.SelectedIndex < 0 Then
        MsgBox("Wählen Sie bitte einen gültigen Protokolltyp!", MsgBoxStyle.Critical, "UNGÜLTIGER PROTOKOLLTYP")
        Exit Sub
      End If
      Select Case cboDruckUmfang.SelectedIndex
        Case 0
                    'Chargenprotokoll 2015 (Verwendete Tabellen: Charge, Rohdaten, Auswertung; Kurzauswertung ausführen)

                    If ReadRohdaten_foi(chargenname_xos, CByte(cboDruckUmfang.SelectedIndex), 0) = -1 Then
                        'Report nur aufrufen, wenn Rohdaten erfolgreich gelesen wurden
                        AttachDataSource()
                        reportdatei_xps = "\chargenprotokoll.lst"
                    Else
                        Cursor = Cursors.Default
            Exit Sub
          End If
        Case 1
                    'Mit Rohdaten 2015 (Verwendete Tabellen: Charge, Rohdaten, Auswertung; Kurzauswertung ausführen)
                    If ReadRohdaten_foi(chargenname_xos, CByte(cboDruckUmfang.SelectedIndex), 0) = -1 Then
                        'Report nur aufrufen, wenn Rohdaten erfolgreich gelesen wurden
                        AttachDataSource()
                        reportdatei_xps = "\chargenprotokoll.lst"
                    Else
                        Cursor = Cursors.Default
            Exit Sub
          End If
        Case 2
                    'Audit trail (Verwendete Tabellen: Charge, Audittrail; Kurzauswertung nicht ausführen)
                    If ReadRohdaten_foi(chargenname_xos, CByte(cboDruckUmfang.SelectedIndex), 0) = -1 Then
                        'Report nur aufrufen, wenn Rohdaten erfolgreich gelesen wurden
                        AttachDataSource()
                        reportdatei_xps = "\Audittrail.lst"
                    Else
                        Cursor = Cursors.Default
            Exit Sub
          End If
        Case 3
                    'Ereignis (Verwendete Tabellen: Charge, Audittrail; Kurzauswertung nicht ausführen)
                    If ReadRohdaten_foi(chargenname_xos, CByte(cboDruckUmfang.SelectedIndex), 0) = -1 Then
                        'Report nur aufrufen, wenn Rohdaten erfolgreich gelesen wurden
                        AttachDataSource()
                        reportdatei_xps = "\Ereignis.lst"
                    Else
                        Cursor = Cursors.Default
            Exit Sub
          End If

      End Select
      ' we need to assign the preview control to the List & Label component to print directly into the preview control.
      If LL.PreviewControl Is Nothing Then
        LL.PreviewControl = previewControl
      End If

      LL.AutoShowSelectFile = False
      LL.AutoShowPrintOptions = False
      LL.Core.LlSetOptionString(LlOptionString.Exports_Allowed, "PDF;XPS;TXT;EMF;PNG;JPG;JPEG")
      LL.AutoDestination = LlPrintMode.PreviewControl
      LL.Variables.Add(“@Versionsnummer", " V. " & Application.ProductVersion.ToString)
      Cursor = Cursors.WaitCursor
      Application.DoEvents()
      Try
        'Einschalten  des Waitcursors erst verfügbar mit neuer dll
        previewControl.SetOption(CType(26, IntPtr), CType(4, IntPtr))
      Catch ex As Exception

      End Try

      LL.Print(LlProject.List, Application.StartupPath & reportdatei_xps)
      Try
        'Ausschalten  des Waitcursors
        previewControl.SetOption(CType(26, IntPtr), CType(2, IntPtr))
      Catch ex As Exception

      End Try
    Catch exc As ListLabelException
      MessageBox.Show(exc.Message, exc.Source, MessageBoxButtons.OK, MessageBoxIcon.[Error])
    End Try
    Cursor = Cursors.Default
  End Sub

  Private Sub Cmd_close_Click(sender As Object, e As EventArgs) Handles cmd_close.Click
    Dim mdichild As Form
    If aufruf_form_xos = "Startfenster" Then
      mdichild = New startfenster_nycomed_frm
    ElseIf aufruf_form_xos = "Chargedetail" Then
      mdichild = New Frm_chrg_prot_detail
    Else
      mdichild = New startfenster_nycomed_frm
    End If
    mdichild.MdiParent = Me.MdiParent
    mdichild.Show()
    Me.Close()
  End Sub

  Private Sub Frm_Print_Combit_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    Me.ControlBox = False
    Me.Height = Mdimain.Size.Height
    Me.Width = Mdimain.Size.Width
    'cboDruckUmfang.SelectedItem = 0
    cboDruckUmfang.SelectedIndex = 0
    'cboDruckUmfang.Text = "Chargenprotokoll"
    Me.Cursor = Cursors.Default
    Me.MaximizedBounds = SystemInformation.WorkingArea
  End Sub

    Public Function Erzeuge_pdfs_fob(auftrgasnummer_xps As String, Dateiname_xps As String _
            , chargenbez_xps As String, auto_oder_manuell_xpi As Integer) As Boolean
        Dim reportdatei_xps As String = String.Empty
        LL = New ListLabel With {
          .LicensingInfo = ""
        }
        If ReadRohdaten_foi(auftrgasnummer_xps, 0, auto_oder_manuell_xpi) = -1 Then
            'Report nur aufrufen, wenn Rohdaten erfolgreich gelesen wurden
            AttachDataSource()
            reportdatei_xps = "\chargenprotokoll.lst"
        Else
            Return False
            Exit Function
        End If
        Dim Prjekttyp_xpi As Integer = 0
        LL.Variables.Add(“@Versionsnummer", "V. " & Application.ProductVersion.ToString)
        Dim lst_xps As String = Application.StartupPath & reportdatei_xps
        ' Ergebnis anzeigen
        Dim exportConfiguration As New ExportConfiguration(LlExportTarget.Pdf, Dateiname_xps, Application.StartupPath & reportdatei_xps) With {
          .ShowResult = False
        }
        'Dim exportConfiguration2 As New ExportConfiguration(LlExportTarget.Preview, pfad_xps & ".ll", Application.StartupPath & "\Gesamtprotokoll.lst") With {
        '  .ShowResult = True
        '}
        exportConfiguration.ExportOptions.Add(LlExportOption.ExportQuiet, "0")
        exportConfiguration.ExportOptions.Add(LlExportOption.PdfAuthor, "PMS/CAS")
        exportConfiguration.ExportOptions.Add(LlExportOption.PdfEncryptionEnableChanging, "0")
        exportConfiguration.ExportOptions.Add(LlExportOption.PdfEncryptionEnablePrinting, "1")
        exportConfiguration.ExportOptions.Add(LlExportOption.PdfEncryptionEnableCopying, "0")
        exportConfiguration.ExportOptions.Add(LlExportOption.PdfEncryptionEncryptFile, "1")
        'exportConfiguration.ExportOptions.Add(LlExportOption.PdfEncryptionLevel, "1")
        exportConfiguration.ExportOptions.Add(LlExportOption.PdfKeywords, "Intervet Chargenprotokoll ")
        exportConfiguration.ExportOptions.Add(LlExportOption.PdfTitle, "Intervet Chargenprotokoll")
        exportConfiguration.ExportOptions.Add(LlExportOption.PdfSubject, "Chargen " & chargenbez_xps & " " & auftrgasnummer_xps)
        exportConfiguration.ExportOptions.Add(LlExportOption.PdfOwnerPassword, "Intervet")
        'exportConfiguration.ExportOptions.Add(LlExportOption.PdfUserPassword, ds_projectmdb_xbo.Tables("Projekt").Rows(0).Item("Proj_Txt").ToString)
        Try
            ' Export starten
            LL.Export(exportConfiguration)
        Catch ex As Exception
            Return False
            Exit Function
        End Try
        Me.Cursor = Cursors.Default
        'LL.Export()
        Return True
        LL.ExportOptions.Clear()
    End Function

    Private Sub Printpdf_Click(sender As Object, e As EventArgs) Handles Printpdf.Click
    If modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString() <> String.Empty Then
      If System.IO.Directory.Exists(modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString()) Then
        Dim datum As Date = Now
        Dim verzeichnis_xps As String = String.Empty
        Dim DatZeit_xps As String = String.Empty
        DatZeit_xps = "_" & Format(datum, "yyyy") & "_"
        DatZeit_xps &= Format(datum, "MM") & "_"
        DatZeit_xps &= Format(datum, "dd")

        DatZeit_xps &= "_" & Format(datum, "HH_mm_ss")
        If modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString().EndsWith("\") Then
          verzeichnis_xps = modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString()
        Else
          verzeichnis_xps = modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString() & "\"
        End If
                Erzeuge_pdfs_fob(chargenname_xos, verzeichnis_xps & chargenname_xos & DatZeit_xps & ".pdf", chargennummer_xos, 0)
                MsgBox("Die Datei " & chargenname_xos & DatZeit_xps & ".pdf wurde erfolgreich erstellt!", MsgBoxStyle.Information, "Anwenderhinweis")
      End If
    End If
  End Sub

End Class