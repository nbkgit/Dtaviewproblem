﻿Public Class Dlg_passwort

  Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
    If Me.Tb_passowrd.Text = "euro-gard-2020" Then
      Me.DialogResult = System.Windows.Forms.DialogResult.OK
    Else
      Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    End If
    Me.Close()
  End Sub

  Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click

    Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Close()
  End Sub

  Private Sub Dlg_loginwebsublist_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
    Tb_passowrd.Text = ""
    Me.Tb_passowrd.Select()
  End Sub

End Class