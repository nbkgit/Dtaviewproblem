Option Explicit On
Option Strict On

Imports System.Data.SqlClient

Module modul_globalvar

  'Dataset der konfigration.xml
  Public ds_konfiguration As New DataSet

  'ChargenprotokollVerzeichnis	modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("chargprotpath")
  'DatenbankquellVerzeichnis		modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("quelldbpath")
  'DatenbankzielVerzeichnis			modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("zieldbpath")
  Public sqlinit2_xos As String = ";Mode='Share Deny None';"

  Public sqlserver1_xos As String = "Data Source="

  'Name der SQL-DB in konfiguration.xml verlegt
  Public sqlserver2_xos As String = ";Initial Catalog="

  'DB-Login zusammenbauen, damit's nicht direkt ausgelesen werde kannIntervet_E172
  Public MeldeName_xos As String = ""

  Public MeldePw_xos As String = ""
  Public sqlserver3_xos As String = ";Integrated Security = SSPI;" '";User Id=" & MeldeName_xos & ";Password=" & MeldePw_xos & ";"

  'DatenbankVariablen f�r Chargenprotokollierungsdatenbank
  Public Linienbeschreibung_xos(5) As String
    Public anonymous_xpi As Integer = 0
    Public Zeitintervall_Charge_xoi As Integer
    Public AppVerz_xos As String = Application.StartupPath
  Public d_xod As Date
  Public Stichtag2015_xod As Date
  Public Gruppenliste_xos As String()
  Public vollstaendigerName_xos As String = String.Empty
  Public Programmstart_xob As Boolean = False
  Public Liniennummer_xoi As Integer = 0

#Region " Datenbankobjekte "

  Public cn_chargeprot_xbo As New SqlConnection
  Public Da_chartprot_xbo As New SqlDataAdapter
  Public Da_benutzer_xbo As New SqlDataAdapter
  Public Da_audittrail_xbo As New SqlDataAdapter
  Public Da_audittrail_detail_xbo As New SqlDataAdapter
  Public Da_VisAM_Seg_1_xbo As New SqlDataAdapter
  Public Da_VisAM_Seg_2_xbo As New SqlDataAdapter
  Public ds_chartprotmdb_xbo As New DataSet
  Public Ds_Rohdat_xo As DataSet

#End Region

  Public Sperrlog_pfad_xps As String = String.Empty
  Public Timer_gesteuert_xob As Boolean = False
  Public Fehlerupdate_xob As Boolean = False
  Public aufruf_form_xos As String = String.Empty

#Region " User Login "

  Public Rueckgabewert_userlogin_xoi As Integer = -1
  Public Username_xos As String = String.Empty

#End Region

#Region " User Login "

  Public neuer_Benutzer_xpb As Boolean = True
  Public Benutzernamename_xos As String = String.Empty

#End Region

#Region " Begr�ndung dlg "

  Public Begruendung_xos As String = String.Empty

#End Region

#Region " Chrg protokolldetail "

  Public neue_charge_xpb As Boolean = True
  Public chargenname_xos As String = String.Empty
  Public chargennummer_xos As String = String.Empty

#End Region

  Public Function FileExists(ByVal FileFullPath As String) As Boolean
    '�berrp�ft ob die Datei vorhanden ist
    If Trim(FileFullPath) = "" Then Return False

    Dim f As New IO.FileInfo(FileFullPath)
    Return f.Exists

  End Function

  Public Function DatetoSqlserverString(ByVal Datum_xpd As DateTime) As String
    Dim DatZeit_xps As String = String.Empty
    '20070911 00:00:00'
    DatZeit_xps = Format(Datum_xpd, "yyyy")
    DatZeit_xps = DatZeit_xps & Format(Datum_xpd, "MM")
    DatZeit_xps = DatZeit_xps & Format(Datum_xpd, "dd")
    DatZeit_xps = DatZeit_xps & " " & Format(Datum_xpd, "HH:mm:ss")
    DatZeit_xps = "'" & DatZeit_xps & "'"
    DatetoSqlserverString = DatZeit_xps
  End Function

End Module