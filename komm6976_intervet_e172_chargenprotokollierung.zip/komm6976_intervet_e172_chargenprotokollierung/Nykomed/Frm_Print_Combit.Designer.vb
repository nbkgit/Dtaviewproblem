﻿Partial Class Frm_Print_Combit
  ''' <summary>
  ''' Required designer variable.
  ''' </summary>
  Private components As System.ComponentModel.IContainer = Nothing

  ''' <summary>
  ''' Clean up any resources being used.
  ''' </summary>
  ''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
  Protected Overrides Sub Dispose(disposing As Boolean)
    If disposing AndAlso (components IsNot Nothing) Then
      components.Dispose()
    End If
    MyBase.Dispose(disposing)
  End Sub

#Region "Windows Form Designer generated code"

  ''' <summary>
  ''' Required method for Designer support - do not modify
  ''' the contents of this method with the code editor.
  ''' </summary>
  Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.LL = New combit.Reporting.ListLabel(Me.components)
        Me.previewControl = New combit.Reporting.ListLabelPreviewControl(Me.components)
        Me.btnDesign = New System.Windows.Forms.Button()
        Me.btnPrintToPreviewControl = New System.Windows.Forms.Button()
        Me.cboDruckUmfang = New System.Windows.Forms.ComboBox()
        Me.cmd_close = New System.Windows.Forms.Button()
        Me.LblDruckUmfang = New System.Windows.Forms.Label()
        Me.Printpdf = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'LL
        '
        Me.LL.AutoDestination = combit.Reporting.LlPrintMode.PreviewControl
        Me.LL.AutoPrinterSettingsStream = Nothing
        Me.LL.AutoProjectStream = Nothing
        Me.LL.DataBindingMode = combit.Reporting.DataBindingMode.DelayLoad
        Me.LL.DrilldownAvailable = True
        Me.LL.EMFResolution = 100
        Me.LL.FileRepository = Nothing
        Me.LL.GenericMaximumRecordCount = -1
        Me.LL.LockNextChar = 8288
        Me.LL.MaxRTFVersion = 65280
        Me.LL.PhantomSpace = 8203
        Me.LL.PreviewControl = Nothing
        Me.LL.Unit = combit.Reporting.LlUnits.Millimeter_1_100
        Me.LL.UseHardwareCopiesForLabels = False
        Me.LL.UseTableSchemaForDesignMode = False
        '
        'previewControl
        '
        Me.previewControl.AllowRbuttonUsage = True
        Me.previewControl.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.previewControl.BackColor = System.Drawing.SystemColors.Control
        Me.previewControl.CurrentPage = 0
        Me.previewControl.ForceReadOnly = False
        Me.previewControl.Location = New System.Drawing.Point(12, 55)
        Me.previewControl.Name = "previewControl"
        Me.previewControl.Size = New System.Drawing.Size(992, 674)
        Me.previewControl.SlideshowMode = False
        Me.previewControl.TabIndex = 0
        Me.previewControl.Text = "previewControl"
        Me.previewControl.ToolbarButtons.Exit = combit.Reporting.LlButtonState.Invisible
        Me.previewControl.ToolbarButtons.GotoFirst = combit.Reporting.LlButtonState.[Default]
        Me.previewControl.ToolbarButtons.GotoLast = combit.Reporting.LlButtonState.[Default]
        Me.previewControl.ToolbarButtons.GotoNext = combit.Reporting.LlButtonState.[Default]
        Me.previewControl.ToolbarButtons.GotoPrev = combit.Reporting.LlButtonState.[Default]
        Me.previewControl.ToolbarButtons.MouseModeMove = combit.Reporting.LlButtonState.[Default]
        Me.previewControl.ToolbarButtons.MouseModeZoom = combit.Reporting.LlButtonState.[Default]
        Me.previewControl.ToolbarButtons.NextFile = combit.Reporting.LlButtonState.[Default]
        Me.previewControl.ToolbarButtons.PageRange = combit.Reporting.LlButtonState.[Default]
        Me.previewControl.ToolbarButtons.PreviousFile = combit.Reporting.LlButtonState.[Default]
        Me.previewControl.ToolbarButtons.PrintAllPages = combit.Reporting.LlButtonState.Enabled
        Me.previewControl.ToolbarButtons.PrintCurrentPage = combit.Reporting.LlButtonState.Enabled
        Me.previewControl.ToolbarButtons.PrintToFax = combit.Reporting.LlButtonState.Enabled
        Me.previewControl.ToolbarButtons.SaveAs = combit.Reporting.LlButtonState.Enabled
        Me.previewControl.ToolbarButtons.SearchNext = combit.Reporting.LlButtonState.[Default]
        Me.previewControl.ToolbarButtons.SearchOptions = combit.Reporting.LlButtonState.[Default]
        Me.previewControl.ToolbarButtons.SearchStart = combit.Reporting.LlButtonState.[Default]
        Me.previewControl.ToolbarButtons.SearchText = combit.Reporting.LlButtonState.[Default]
        Me.previewControl.ToolbarButtons.SendTo = combit.Reporting.LlButtonState.[Default]
        Me.previewControl.ToolbarButtons.SlideshowMode = combit.Reporting.LlButtonState.[Default]
        Me.previewControl.ToolbarButtons.ZoomCombo = combit.Reporting.LlButtonState.[Default]
        Me.previewControl.ToolbarButtons.ZoomReset = combit.Reporting.LlButtonState.[Default]
        Me.previewControl.ToolbarButtons.ZoomRevert = combit.Reporting.LlButtonState.[Default]
        Me.previewControl.ToolbarButtons.ZoomTimes2 = combit.Reporting.LlButtonState.[Default]
        '
        'btnDesign
        '
        Me.btnDesign.Location = New System.Drawing.Point(897, 13)
        Me.btnDesign.Name = "btnDesign"
        Me.btnDesign.Size = New System.Drawing.Size(107, 34)
        Me.btnDesign.TabIndex = 1
        Me.btnDesign.Text = "&Designer"
        Me.btnDesign.UseVisualStyleBackColor = True
        Me.btnDesign.Visible = False
        '
        'btnPrintToPreviewControl
        '
        Me.btnPrintToPreviewControl.Location = New System.Drawing.Point(325, 11)
        Me.btnPrintToPreviewControl.Name = "btnPrintToPreviewControl"
        Me.btnPrintToPreviewControl.Size = New System.Drawing.Size(142, 34)
        Me.btnPrintToPreviewControl.TabIndex = 3
        Me.btnPrintToPreviewControl.Text = "&Protokoll anzeigen"
        Me.btnPrintToPreviewControl.UseVisualStyleBackColor = True
        '
        'cboDruckUmfang
        '
        Me.cboDruckUmfang.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.cboDruckUmfang.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboDruckUmfang.FormattingEnabled = True
        Me.cboDruckUmfang.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.cboDruckUmfang.Items.AddRange(New Object() {"Chargenprotokoll", "Mit Rohdaten", "Audittrail", "Ereignis"})
        Me.cboDruckUmfang.Location = New System.Drawing.Point(71, 17)
        Me.cboDruckUmfang.Name = "cboDruckUmfang"
        Me.cboDruckUmfang.Size = New System.Drawing.Size(227, 21)
        Me.cboDruckUmfang.TabIndex = 8
        '
        'cmd_close
        '
        Me.cmd_close.Location = New System.Drawing.Point(635, 13)
        Me.cmd_close.Name = "cmd_close"
        Me.cmd_close.Size = New System.Drawing.Size(143, 33)
        Me.cmd_close.TabIndex = 7
        Me.cmd_close.Text = "&Schliessen"
        Me.cmd_close.UseVisualStyleBackColor = True
        '
        'LblDruckUmfang
        '
        Me.LblDruckUmfang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblDruckUmfang.Location = New System.Drawing.Point(11, 7)
        Me.LblDruckUmfang.Name = "LblDruckUmfang"
        Me.LblDruckUmfang.Size = New System.Drawing.Size(297, 39)
        Me.LblDruckUmfang.TabIndex = 9
        Me.LblDruckUmfang.Text = "Report-Typ:"
        Me.LblDruckUmfang.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Printpdf
        '
        Me.Printpdf.Location = New System.Drawing.Point(473, 13)
        Me.Printpdf.Name = "Printpdf"
        Me.Printpdf.Size = New System.Drawing.Size(156, 34)
        Me.Printpdf.TabIndex = 10
        Me.Printpdf.Text = "Protokoll als Pdf &exportieren"
        Me.Printpdf.UseVisualStyleBackColor = True
        '
        'Frm_Print_Combit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1016, 741)
        Me.Controls.Add(Me.Printpdf)
        Me.Controls.Add(Me.cboDruckUmfang)
        Me.Controls.Add(Me.cmd_close)
        Me.Controls.Add(Me.LblDruckUmfang)
        Me.Controls.Add(Me.btnPrintToPreviewControl)
        Me.Controls.Add(Me.btnDesign)
        Me.Controls.Add(Me.previewControl)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Frm_Print_Combit"
        Me.Text = "Protokoll drucken"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private LL As combit.Reporting.ListLabel
    Private previewControl As combit.Reporting.ListLabelPreviewControl
    Friend WithEvents btnDesign As System.Windows.Forms.Button
  Friend WithEvents btnPrintToPreviewControl As System.Windows.Forms.Button
  Friend WithEvents cboDruckUmfang As ComboBox
  Friend WithEvents cmd_close As Button
  Friend WithEvents LblDruckUmfang As Label
  Friend WithEvents Printpdf As Button
End Class