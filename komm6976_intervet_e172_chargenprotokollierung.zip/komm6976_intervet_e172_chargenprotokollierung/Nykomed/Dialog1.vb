Imports System.Windows.Forms

Public Class Dlg_aenderungsgrund

  Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click

    If tb_grund.TextLength > 254 Then
      MsgBox("Die Begr�ndung ist zu lang")
      tb_grund.Focus()
      Exit Sub
    End If
    If tb_grund.Text = String.Empty Then
      MsgBox("Sie haben keine Begr�ndung festegelegt!")
      tb_grund.Focus()
      'Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
      Exit Sub
    End If
    Begruendung_xos = tb_grund.Text
    Me.DialogResult = System.Windows.Forms.DialogResult.OK
    Me.Close()
  End Sub

  Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
    Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Close()
  End Sub

  Private Sub Dlg_aenderungsgrung_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    tb_grund.Focus()
  End Sub
End Class
