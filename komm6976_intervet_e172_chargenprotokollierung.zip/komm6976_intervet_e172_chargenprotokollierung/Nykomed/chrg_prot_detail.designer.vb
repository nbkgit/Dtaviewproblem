<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_chrg_prot_detail
  Inherits System.Windows.Forms.Form

  'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing AndAlso components IsNot Nothing Then
      components.Dispose()
    End If
    MyBase.Dispose(disposing)
  End Sub

  'Wird vom Windows Form-Designer benötigt.
  Private components As System.ComponentModel.IContainer

  'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
  'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
  'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
    Me.Lbl_charge = New System.Windows.Forms.Label()
    Me.tb_charge = New System.Windows.Forms.TextBox()
    Me.lbl_produktnr = New System.Windows.Forms.Label()
    Me.Tb_produktnummer = New System.Windows.Forms.TextBox()
    Me.lbl_produktbez = New System.Windows.Forms.Label()
    Me.Tb_produktbez = New System.Windows.Forms.TextBox()
    Me.Lbl_kabine = New System.Windows.Forms.Label()
    Me.Cb_kabinennummer = New System.Windows.Forms.ComboBox()
    Me.lbl_startzeit = New System.Windows.Forms.Label()
    Me.Tb_startzeit = New System.Windows.Forms.TextBox()
    Me.Lbl_strtbsp = New System.Windows.Forms.Label()
    Me.Lbl_endzeit = New System.Windows.Forms.Label()
    Me.Tb_endzeit = New System.Windows.Forms.TextBox()
    Me.Llb_endzeitbsp = New System.Windows.Forms.Label()
    Me.Lbl_kommentar = New System.Windows.Forms.Label()
    Me.Tb_kommentar = New System.Windows.Forms.TextBox()
    Me.cmd_neu = New System.Windows.Forms.Button()
    Me.cmd_speichern = New System.Windows.Forms.Button()
    Me.cmd_print = New System.Windows.Forms.Button()
    Me.cmd_close = New System.Windows.Forms.Button()
    Me.cmd_beenden = New System.Windows.Forms.Button()
    Me.lbl_batchnr = New System.Windows.Forms.Label()
    Me.tb_batchnummer = New System.Windows.Forms.TextBox()
    Me.Lbl_kurzauswertung = New System.Windows.Forms.Label()
    Me.tb_kurzauswertung = New System.Windows.Forms.TextBox()
    Me.ListView1 = New System.Windows.Forms.ListView()
    Me.lbl_audittrial = New System.Windows.Forms.Label()
    Me.GroupBox1 = New System.Windows.Forms.GroupBox()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.Tb_EndZeit_Vorbereitung = New System.Windows.Forms.TextBox()
    Me.Label2 = New System.Windows.Forms.Label()
    Me.Label3 = New System.Windows.Forms.Label()
    Me.Tb_StartZeit_Vorbereitung = New System.Windows.Forms.TextBox()
    Me.Label4 = New System.Windows.Forms.Label()
    Me.GroupBox2 = New System.Windows.Forms.GroupBox()
    Me.Lb_Filelist = New System.Windows.Forms.ListBox()
    Me.Lbl_filelist = New System.Windows.Forms.Label()
    Me.Tb_angelegtam = New System.Windows.Forms.TextBox()
    Me.Lbl_angelgtam = New System.Windows.Forms.Label()
    Me.Tb_angelegtDurch = New System.Windows.Forms.TextBox()
    Me.Lbl_angelgtdurch = New System.Windows.Forms.Label()
    Me.Tb_geaendertdurch = New System.Windows.Forms.TextBox()
    Me.Lbl_geaendertdzrch = New System.Windows.Forms.Label()
    Me.Tb_geaendertam = New System.Windows.Forms.TextBox()
    Me.Lbl_Geaendertam = New System.Windows.Forms.Label()
    Me.GroupBox1.SuspendLayout()
    Me.GroupBox2.SuspendLayout()
    Me.SuspendLayout()
    '
    'Lbl_charge
    '
    Me.Lbl_charge.AutoSize = True
    Me.Lbl_charge.Location = New System.Drawing.Point(85, 20)
    Me.Lbl_charge.Name = "Lbl_charge"
    Me.Lbl_charge.Size = New System.Drawing.Size(63, 13)
    Me.Lbl_charge.TabIndex = 41
    Me.Lbl_charge.Text = "Auftrags-Nr."
    Me.Lbl_charge.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '
    'tb_charge
    '
    Me.tb_charge.Location = New System.Drawing.Point(155, 18)
    Me.tb_charge.Name = "tb_charge"
    Me.tb_charge.Size = New System.Drawing.Size(319, 20)
    Me.tb_charge.TabIndex = 1
    '
    'lbl_produktnr
    '
    Me.lbl_produktnr.AutoSize = True
    Me.lbl_produktnr.Location = New System.Drawing.Point(90, 95)
    Me.lbl_produktnr.Name = "lbl_produktnr"
    Me.lbl_produktnr.Size = New System.Drawing.Size(61, 13)
    Me.lbl_produktnr.TabIndex = 43
    Me.lbl_produktnr.Text = "Material-Nr."
    Me.lbl_produktnr.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '
    'Tb_produktnummer
    '
    Me.Tb_produktnummer.Location = New System.Drawing.Point(155, 90)
    Me.Tb_produktnummer.Name = "Tb_produktnummer"
    Me.Tb_produktnummer.Size = New System.Drawing.Size(319, 20)
    Me.Tb_produktnummer.TabIndex = 3
    '
    'lbl_produktbez
    '
    Me.lbl_produktbez.AutoSize = True
    Me.lbl_produktbez.Location = New System.Drawing.Point(45, 55)
    Me.lbl_produktbez.Name = "lbl_produktbez"
    Me.lbl_produktbez.Size = New System.Drawing.Size(105, 13)
    Me.lbl_produktbez.TabIndex = 42
    Me.lbl_produktbez.Text = "Produktbezeichnung"
    Me.lbl_produktbez.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '
    'Tb_produktbez
    '
    Me.Tb_produktbez.Location = New System.Drawing.Point(155, 55)
    Me.Tb_produktbez.Name = "Tb_produktbez"
    Me.Tb_produktbez.Size = New System.Drawing.Size(319, 20)
    Me.Tb_produktbez.TabIndex = 2
    '
    'Lbl_kabine
    '
    Me.Lbl_kabine.AutoSize = True
    Me.Lbl_kabine.Location = New System.Drawing.Point(925, 58)
    Me.Lbl_kabine.Name = "Lbl_kabine"
    Me.Lbl_kabine.Size = New System.Drawing.Size(51, 13)
    Me.Lbl_kabine.TabIndex = 53
    Me.Lbl_kabine.Text = "Abfülllinie"
    Me.Lbl_kabine.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    Me.Lbl_kabine.Visible = False
    '
    'Cb_kabinennummer
    '
    Me.Cb_kabinennummer.Enabled = False
    Me.Cb_kabinennummer.FormattingEnabled = True
    Me.Cb_kabinennummer.Items.AddRange(New Object() {"E172"})
    Me.Cb_kabinennummer.Location = New System.Drawing.Point(982, 55)
    Me.Cb_kabinennummer.Name = "Cb_kabinennummer"
    Me.Cb_kabinennummer.Size = New System.Drawing.Size(165, 21)
    Me.Cb_kabinennummer.TabIndex = 40
    Me.Cb_kabinennummer.Visible = False
    '
    'lbl_startzeit
    '
    Me.lbl_startzeit.AutoSize = True
    Me.lbl_startzeit.Location = New System.Drawing.Point(13, 32)
    Me.lbl_startzeit.Name = "lbl_startzeit"
    Me.lbl_startzeit.Size = New System.Drawing.Size(45, 13)
    Me.lbl_startzeit.TabIndex = 45
    Me.lbl_startzeit.Text = "Startzeit"
    Me.lbl_startzeit.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '
    'Tb_startzeit
    '
    Me.Tb_startzeit.Location = New System.Drawing.Point(62, 28)
    Me.Tb_startzeit.Name = "Tb_startzeit"
    Me.Tb_startzeit.Size = New System.Drawing.Size(165, 20)
    Me.Tb_startzeit.TabIndex = 7
    '
    'Lbl_strtbsp
    '
    Me.Lbl_strtbsp.AutoSize = True
    Me.Lbl_strtbsp.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Lbl_strtbsp.Location = New System.Drawing.Point(80, 51)
    Me.Lbl_strtbsp.Name = "Lbl_strtbsp"
    Me.Lbl_strtbsp.Size = New System.Drawing.Size(89, 12)
    Me.Lbl_strtbsp.TabIndex = 46
    Me.Lbl_strtbsp.Text = "01.01.2006 00:00:00"
    '
    'Lbl_endzeit
    '
    Me.Lbl_endzeit.AutoSize = True
    Me.Lbl_endzeit.Location = New System.Drawing.Point(16, 79)
    Me.Lbl_endzeit.Name = "Lbl_endzeit"
    Me.Lbl_endzeit.Size = New System.Drawing.Size(42, 13)
    Me.Lbl_endzeit.TabIndex = 47
    Me.Lbl_endzeit.Text = "Endzeit"
    Me.Lbl_endzeit.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '
    'Tb_endzeit
    '
    Me.Tb_endzeit.Location = New System.Drawing.Point(62, 75)
    Me.Tb_endzeit.Name = "Tb_endzeit"
    Me.Tb_endzeit.Size = New System.Drawing.Size(165, 20)
    Me.Tb_endzeit.TabIndex = 8
    '
    'Llb_endzeitbsp
    '
    Me.Llb_endzeitbsp.AutoSize = True
    Me.Llb_endzeitbsp.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Llb_endzeitbsp.Location = New System.Drawing.Point(80, 98)
    Me.Llb_endzeitbsp.Name = "Llb_endzeitbsp"
    Me.Llb_endzeitbsp.Size = New System.Drawing.Size(89, 12)
    Me.Llb_endzeitbsp.TabIndex = 48
    Me.Llb_endzeitbsp.Text = "31.12.2006 23:59:59"
    '
    'Lbl_kommentar
    '
    Me.Lbl_kommentar.AutoSize = True
    Me.Lbl_kommentar.Location = New System.Drawing.Point(91, 381)
    Me.Lbl_kommentar.Name = "Lbl_kommentar"
    Me.Lbl_kommentar.Size = New System.Drawing.Size(60, 13)
    Me.Lbl_kommentar.TabIndex = 56
    Me.Lbl_kommentar.Text = "Kommentar"
    Me.Lbl_kommentar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '
    'Tb_kommentar
    '
    Me.Tb_kommentar.Location = New System.Drawing.Point(155, 381)
    Me.Tb_kommentar.Multiline = True
    Me.Tb_kommentar.Name = "Tb_kommentar"
    Me.Tb_kommentar.ScrollBars = System.Windows.Forms.ScrollBars.Both
    Me.Tb_kommentar.Size = New System.Drawing.Size(803, 45)
    Me.Tb_kommentar.TabIndex = 9
    '
    'cmd_neu
    '
    Me.cmd_neu.Location = New System.Drawing.Point(604, 18)
    Me.cmd_neu.Name = "cmd_neu"
    Me.cmd_neu.Size = New System.Drawing.Size(144, 33)
    Me.cmd_neu.TabIndex = 11
    Me.cmd_neu.Text = "&Neu"
    Me.cmd_neu.UseVisualStyleBackColor = True
    '
    'cmd_speichern
    '
    Me.cmd_speichern.Location = New System.Drawing.Point(604, 68)
    Me.cmd_speichern.Name = "cmd_speichern"
    Me.cmd_speichern.Size = New System.Drawing.Size(144, 33)
    Me.cmd_speichern.TabIndex = 12
    Me.cmd_speichern.Text = "Datensatz &speichern"
    Me.cmd_speichern.UseVisualStyleBackColor = True
    '
    'cmd_print
    '
    Me.cmd_print.Location = New System.Drawing.Point(604, 118)
    Me.cmd_print.Name = "cmd_print"
    Me.cmd_print.Size = New System.Drawing.Size(144, 33)
    Me.cmd_print.TabIndex = 13
    Me.cmd_print.Text = "&Drucken"
    Me.cmd_print.UseVisualStyleBackColor = True
    '
    'cmd_close
    '
    Me.cmd_close.Location = New System.Drawing.Point(604, 168)
    Me.cmd_close.Name = "cmd_close"
    Me.cmd_close.Size = New System.Drawing.Size(144, 33)
    Me.cmd_close.TabIndex = 14
    Me.cmd_close.Text = "S&chliessen"
    Me.cmd_close.UseVisualStyleBackColor = True
    '
    'cmd_beenden
    '
    Me.cmd_beenden.Location = New System.Drawing.Point(605, 222)
    Me.cmd_beenden.Name = "cmd_beenden"
    Me.cmd_beenden.Size = New System.Drawing.Size(143, 33)
    Me.cmd_beenden.TabIndex = 15
    Me.cmd_beenden.Text = "&Beenden"
    Me.cmd_beenden.UseVisualStyleBackColor = True
    '
    'lbl_batchnr
    '
    Me.lbl_batchnr.AutoSize = True
    Me.lbl_batchnr.Location = New System.Drawing.Point(85, 130)
    Me.lbl_batchnr.Name = "lbl_batchnr"
    Me.lbl_batchnr.Size = New System.Drawing.Size(64, 13)
    Me.lbl_batchnr.TabIndex = 44
    Me.lbl_batchnr.Text = "Chargen-Nr."
    Me.lbl_batchnr.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '
    'tb_batchnummer
    '
    Me.tb_batchnummer.Location = New System.Drawing.Point(155, 127)
    Me.tb_batchnummer.Name = "tb_batchnummer"
    Me.tb_batchnummer.Size = New System.Drawing.Size(319, 20)
    Me.tb_batchnummer.TabIndex = 4
    '
    'Lbl_kurzauswertung
    '
    Me.Lbl_kurzauswertung.AutoSize = True
    Me.Lbl_kurzauswertung.Location = New System.Drawing.Point(68, 319)
    Me.Lbl_kurzauswertung.Name = "Lbl_kurzauswertung"
    Me.Lbl_kurzauswertung.Size = New System.Drawing.Size(83, 13)
    Me.Lbl_kurzauswertung.TabIndex = 54
    Me.Lbl_kurzauswertung.Text = "Kurzauswertung"
    Me.Lbl_kurzauswertung.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '
    'tb_kurzauswertung
    '
    Me.tb_kurzauswertung.Location = New System.Drawing.Point(155, 319)
    Me.tb_kurzauswertung.Multiline = True
    Me.tb_kurzauswertung.Name = "tb_kurzauswertung"
    Me.tb_kurzauswertung.ReadOnly = True
    Me.tb_kurzauswertung.ScrollBars = System.Windows.Forms.ScrollBars.Both
    Me.tb_kurzauswertung.Size = New System.Drawing.Size(803, 43)
    Me.tb_kurzauswertung.TabIndex = 55
    '
    'ListView1
    '
    Me.ListView1.HideSelection = False
    Me.ListView1.Location = New System.Drawing.Point(39, 712)
    Me.ListView1.Name = "ListView1"
    Me.ListView1.Size = New System.Drawing.Size(1108, 112)
    Me.ListView1.TabIndex = 29
    Me.ListView1.UseCompatibleStateImageBehavior = False
    '
    'lbl_audittrial
    '
    Me.lbl_audittrial.AutoSize = True
    Me.lbl_audittrial.Location = New System.Drawing.Point(36, 696)
    Me.lbl_audittrial.Name = "lbl_audittrial"
    Me.lbl_audittrial.Size = New System.Drawing.Size(54, 13)
    Me.lbl_audittrial.TabIndex = 66
    Me.lbl_audittrial.Text = "Audit-Trail"
    '
    'GroupBox1
    '
    Me.GroupBox1.Controls.Add(Me.Label1)
    Me.GroupBox1.Controls.Add(Me.Tb_EndZeit_Vorbereitung)
    Me.GroupBox1.Controls.Add(Me.Label2)
    Me.GroupBox1.Controls.Add(Me.Label3)
    Me.GroupBox1.Controls.Add(Me.Tb_StartZeit_Vorbereitung)
    Me.GroupBox1.Controls.Add(Me.Label4)
    Me.GroupBox1.Location = New System.Drawing.Point(48, 168)
    Me.GroupBox1.Name = "GroupBox1"
    Me.GroupBox1.Size = New System.Drawing.Size(233, 119)
    Me.GroupBox1.TabIndex = 32
    Me.GroupBox1.TabStop = False
    Me.GroupBox1.Text = "Setup"
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label1.Location = New System.Drawing.Point(76, 94)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(89, 12)
    Me.Label1.TabIndex = 52
    Me.Label1.Text = "31.12.2006 23:59:59"
    '
    'Tb_EndZeit_Vorbereitung
    '
    Me.Tb_EndZeit_Vorbereitung.Location = New System.Drawing.Point(58, 71)
    Me.Tb_EndZeit_Vorbereitung.Name = "Tb_EndZeit_Vorbereitung"
    Me.Tb_EndZeit_Vorbereitung.Size = New System.Drawing.Size(165, 20)
    Me.Tb_EndZeit_Vorbereitung.TabIndex = 6
    '
    'Label2
    '
    Me.Label2.AutoSize = True
    Me.Label2.Location = New System.Drawing.Point(12, 75)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(42, 13)
    Me.Label2.TabIndex = 51
    Me.Label2.Text = "Endzeit"
    Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '
    'Label3
    '
    Me.Label3.AutoSize = True
    Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Label3.Location = New System.Drawing.Point(76, 47)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(89, 12)
    Me.Label3.TabIndex = 50
    Me.Label3.Text = "01.01.2006 00:00:00"
    '
    'Tb_StartZeit_Vorbereitung
    '
    Me.Tb_StartZeit_Vorbereitung.Location = New System.Drawing.Point(58, 24)
    Me.Tb_StartZeit_Vorbereitung.Name = "Tb_StartZeit_Vorbereitung"
    Me.Tb_StartZeit_Vorbereitung.Size = New System.Drawing.Size(165, 20)
    Me.Tb_StartZeit_Vorbereitung.TabIndex = 5
    '
    'Label4
    '
    Me.Label4.AutoSize = True
    Me.Label4.Location = New System.Drawing.Point(9, 28)
    Me.Label4.Name = "Label4"
    Me.Label4.Size = New System.Drawing.Size(45, 13)
    Me.Label4.TabIndex = 49
    Me.Label4.Text = "Startzeit"
    Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '
    'GroupBox2
    '
    Me.GroupBox2.Controls.Add(Me.Tb_startzeit)
    Me.GroupBox2.Controls.Add(Me.lbl_startzeit)
    Me.GroupBox2.Controls.Add(Me.Lbl_strtbsp)
    Me.GroupBox2.Controls.Add(Me.Lbl_endzeit)
    Me.GroupBox2.Controls.Add(Me.Tb_endzeit)
    Me.GroupBox2.Controls.Add(Me.Llb_endzeitbsp)
    Me.GroupBox2.Location = New System.Drawing.Point(313, 168)
    Me.GroupBox2.Name = "GroupBox2"
    Me.GroupBox2.Size = New System.Drawing.Size(240, 119)
    Me.GroupBox2.TabIndex = 33
    Me.GroupBox2.TabStop = False
    Me.GroupBox2.Text = "Produktion"
    '
    'Lb_Filelist
    '
    Me.Lb_Filelist.FormattingEnabled = True
    Me.Lb_Filelist.Location = New System.Drawing.Point(155, 453)
    Me.Lb_Filelist.Name = "Lb_Filelist"
    Me.Lb_Filelist.Size = New System.Drawing.Size(343, 225)
    Me.Lb_Filelist.TabIndex = 10
    '
    'Lbl_filelist
    '
    Me.Lbl_filelist.AutoSize = True
    Me.Lbl_filelist.Location = New System.Drawing.Point(36, 453)
    Me.Lbl_filelist.Name = "Lbl_filelist"
    Me.Lbl_filelist.Size = New System.Drawing.Size(112, 13)
    Me.Lbl_filelist.TabIndex = 57
    Me.Lbl_filelist.Text = "erzeugte pdf Datei(en)"
    Me.Lbl_filelist.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
    '
    'Tb_angelegtam
    '
    Me.Tb_angelegtam.Location = New System.Drawing.Point(155, 843)
    Me.Tb_angelegtam.Name = "Tb_angelegtam"
    Me.Tb_angelegtam.ReadOnly = True
    Me.Tb_angelegtam.Size = New System.Drawing.Size(165, 20)
    Me.Tb_angelegtam.TabIndex = 67
    '
    'Lbl_angelgtam
    '
    Me.Lbl_angelgtam.AutoSize = True
    Me.Lbl_angelgtam.Location = New System.Drawing.Point(82, 846)
    Me.Lbl_angelgtam.Name = "Lbl_angelgtam"
    Me.Lbl_angelgtam.Size = New System.Drawing.Size(67, 13)
    Me.Lbl_angelgtam.TabIndex = 68
    Me.Lbl_angelgtam.Text = "Angelegt Am"
    Me.Lbl_angelgtam.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '
    'Tb_angelegtDurch
    '
    Me.Tb_angelegtDurch.Location = New System.Drawing.Point(154, 878)
    Me.Tb_angelegtDurch.Name = "Tb_angelegtDurch"
    Me.Tb_angelegtDurch.ReadOnly = True
    Me.Tb_angelegtDurch.Size = New System.Drawing.Size(165, 20)
    Me.Tb_angelegtDurch.TabIndex = 69
    '
    'Lbl_angelgtdurch
    '
    Me.Lbl_angelgtdurch.AutoSize = True
    Me.Lbl_angelgtdurch.Location = New System.Drawing.Point(69, 881)
    Me.Lbl_angelgtdurch.Name = "Lbl_angelgtdurch"
    Me.Lbl_angelgtdurch.Size = New System.Drawing.Size(79, 13)
    Me.Lbl_angelgtdurch.TabIndex = 70
    Me.Lbl_angelgtdurch.Text = "Angelegt durch"
    Me.Lbl_angelgtdurch.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '
    'Tb_geaendertdurch
    '
    Me.Tb_geaendertdurch.Location = New System.Drawing.Point(450, 882)
    Me.Tb_geaendertdurch.Name = "Tb_geaendertdurch"
    Me.Tb_geaendertdurch.ReadOnly = True
    Me.Tb_geaendertdurch.Size = New System.Drawing.Size(165, 20)
    Me.Tb_geaendertdurch.TabIndex = 73
    '
    'Lbl_geaendertdzrch
    '
    Me.Lbl_geaendertdzrch.AutoSize = True
    Me.Lbl_geaendertdzrch.Location = New System.Drawing.Point(365, 885)
    Me.Lbl_geaendertdzrch.Name = "Lbl_geaendertdzrch"
    Me.Lbl_geaendertdzrch.Size = New System.Drawing.Size(81, 13)
    Me.Lbl_geaendertdzrch.TabIndex = 74
    Me.Lbl_geaendertdzrch.Text = "Geändert durch"
    Me.Lbl_geaendertdzrch.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '
    'Tb_geaendertam
    '
    Me.Tb_geaendertam.Location = New System.Drawing.Point(451, 847)
    Me.Tb_geaendertam.Name = "Tb_geaendertam"
    Me.Tb_geaendertam.ReadOnly = True
    Me.Tb_geaendertam.Size = New System.Drawing.Size(165, 20)
    Me.Tb_geaendertam.TabIndex = 71
    '
    'Lbl_Geaendertam
    '
    Me.Lbl_Geaendertam.AutoSize = True
    Me.Lbl_Geaendertam.Location = New System.Drawing.Point(378, 850)
    Me.Lbl_Geaendertam.Name = "Lbl_Geaendertam"
    Me.Lbl_Geaendertam.Size = New System.Drawing.Size(69, 13)
    Me.Lbl_Geaendertam.TabIndex = 72
    Me.Lbl_Geaendertam.Text = "Geändert Am"
    Me.Lbl_Geaendertam.TextAlign = System.Drawing.ContentAlignment.MiddleRight
    '
    'Frm_chrg_prot_detail
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(1245, 943)
    Me.ControlBox = False
    Me.Controls.Add(Me.Tb_geaendertdurch)
    Me.Controls.Add(Me.Lbl_geaendertdzrch)
    Me.Controls.Add(Me.Tb_geaendertam)
    Me.Controls.Add(Me.Lbl_Geaendertam)
    Me.Controls.Add(Me.Tb_angelegtDurch)
    Me.Controls.Add(Me.Lbl_angelgtdurch)
    Me.Controls.Add(Me.Tb_angelegtam)
    Me.Controls.Add(Me.Lbl_angelgtam)
    Me.Controls.Add(Me.Lbl_filelist)
    Me.Controls.Add(Me.Lb_Filelist)
    Me.Controls.Add(Me.GroupBox2)
    Me.Controls.Add(Me.GroupBox1)
    Me.Controls.Add(Me.lbl_audittrial)
    Me.Controls.Add(Me.ListView1)
    Me.Controls.Add(Me.tb_kurzauswertung)
    Me.Controls.Add(Me.Lbl_kurzauswertung)
    Me.Controls.Add(Me.tb_batchnummer)
    Me.Controls.Add(Me.lbl_batchnr)
    Me.Controls.Add(Me.cmd_beenden)
    Me.Controls.Add(Me.cmd_close)
    Me.Controls.Add(Me.cmd_print)
    Me.Controls.Add(Me.cmd_speichern)
    Me.Controls.Add(Me.cmd_neu)
    Me.Controls.Add(Me.Tb_kommentar)
    Me.Controls.Add(Me.Lbl_kommentar)
    Me.Controls.Add(Me.Cb_kabinennummer)
    Me.Controls.Add(Me.Lbl_kabine)
    Me.Controls.Add(Me.Tb_produktbez)
    Me.Controls.Add(Me.lbl_produktbez)
    Me.Controls.Add(Me.Tb_produktnummer)
    Me.Controls.Add(Me.lbl_produktnr)
    Me.Controls.Add(Me.tb_charge)
    Me.Controls.Add(Me.Lbl_charge)
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "Frm_chrg_prot_detail"
    Me.Text = "Chargendetail"
    Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
    Me.GroupBox1.ResumeLayout(False)
    Me.GroupBox1.PerformLayout()
    Me.GroupBox2.ResumeLayout(False)
    Me.GroupBox2.PerformLayout()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents Lbl_charge As System.Windows.Forms.Label
  Friend WithEvents tb_charge As System.Windows.Forms.TextBox
  Friend WithEvents lbl_produktnr As System.Windows.Forms.Label
  Friend WithEvents Tb_produktnummer As System.Windows.Forms.TextBox
  Friend WithEvents lbl_produktbez As System.Windows.Forms.Label
  Friend WithEvents Tb_produktbez As System.Windows.Forms.TextBox
  Friend WithEvents Lbl_kabine As System.Windows.Forms.Label
  Friend WithEvents Cb_kabinennummer As System.Windows.Forms.ComboBox
  Friend WithEvents lbl_startzeit As System.Windows.Forms.Label
  Friend WithEvents Tb_startzeit As System.Windows.Forms.TextBox
  Friend WithEvents Lbl_strtbsp As System.Windows.Forms.Label
  Friend WithEvents Lbl_endzeit As System.Windows.Forms.Label
  Friend WithEvents Tb_endzeit As System.Windows.Forms.TextBox
  Friend WithEvents Llb_endzeitbsp As System.Windows.Forms.Label
  Friend WithEvents Lbl_kommentar As System.Windows.Forms.Label
  Friend WithEvents Tb_kommentar As System.Windows.Forms.TextBox
  Friend WithEvents cmd_neu As System.Windows.Forms.Button
  Friend WithEvents cmd_speichern As System.Windows.Forms.Button
  Friend WithEvents cmd_print As System.Windows.Forms.Button
  Friend WithEvents cmd_close As System.Windows.Forms.Button
  Friend WithEvents cmd_beenden As System.Windows.Forms.Button
  Friend WithEvents lbl_batchnr As System.Windows.Forms.Label
  Friend WithEvents tb_batchnummer As System.Windows.Forms.TextBox
  Friend WithEvents Lbl_kurzauswertung As System.Windows.Forms.Label
  Friend WithEvents tb_kurzauswertung As System.Windows.Forms.TextBox
  Friend WithEvents ListView1 As System.Windows.Forms.ListView
  Friend WithEvents lbl_audittrial As System.Windows.Forms.Label
  Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents Tb_EndZeit_Vorbereitung As System.Windows.Forms.TextBox
  Friend WithEvents Label2 As System.Windows.Forms.Label
  Friend WithEvents Label3 As System.Windows.Forms.Label
  Friend WithEvents Tb_StartZeit_Vorbereitung As System.Windows.Forms.TextBox
  Friend WithEvents Label4 As System.Windows.Forms.Label
  Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
  Friend WithEvents Lb_Filelist As ListBox
  Friend WithEvents Lbl_filelist As Label
  Friend WithEvents Tb_angelegtam As TextBox
  Friend WithEvents Lbl_angelgtam As Label
  Friend WithEvents Tb_angelegtDurch As TextBox
  Friend WithEvents Lbl_angelgtdurch As Label
  Friend WithEvents Tb_geaendertdurch As TextBox
  Friend WithEvents Lbl_geaendertdzrch As Label
  Friend WithEvents Tb_geaendertam As TextBox
  Friend WithEvents Lbl_Geaendertam As Label
End Class
