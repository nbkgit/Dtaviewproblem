Option Strict On
Option Explicit On

Imports System.Data.SqlClient

Module ModChargProt

    Public Function ReadRohdaten_foi(ByVal Charge As String, ByVal ProtTyp As Byte, auto_ode_manuell_xpi As Integer) As Integer
        'Erstellt das komplette Dataset mit allen f�r den jeweiligen report erforderlichen Tabellen
        'F�r Chargenprotkollierung wird zus�tzlich das Ergebnis der Kurzauswertung in dei Datenbank geschrieben

        '�bergabe-Parameter Charge: ID aus tbl. Chargen -> Randwerte f�r die Rohdaten
        'R�ckgabewerte:
        '-1: Funktion ist OK, Report kann aufgerufen werden
        '0:  Funktion nicht OK, Report kann nicht aufgerufen werden

        'Ablauf:
        '0. Pr�fen, ob die letzte g�ltige Datenabholung l�nger als 1 Std. her ist, wenn nein, Merker "Daten aktualisieren" aktivieren
        '1. In Schleife pr�fen, ob alle MDB's vorhanden sind, wenn nein, Merker "Daten aktualisieren" aktivieren
        '1a Ggfls. Funktion "Daten aktualisieren" aufrufen
        '1b Pr�fen, ob alle Rohdaten-MDB's vorhanden sind
        '2. In Schleife das Dataset f�llen
        '3. Dataset auf Vollst�ndigkeit der Daten pr�fen, wenn nein, Funktion "Daten aktualisieren" aufrufen (nur, wenn sie zuvor nicht aufgerufen wurde)
        '4. Daten gem. Einstellungen aus Datensatz der Charge einer Bewertung unterziehen ("Kurzauswertung")

        'deklat und init

        Dim Kurzauswertung_xps As String = ""

        Dim LimitPartikel�berschritten_xpb As Boolean = False
        Dim LimitFlow�berschritten_xpb As Boolean = False
        Dim StartDatZeit_xpd As DateTime, EndDatZeit_xpd As DateTime
        Dim StartDatZeitsetup_xpd As DateTime, EndDatZeitSetup_xpd As DateTime
        Dim DelaySeconds_xpi As Integer, DelayTmp_xpi As Integer
        Dim DatTmp_xpd As DateTime, DatTmpNext_xpd As DateTime
        Dim AnzDsDatZeitFehler_xpi As Integer = 0
        Dim AnzDsPZ05Fehler_xpi As Integer = 0
        Dim AnzDsAlarmFehler_xpi As Integer = 0
        Dim AnzDsDatZeitFehler_prod_xpi As Integer = 0
        Dim AnzDsPZ05Fehler_prod_xpi As Integer = 0
        Dim AnzDsPZ5Fehler_prod_xpi As Integer = 0
        Dim AnzDsAlarmFehler_prod_xpi As Integer = 0
        Dim AnzDsDatZeitFehler_Setup_xpi As Integer = 0
        Dim AnzDsPZ05Fehler_Setup_xpi As Integer = 0
        Dim AnzDsPZ5Fehler_Setup_xpi As Integer = 0
        Dim AnzDsAlarmFehler_Setup_xpi As Integer = 0
        Dim UntereGrenzeAlarme_xpi As Integer = 0
        Dim ObereeGrenzeAlarme_xpi As Integer = 0
        Dim AnzDsPZ5Fehler_xpi As Integer = 0
        Dim FeldFehlerAkt_xpb(14) As Boolean   'Flankenmerker: False: Keine Grenzwertverletzung; True: Grenzwertzverletzung
        Dim FeldFehlerAlt_xpb(14) As Boolean   'Flankenmerker: False: Keine Grenzwertverletzung; True: Grenzwertzverletzung
        Dim Flankenwechsel_xpb As Boolean

        'Grenzwerte f�r Partikelkonzentrationen
        Dim LimitPZ05_xpi As Integer
        Dim LimitPZ_5_xpi As Integer

        Dim PZMax0_5_xpi As Integer
        Dim PZMax5_xpi As Integer
        Dim PZMax0_5SUM_xpi As Integer
        Dim PZMax5SUM_xpi As Integer

        Dim PZMin0_5_xpi As Integer
        Dim PZMin5_xpi As Integer
        Dim PZMin0_5SUM_xpi As Integer
        Dim PZMin5SUM_xpi As Integer
        Dim AnzAintervallMax_xpi As Integer = 0

        Dim Linienbeschreibung_xpb As Byte

        Dim SqlSelect_xps As String, SqlTabelle_xps As String, SqlWhere_xps As String
        Dim SqlEreignis_xps As String
        Dim AnzSollDS_xpi As Integer, AnzIstDS_xpi As Integer
        Dim i_xpi As Integer

        Dim RowDet_xp As DataRow()    'wird f�r verschiedene Tabellen verwendet (tempor�r)
        Dim RowDetAudit_xp As DataRow()    'wird f�r Audittrail verwendet (tempor�r)
        Dim Rowtmp_xp As DataRow      'wird f�r verschiedene Tabellen verwendet (tempor�r)
        Dim RowTmpDet_xp As DataRow  'wird f�r verschiedene Tabellen verwendet (tempor�r)

        Ds_Rohdat_xo = Nothing
        Ds_Rohdat_xo = New DataSet

        Try
            '-1: Randwerte aus Chargen.mdb und holen
            'Neue Tabelle "Charge" im Dataset erzeugen
            Ds_Rohdat_xo.Tables.Add("Chargen")
            'Tabellendefinition �bernehmen:
            For i_xpi = 0 To ds_chartprotmdb_xbo.Tables("Chargen").Columns.Count - 1
                Ds_Rohdat_xo.Tables("Chargen").Columns.Add(ds_chartprotmdb_xbo.Tables("Chargen").Columns(i_xpi).ColumnName)
                Ds_Rohdat_xo.Tables("Chargen").Columns(i_xpi).DataType = ds_chartprotmdb_xbo.Tables("Chargen").Columns(i_xpi).DataType
            Next
            Ds_Rohdat_xo.Tables("Chargen").Columns.Add("Modus")
            Ds_Rohdat_xo.Tables("Chargen").Columns("Modus").DataType = ds_chartprotmdb_xbo.Tables("Chargen").Columns(0).DataType
            Ds_Rohdat_xo.Tables("Chargen").Columns.Add("Linietext")
            Ds_Rohdat_xo.Tables("Chargen").Columns("Linietext").DataType = ds_chartprotmdb_xbo.Tables("Chargen").Columns(0).DataType
            Ds_Rohdat_xo.Tables("Chargen").Columns.Add("Anzahl_Alarme")
            Ds_Rohdat_xo.Tables("Chargen").Columns("Anzahl_Alarme").DataType = ds_chartprotmdb_xbo.Tables("Chargen").Columns(0).DataType


            'und neue row erzeugen

            Rowtmp_xp = Ds_Rohdat_xo.Tables("Chargen").NewRow
            RowDet_xp = ds_chartprotmdb_xbo.Tables("Chargen").Select("[Auftragsnummer] Like '" & Charge & "'")
            For i_xpi = 0 To ds_chartprotmdb_xbo.Tables("Chargen").Columns.Count - 1
                Rowtmp_xp(i_xpi) = RowDet_xp(0).Item(i_xpi)
                'Randwerte der Chargenprotokollierung ermitteln
                Select Case i_xpi
                    Case 0
          'Charge
                    Case 1
          'ProduktNummer
                    Case 2
          'Produkt
                    Case 3
          'BatchNummer
                    Case 4
                        'Kabine
                        Linienbeschreibung_xpb = CByte(RowDet_xp(0).Item(i_xpi))
                    Case 5
          'Messposition, nicht relevant
                    Case 6
          'PZ1Auswerten
          'PZAktiv_xpb(1) = CBool(RowDet_xp(0).Item(i_xpi))
                    Case 7
          'PZ2Auswerten
          'PZAktiv_xpb(2) = CBool(RowDet_xp(0).Item(i_xpi))
                    Case 8
          'PZ3Auswerten
          'PZAktiv_xpb(3) = CBool(RowDet_xp(0).Item(i_xpi))<
                    Case 9
                        'StartZeit
                        StartDatZeit_xpd = CDate(RowDet_xp(0).Item(i_xpi))
                    Case 10
                        'EndZeit
                        EndDatZeit_xpd = CDate(RowDet_xp(0).Item(i_xpi))
                    Case 11
          'Produktionstyp
                    Case 12
          'AngelegtAm
                    Case 13
          'AngelegtDurch
                    Case 14
          'Ge�ndertAm
                    Case 15
          'Ge�ndertDurch
                    Case 16
          'Kurzauswertung
                    Case 17
          'Kommentar
                    Case 18
                        'StartZeit ZK
                        StartDatZeitsetup_xpd = CDate(RowDet_xp(0).Item(i_xpi))
                    Case 19
                        'EndZeit ZK
                        EndDatZeitSetup_xpd = CDate(RowDet_xp(0).Item(i_xpi))
                End Select
            Next
            'Linienbeschreibung_xpb

            If ProtTyp = 0 Then
                Rowtmp_xp.Item("Modus") = "CHARGENPROTOKOLL E172 (ZUSAMMENFASSUNG)"
            Else
                Rowtmp_xp.Item("Modus") = "CHARGENPROTOKOLL E172 MIT ROHDATEN"
            End If
            Ds_Rohdat_xo.Tables("Chargen").Rows.Add(Rowtmp_xp)

            If ProtTyp < 2 Then
                For n_xpi As Integer = 0 To 1
                    Dim setup_xps = String.Empty
                    Dim datzeit_von_xpd As Date = Now
                    Dim datzeit_bis_xpd As Date = Now
                    If n_xpi = 0 Then
                        setup_xps = "_Setup"
                        datzeit_von_xpd = StartDatZeitsetup_xpd
                        datzeit_bis_xpd = EndDatZeitSetup_xpd
                    Else
                        datzeit_von_xpd = StartDatZeit_xpd
                        datzeit_bis_xpd = EndDatZeit_xpd
                    End If
                    SqlTabelle_xps = "[PZ_E172]"
                    SqlSelect_xps = "SELECT " & SqlTabelle_xps & ".DatZeit, '' AS ErrDatZeit, "
                    SqlSelect_xps = SqlSelect_xps & SqlTabelle_xps & ".[Counter_ID], "
                    SqlSelect_xps = SqlSelect_xps & SqlTabelle_xps & ".[TaktZaehler], "
                    SqlSelect_xps = SqlSelect_xps & SqlTabelle_xps & ".[PZ_0_5], "
                    SqlSelect_xps = SqlSelect_xps & SqlTabelle_xps & ".[PZ_0_5_SUM], "
                    SqlSelect_xps = SqlSelect_xps & SqlTabelle_xps & ".[PZ_0_5_High_Limit], "
                    SqlSelect_xps = SqlSelect_xps & "CASE WHEN (" & SqlTabelle_xps & ".[PZ_0_5_SUM] > " & SqlTabelle_xps & ".[PZ_0_5_High_Limit]) Then '!!' ELSE  '' END as PZ_0_5_Alarm,"
                    SqlSelect_xps = SqlSelect_xps & SqlTabelle_xps & ".[PZ_5], "
                    SqlSelect_xps = SqlSelect_xps & SqlTabelle_xps & ".[PZ_5_SUM], "
                    SqlSelect_xps = SqlSelect_xps & SqlTabelle_xps & ".[PZ_5_High_Limit], "
                    SqlSelect_xps = SqlSelect_xps & "CASE WHEN (" & SqlTabelle_xps & ".[PZ_5_SUM] > " & SqlTabelle_xps & ".[PZ_5_High_Limit]) Then '!!' ELSE  '' END as PZ_5_0_Alarm,"
                    SqlSelect_xps = SqlSelect_xps & SqlTabelle_xps & ".[PZ_Anz_Intervall], "
                    SqlSelect_xps = SqlSelect_xps & SqlTabelle_xps & ".[PZ_Status], '' as Statustext "
                    SqlSelect_xps = SqlSelect_xps & "FROM " & SqlTabelle_xps

                    SqlWhere_xps = " WHERE DatZeit >= " & DatetoSqlserverString(datzeit_von_xpd) & " AND DatZeit <= " & DatetoSqlserverString(datzeit_bis_xpd) & " Order by [DatZeit] ASC;"
                    Dim cmd As New SqlCommand(SqlSelect_xps & SqlWhere_xps, cn_chargeprot_xbo)
                    Dim da As New SqlDataAdapter With {
            .SelectCommand = cmd
          }
                    da.Fill(Ds_Rohdat_xo, "Rohdaten" & setup_xps)

                    'Erstelle Diagramm daten tabelle
                    Dim SqlWhere_xps2 = " WHERE DatZeit >= " & DatetoSqlserverString(datzeit_von_xpd) & " AND DatZeit <= " & DatetoSqlserverString(datzeit_bis_xpd)
                    Dim Selectdiagramm_xps As String = "SELECT " & SqlTabelle_xps & ".DatZeit,"
                    Selectdiagramm_xps &= "CASE WHEN (" & SqlTabelle_xps & ".[PZ_0_5_SUM] / " & SqlTabelle_xps & ".[PZ_0_5_High_Limit] > 2.0) Then 2.0 Else " & SqlTabelle_xps & ".[PZ_0_5_SUM] / " & SqlTabelle_xps & ".[PZ_0_5_High_Limit] end As PZ_0_5_SUM_rel"
                    Selectdiagramm_xps &= ",CASE WHEN (" & SqlTabelle_xps & ".[PZ_5_SUM] / " & SqlTabelle_xps & ".[PZ_5_High_Limit] > 2.0) Then 2.0 Else " & SqlTabelle_xps & ".[PZ_5_SUM] / " & SqlTabelle_xps & ".[PZ_5_High_Limit] end As PZ_5_SUM_rel, "
                    Selectdiagramm_xps &= SqlTabelle_xps & ".[Counter_ID] "
                    Selectdiagramm_xps &= "FROM " & SqlTabelle_xps
                    Dim cmd2 As New SqlCommand(Selectdiagramm_xps & SqlWhere_xps, cn_chargeprot_xbo)
                    Dim da2 As New SqlDataAdapter With {
            .SelectCommand = cmd2
          }
                    da2.Fill(Ds_Rohdat_xo, "Diagramm" & setup_xps)

                    'Bei chargenprotokoll und mit rohdaten
                    'Hier das dataset auswerten

                    'Anzahl der Soll-Datens�tze ermitteln: (VisAM liefert 2 Datens�tze / Minute
                    AnzSollDS_xpi = CInt(DateDiff(DateInterval.Minute, StartDatZeit_xpd, EndDatZeit_xpd))
                    AnzIstDS_xpi = Ds_Rohdat_xo.Tables("Rohdaten" & setup_xps).Rows.Count
                    Select Case AnzIstDS_xpi
                        Case 0
                            'es gibt keine Datens�tze -> Funktion beenden
                            If auto_ode_manuell_xpi = 0 Then
                                MsgBox("F�r den ausgew�hlten Zeitraum sind keine Rohdaten vorhanden! �berpr�fen Sie bitte Start- und Endzeit der Charge!", MsgBoxStyle.Critical)
                            End If
                            Return 0
                        Case Is < AnzSollDS_xpi
            'es fehlen Datens�tze -> entspr. Meldung in Auswertung anzeigen
                        Case Is >= AnzSollDS_xpi
                            'Erforderliche Anzahl Datens�tze ist vorhanden
                    End Select
                    'waagerechte Tablle zusammensetzne

                    'Dataset auf zeitlich L�cken und Doubletten �berpr�fen
                    'dazu muss aus tbl ein sortiertes DataView aufgemacht werden

                    Dim m_xpi As Integer = 0
                    'Neue Tabelle "Auswertung" im Dataset erzeugen
                    Ds_Rohdat_xo.Tables.Add("Auswertung" & setup_xps)
                    Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).Columns.Add("Was")
                    Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).Columns.Add("PZ_0_5")
                    Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).Columns.Add("PZ_0_5_SUM")
                    Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).Columns.Add("PZ_5")
                    Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).Columns.Add("PZ_5_SUM")
                    Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).Columns.Add("Counter_ID")
                    AnzDsDatZeitFehler_xpi = 0
                    For p_xpi As Integer = 1 To 4

                        Dim RohDat_xp As DataView
                        RohDat_xp = Ds_Rohdat_xo.Tables("Rohdaten" & setup_xps).DefaultView
                        RohDat_xp.RowFilter = "Counter_ID = " & p_xpi.ToString
                        RohDat_xp.Sort = "DatZeit ASC"
                        DatTmp_xpd = datzeit_von_xpd
                        AnzIstDS_xpi = RohDat_xp.Count
                        AnzDsDatZeitFehler_xpi = 0
                        AnzDsPZ05Fehler_xpi = 0
                        AnzDsPZ5Fehler_xpi = 0
                        For i_xpi = 0 To AnzIstDS_xpi - 1

                            DatTmpNext_xpd = CDate(RohDat_xp(i_xpi).Item("DatZeit").ToString)
                            DelayTmp_xpi = CInt(DateDiff(DateInterval.Second, DatTmp_xpd, DatTmpNext_xpd))
                            'Datensatz mit Delay-Fehler markieren
                            If DelayTmp_xpi > 70 Then
                                RohDat_xp(i_xpi).Item("ErrDatZeit") = "!!"
                                AnzDsDatZeitFehler_xpi = AnzDsDatZeitFehler_xpi + 1
                                If n_xpi = 1 Then
                                    AnzDsDatZeitFehler_prod_xpi += 1

                                Else
                                    AnzDsDatZeitFehler_Setup_xpi += 1

                                End If
                            End If
                            'Max. Delay ermitteln
                            If DelayTmp_xpi > DelaySeconds_xpi Then
                                DelaySeconds_xpi = DelayTmp_xpi
                            Else
                                'kein neues Max. Delay
                            End If
                            'Beim letzten Datensatz Zeitvergleich mit EndDatZeit durchf�hren
                            If i_xpi = AnzIstDS_xpi - 1 Then
                                DelayTmp_xpi = CInt(DateDiff(DateInterval.Second, DatTmpNext_xpd, datzeit_bis_xpd))
                                'Datensatz mit Delay-Fehler markieren
                                If DelayTmp_xpi > 70 Then
                                    RohDat_xp(i_xpi).Item("ErrDatZeit") = "!!"
                                    AnzDsDatZeitFehler_xpi = AnzDsDatZeitFehler_xpi + 1
                                    If n_xpi = 1 Then
                                        AnzDsDatZeitFehler_prod_xpi += 1
                                    Else
                                        AnzDsDatZeitFehler_Setup_xpi += 1
                                    End If
                                End If
                                'Max. Delay ermitteln
                                If DelayTmp_xpi > DelaySeconds_xpi Then
                                    DelaySeconds_xpi = DelayTmp_xpi
                                Else
                                    'kein neues Max. Delay
                                End If
                            End If
                            DatTmp_xpd = DatTmpNext_xpd
                            If RohDat_xp(i_xpi).Item("PZ_0_5_Alarm").ToString = "!!" Then
                                AnzDsPZ05Fehler_xpi += 1
                                If n_xpi = 1 Then

                                    AnzDsPZ05Fehler_prod_xpi += 1
                                Else
                                    AnzDsPZ05Fehler_Setup_xpi += 1
                                End If
                            End If
                            If RohDat_xp(i_xpi).Item("PZ_5_0_Alarm").ToString = "!!" Then
                                AnzDsPZ5Fehler_xpi += 1
                                If n_xpi = 1 Then
                                    AnzDsPZ5Fehler_prod_xpi += 1
                                Else
                                    AnzDsPZ5Fehler_Setup_xpi += 1
                                End If
                            End If
                            'Statusbits verarbeiten
                            Dim statustext_xps As String = String.Empty
                            Try
                                Dim Statusbitarray_xpo As BitArray = New BitArray(System.BitConverter.GetBytes(CInt(RohDat_xp(i_xpi).Item("PZ_Status"))))
                                If Statusbitarray_xpo(0) Then
                                    statustext_xps = "L"
                                End If
                                If Statusbitarray_xpo(1) Then
                                    If statustext_xps = String.Empty Then
                                    Else
                                        statustext_xps &= ","
                                    End If
                                    statustext_xps &= "F"
                                End If
                                If Statusbitarray_xpo(2) Then
                                    If statustext_xps = String.Empty Then
                                    Else
                                        statustext_xps &= ","
                                    End If
                                    statustext_xps &= "H"
                                End If
                            Catch ex As Exception
                                'Sollte nicht vorkommen, aber status ist DBNULL
                            End Try

                            RohDat_xp(i_xpi).Item("Statustext") = statustext_xps
                        Next
                        'Dataset auf Grenzwertverletzungen Pr�fen und Tabelle "Auswertung" mit Daten f�llen
                        Dim tbl_xp As DataTable
                        tbl_xp = Ds_Rohdat_xo.Tables("Rohdaten" & setup_xps)
                        Dim keinDatenoz_xpi As Integer = 0
                        Try

                            PZMax0_5_xpi = CInt(tbl_xp.Compute("Max(PZ_0_5)", "Counter_ID = " & p_xpi.ToString))
                            PZMax5_xpi = CInt(tbl_xp.Compute("Max(PZ_5)", "Counter_ID = " & p_xpi.ToString))
                            PZMax0_5SUM_xpi = CInt(tbl_xp.Compute("Max(PZ_0_5_SUM)", "Counter_ID = " & p_xpi.ToString))
                            PZMax5SUM_xpi = CInt(tbl_xp.Compute("Max(PZ_5_SUM)", "Counter_ID = " & p_xpi.ToString))

                            PZMin0_5_xpi = CInt(tbl_xp.Compute("Min(PZ_0_5)", "Counter_ID = " & p_xpi.ToString))
                            PZMin5_xpi = CInt(tbl_xp.Compute("Min(PZ_5)", "Counter_ID = " & p_xpi.ToString))
                            PZMin0_5SUM_xpi = CInt(tbl_xp.Compute("Min(PZ_0_5_SUM)", "Counter_ID = " & p_xpi.ToString))
                            PZMin5SUM_xpi = CInt(tbl_xp.Compute("Min(PZ_5_SUM)", "Counter_ID = " & p_xpi.ToString))
                            LimitPZ05_xpi = CInt(tbl_xp.Compute("Max(PZ_0_5_High_Limit)", "Counter_ID = " & p_xpi.ToString))
                            LimitPZ_5_xpi = CInt(tbl_xp.Compute("Max(PZ_5_High_Limit)", "Counter_ID = " & p_xpi.ToString))
                            AnzAintervallMax_xpi = CInt(tbl_xp.Compute("Max(PZ_Anz_Intervall)", "Counter_ID = " & p_xpi.ToString))
                        Catch ex As Exception
                            keinDatenoz_xpi = 1
                        End Try

                        'und mit daten f�llen
                        If keinDatenoz_xpi = 1 Then
                            Rowtmp_xp = Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).NewRow
                            Rowtmp_xp(0) = "PZ" & p_xpi.ToString & " hat keine Daten"
                            Rowtmp_xp(5) = p_xpi.ToString
                            Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).Rows.Add(Rowtmp_xp)
                            AnzDsDatZeitFehler_xpi += 1
                            If n_xpi = 1 Then
                                AnzDsDatZeitFehler_prod_xpi += 1
                            Else
                                AnzDsDatZeitFehler_Setup_xpi += 1
                            End If
                        Else
                            Rowtmp_xp = Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).NewRow
                            Rowtmp_xp(0) = "Min:"

                            Rowtmp_xp(1) = "" 'PZMin0_5_xpi.ToString
                            Rowtmp_xp(2) = PZMin0_5SUM_xpi.ToString
                            Rowtmp_xp(3) = "" 'PZMin5_xpi.ToString
                            Rowtmp_xp(4) = PZMin5SUM_xpi.ToString
                            Rowtmp_xp(5) = p_xpi.ToString
                            Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).Rows.Add(Rowtmp_xp)

                            Rowtmp_xp = Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).NewRow
                            Rowtmp_xp(0) = "Max:"
                            Rowtmp_xp(1) = "" 'PZMax0_5_xpi.ToString
                            Rowtmp_xp(2) = PZMax0_5SUM_xpi.ToString
                            Rowtmp_xp(3) = "" ' PZMax5_xpi.ToString
                            Rowtmp_xp(4) = PZMax5SUM_xpi.ToString
                            Rowtmp_xp(5) = p_xpi.ToString
                            Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).Rows.Add(Rowtmp_xp)
                            Rowtmp_xp = Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).NewRow
                            'Rowtmp_xp(0) = "Anzahl Intervalle:"

                            'Rowtmp_xp(2) = AnzAintervallMax_xpi.ToString
                            'Rowtmp_xp(4) = AnzAintervallMax_xpi.ToString
                            'Rowtmp_xp(5) = p_xpi.ToString
                            'Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).Rows.Add(Rowtmp_xp)

                            'Rowtmp_xp = Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).NewRow
                            Rowtmp_xp(0) = "Limits:"

                            Rowtmp_xp(2) = LimitPZ05_xpi.ToString
                            Rowtmp_xp(4) = LimitPZ_5_xpi.ToString
                            Rowtmp_xp(5) = p_xpi.ToString
                            Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).Rows.Add(Rowtmp_xp)
                            Rowtmp_xp = Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).NewRow
                            Rowtmp_xp(0) = "Limits OK:"



                            If AnzDsPZ05Fehler_xpi > 0 Then
                                Rowtmp_xp(2) = "Err"
                            Else
                                Rowtmp_xp(2) = "OK"
                            End If
                            If AnzDsPZ5Fehler_xpi > 0 Then
                                Rowtmp_xp(4) = "Err"
                            Else
                                Rowtmp_xp(4) = "OK"
                            End If

                            Rowtmp_xp(5) = p_xpi.ToString
                            Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).Rows.Add(Rowtmp_xp)

                            'Max. Zeit zw. 2 Datens�tzen anzeigen
                            If AnzDsDatZeitFehler_xpi > 0 Then
                                Rowtmp_xp = Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).NewRow
                                Rowtmp_xp(0) = "Max. Zeitintervall [sec]:"
                                Rowtmp_xp(1) = DelaySeconds_xpi.ToString
                                Rowtmp_xp(2) = "sec."
                                Rowtmp_xp(3) = "(Limit:"
                                Rowtmp_xp(4) = "70 sec.)"
                                Rowtmp_xp(5) = p_xpi.ToString
                                Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).Rows.Add(Rowtmp_xp)
                            End If
                            If ProtTyp < 2 And (AnzDsDatZeitFehler_xpi > 0) Then
                                'Datens�tze mit Grenzwertverletzungen anzeigen
                                Rowtmp_xp = Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).NewRow
                                Rowtmp_xp(0) = "DATENL�CKEN:"
                                Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).Rows.Add(Rowtmp_xp)
                                Rowtmp_xp = Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).NewRow
                                Rowtmp_xp(0) = "Start:"
                                Rowtmp_xp(1) = "L�nge:"
                                Rowtmp_xp(5) = p_xpi.ToString
                                Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).Rows.Add(Rowtmp_xp)
                                'Alle DS der Tabelle absuchen
                                For i_xpi = 0 To AnzIstDS_xpi - 1
                                    Dim Fehlerspalte_ergaenzen_xpb As Boolean = False
                                    Flankenwechsel_xpb = False
                                    For j_xpi As Integer = 0 To 14
                                        'Alle "Fehler-Felder" durchlaufen und auf kommt / geht �berpr�fen
                                        If RohDat_xp(i_xpi).Item(j_xpi).ToString Like "!!" Then
                                            'Grenzwertverletzung vorhanden
                                            FeldFehlerAkt_xpb(j_xpi) = True
                                        Else
                                            FeldFehlerAkt_xpb(j_xpi) = False
                                        End If
                                    Next
                                    'Flankenwechsel detektieren
                                    For j_xpi As Integer = 0 To 14
                                        If FeldFehlerAkt_xpb(j_xpi) = FeldFehlerAlt_xpb(j_xpi) Then
                                            'Kein Flankenwechsel
                                        Else
                                            'Flankenwechsel vorhanden
                                            Flankenwechsel_xpb = True
                                        End If
                                    Next
                                    If Flankenwechsel_xpb = True Then
                                        'Neue Zeile anlegen
                                        Rowtmp_xp = Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).NewRow
                                        If i_xpi = 0 Then
                                            Rowtmp_xp(0) = StartDatZeit_xpd.ToString
                                        Else
                                            Rowtmp_xp(0) = RohDat_xp(i_xpi - 1).Item(0).ToString
                                        End If
                                        Dim LaengeSek_xpi As Integer = -1
                                        If i_xpi = AnzIstDS_xpi - 1 Then
                                            LaengeSek_xpi = CInt(DateDiff(DateInterval.Second, CDate(Rowtmp_xp(0).ToString), EndDatZeit_xpd))
                                        Else
                                            LaengeSek_xpi = CInt(DateDiff(DateInterval.Second, CDate(Rowtmp_xp(0).ToString), CDate(RohDat_xp(i_xpi).Item(0).ToString)))
                                        End If
                                        Rowtmp_xp(1) = LaengeSek_xpi.ToString & " Sek."
                                        For j_xpi As Integer = 0 To 14
                                            If FeldFehlerAkt_xpb(j_xpi) = FeldFehlerAlt_xpb(j_xpi) Then
                                                'Kein Flankenwechsel
                                            Else
                                                'Flankenwechsel vorhanden
                                                If j_xpi = 1 Then
                                                    'Fehlende Datens�tze
                                                    If FeldFehlerAkt_xpb(j_xpi) = True Then
                                                        Fehlerspalte_ergaenzen_xpb = True
                                                    End If
                                                End If
                                            End If
                                        Next
                                        If Fehlerspalte_ergaenzen_xpb = True Then
                                            Rowtmp_xp(5) = p_xpi.ToString
                                            Ds_Rohdat_xo.Tables("Auswertung" & setup_xps).Rows.Add(Rowtmp_xp)
                                        End If
                                    End If
                                    'Merker r�cksetzen
                                    For j_xpi As Integer = 0 To 14
                                        FeldFehlerAlt_xpb(j_xpi) = FeldFehlerAkt_xpb(j_xpi)
                                    Next
                                Next
                            End If
                        End If
                    Next p_xpi
                    DatTmp_xpd = StartDatZeit_xpd
                    'SQL-Statement zusammenbauen
                    'Alarme Visu
                    SqlTabelle_xps = "[Meldesystem]"
                    Dim d_xpd As Date = CDate("01.07.2020")
                    'dann die St�rungen...
                    SqlEreignis_xps = " WHERE Time >= "
                    'SqlEreignis_xps &= " * FROM "
                    ''Alarme

                    Dim Sql_Meldnummern_xps As String = String.Empty
                    'Kabienenereignisse

                    Sql_Meldnummern_xps = Sql_Meldnummern_xps & " ([Status] = '-N' OR [Status] ='-G'))"
                    'SqlEreignis_xps &= "[VisAM-MEL]"
                    Dim Sql_xps_ohne_sEmikolon As String = SqlEreignis_xps & DatetoSqlserverString(datzeit_von_xpd) & " AND Time <= " & DatetoSqlserverString(datzeit_bis_xpd) & " AND [Status] Like '-N'"
                    SqlEreignis_xps = SqlEreignis_xps & DatetoSqlserverString(datzeit_von_xpd) & " AND Time < " & DatetoSqlserverString(datzeit_bis_xpd) '& " And (" & Sql_Meldnummern_xps & ") "
                    SqlEreignis_xps = "SELECT i2.[Time],i2.[mSec],i2.[Status],i2.[M_No],i1.[Anzahl_Alarme] ,i2.[Text] FROM (SELECT [M_No],Count(*) As Anzahl_Alarme FROM " & SqlTabelle_xps & " " & Sql_xps_ohne_sEmikolon & " GROUP BY [M_No] ) i1 FULL OUTER JOIN " & SqlTabelle_xps & " i2 on i1.[M_No] = i2.[M_No]" & SqlEreignis_xps & " Order by [Time] ASC"
                    Dim cmd1 As New SqlCommand(SqlEreignis_xps, cn_chargeprot_xbo)
                    Dim da1 As New SqlDataAdapter With {
          .SelectCommand = cmd1
        }
                    da1.Fill(Ds_Rohdat_xo, "Ereignisse" & setup_xps)
                    AnzDsAlarmFehler_xpi = 0
                    If Ds_Rohdat_xo.Tables.Contains("Ereignisse" & setup_xps) Then
                        For Each dr_xp As DataRow In Ds_Rohdat_xo.Tables("Ereignisse" & setup_xps).Rows
                            If CInt(dr_xp.Item("M_No")) >= UntereGrenzeAlarme_xpi And CInt(dr_xp.Item("M_No")) <= ObereeGrenzeAlarme_xpi Then
                                AnzDsAlarmFehler_xpi += 1
                                If n_xpi = 1 Then
                                    AnzDsAlarmFehler_prod_xpi += 1
                                Else

                                    AnzDsAlarmFehler_Setup_xpi += 1
                                End If
                            End If
                            Select Case dr_xp.Item("Status").ToString
                                Case "-N"
                                    dr_xp.Item("Status") = "KOMMT"
                                Case "-G"
                                    dr_xp.Item("Status") = "GEHT"
                                Case "-Q"
                                    dr_xp.Item("Status") = "QUITT"
                            End Select
                        Next
                        Ds_Rohdat_xo.Tables("Chargen").Rows(0).Item(22) = Ds_Rohdat_xo.Tables("Ereignisse" & setup_xps).Rows.Count
                    Else
                        Ds_Rohdat_xo.Tables("Chargen").Rows(0).Item(22) = 0
                    End If

                    Dim SqlWhereEreignis_xps As String = " WHERE [Time] >= " & DatetoSqlserverString(datzeit_von_xpd) & " AND [Time] <= " & DatetoSqlserverString(datzeit_bis_xpd) & " Order by [Time] ASC;"
                    SqlEreignis_xps = "Select * FROM [Ereignisse]"
                    Dim cmd3 As New SqlCommand(SqlEreignis_xps & SqlWhereEreignis_xps, cn_chargeprot_xbo)
                    Dim da3 As New SqlDataAdapter With {
            .SelectCommand = cmd3
          }
                    da3.Fill(Ds_Rohdat_xo, "Ereignisse_vis" & setup_xps)
                    For Each dr_xp As DataRow In Ds_Rohdat_xo.Tables("Ereignisse_vis" & setup_xps).Rows
                        Select Case dr_xp.Item("Status").ToString
                            Case "-N"
                                dr_xp.Item("Status") = "KOMMT"
                            Case "-G"
                                dr_xp.Item("Status") = "GEHT"
                        End Select
                    Next
                Next n_xpi
                'und auch ein Adutrail
                Ds_Rohdat_xo.Tables.Add("AuditTrail")
                'Tabellendefinition �bernehmen:
                For i_xpi = 0 To ds_chartprotmdb_xbo.Tables("AuditTrail").Columns.Count - 1
                    Ds_Rohdat_xo.Tables("AuditTrail").Columns.Add(ds_chartprotmdb_xbo.Tables("AuditTrail").Columns(i_xpi).ColumnName)
                    Ds_Rohdat_xo.Tables("AuditTrail").Columns(i_xpi).DataType = ds_chartprotmdb_xbo.Tables("AuditTrail").Columns(i_xpi).DataType
                Next
                Ds_Rohdat_xo.Tables.Add("AuditTrail_Detail")
                'Tabellendefinition �bernehmen:
                For i_xpi = 0 To ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Columns.Count - 1
                    Ds_Rohdat_xo.Tables("AuditTrail_Detail").Columns.Add(ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Columns(i_xpi).ColumnName)
                    Ds_Rohdat_xo.Tables("AuditTrail_Detail").Columns(i_xpi).DataType = ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Columns(i_xpi).DataType
                Next

                'und neue row's erzeugen
                RowDet_xp = ds_chartprotmdb_xbo.Tables("AuditTrail").Select("Charge Like '" & Charge & "'")
                For Each row As DataRow In RowDet_xp
                    Rowtmp_xp = Ds_Rohdat_xo.Tables("AuditTrail").NewRow
                    For i_xpi = 0 To ds_chartprotmdb_xbo.Tables("AuditTrail").Columns.Count - 1
                        Rowtmp_xp(i_xpi) = row.Item(i_xpi)
                    Next
                    Ds_Rohdat_xo.Tables("AuditTrail").Rows.Add(Rowtmp_xp)
                    'Detail-Tabellen
                    RowDetAudit_xp = ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Select("AudiTrailID = '" & row("AudiTrailID").ToString() & "'")
                    For Each row2 As DataRow In RowDetAudit_xp
                        RowTmpDet_xp = Ds_Rohdat_xo.Tables("AuditTrail_Detail").NewRow
                        For i_xpi = 0 To ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Columns.Count - 1
                            RowTmpDet_xp(i_xpi) = row2.Item(i_xpi)
                        Next
                        Ds_Rohdat_xo.Tables("AuditTrail_Detail").Rows.Add(RowTmpDet_xp)
                    Next
                Next
                If Ds_Rohdat_xo.Tables.Contains("AuditTrail") = True And Ds_Rohdat_xo.Tables.Contains("AuditTrail_Detail") = True Then
                    Ds_Rohdat_xo.Relations.Add("AuditTrail_Deatil",
            Ds_Rohdat_xo.Tables("AuditTrail").Columns("AudiTrailID"),
            Ds_Rohdat_xo.Tables("AuditTrail_Detail").Columns("AudiTrailID"))
                End If
            Else
                'Neue Tabellen "AuditTrail" und "AuditTrail_Detail" im Dataset erzeugen
                If ProtTyp = 2 Then
                    Ds_Rohdat_xo.Tables.Add("AuditTrail")
                    'Tabellendefinition �bernehmen:
                    For i_xpi = 0 To ds_chartprotmdb_xbo.Tables("AuditTrail").Columns.Count - 1
                        Ds_Rohdat_xo.Tables("AuditTrail").Columns.Add(ds_chartprotmdb_xbo.Tables("AuditTrail").Columns(i_xpi).ColumnName)
                        Ds_Rohdat_xo.Tables("AuditTrail").Columns(i_xpi).DataType = ds_chartprotmdb_xbo.Tables("AuditTrail").Columns(i_xpi).DataType
                    Next
                    Ds_Rohdat_xo.Tables.Add("AuditTrail_Detail")
                    'Tabellendefinition �bernehmen:
                    For i_xpi = 0 To ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Columns.Count - 1
                        Ds_Rohdat_xo.Tables("AuditTrail_Detail").Columns.Add(ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Columns(i_xpi).ColumnName)
                        Ds_Rohdat_xo.Tables("AuditTrail_Detail").Columns(i_xpi).DataType = ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Columns(i_xpi).DataType
                    Next

                    'und neue row's erzeugen
                    RowDet_xp = ds_chartprotmdb_xbo.Tables("AuditTrail").Select("Charge Like '" & Charge & "'")
                    For Each row As DataRow In RowDet_xp
                        Rowtmp_xp = Ds_Rohdat_xo.Tables("AuditTrail").NewRow
                        For i_xpi = 0 To ds_chartprotmdb_xbo.Tables("AuditTrail").Columns.Count - 1
                            Rowtmp_xp(i_xpi) = row.Item(i_xpi)
                        Next
                        Ds_Rohdat_xo.Tables("AuditTrail").Rows.Add(Rowtmp_xp)
                        'Detail-Tabellen
                        RowDetAudit_xp = ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Select("AudiTrailID = '" & row("AudiTrailID").ToString() & "'")
                        For Each row2 As DataRow In RowDetAudit_xp
                            RowTmpDet_xp = Ds_Rohdat_xo.Tables("AuditTrail_Detail").NewRow
                            For i_xpi = 0 To ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Columns.Count - 1
                                RowTmpDet_xp(i_xpi) = row2.Item(i_xpi)
                            Next
                            Ds_Rohdat_xo.Tables("AuditTrail_Detail").Rows.Add(RowTmpDet_xp)
                        Next
                    Next
                    If Ds_Rohdat_xo.Tables.Contains("AuditTrail") = True And Ds_Rohdat_xo.Tables.Contains("AuditTrail_Detail") = True Then
                        Ds_Rohdat_xo.Relations.Add("AuditTrail_Deatil",
              Ds_Rohdat_xo.Tables("AuditTrail").Columns("AudiTrailID"),
              Ds_Rohdat_xo.Tables("AuditTrail_Detail").Columns("AudiTrailID"))
                    End If
                Else
                    Rowtmp_xp.Item("Modus") = "CHARGENPROTOKOLL E172 Ereignis"
                    Dim SqlWhereEreignis_xps As String = " WHERE [Time] >= " & DatetoSqlserverString(StartDatZeitsetup_xpd) & " AND [Time] <= " & DatetoSqlserverString(EndDatZeitSetup_xpd) & " Order by [Time] ASC;"
                    Dim SqlWhereEreignis2_xps As String = " WHERE [Time] >= " & DatetoSqlserverString(StartDatZeit_xpd) & " AND [Time] <= " & DatetoSqlserverString(EndDatZeit_xpd) & " Order by [Time] ASC;"
                    SqlEreignis_xps = "Select * FROM [Ereignisse]"
                    Dim cmd As New SqlCommand(SqlEreignis_xps & SqlWhereEreignis_xps, cn_chargeprot_xbo)
                    Dim da As New SqlDataAdapter With {
            .SelectCommand = cmd
          }
                    da.Fill(Ds_Rohdat_xo, "Ereignisse_Setup")
                    For Each dr_xp As DataRow In Ds_Rohdat_xo.Tables("Ereignisse_Setup").Rows

                        Select Case dr_xp.Item("Status").ToString
                            Case "-N"
                                dr_xp.Item("Status") = "KOMMT"
                            Case "-G"
                                dr_xp.Item("Status") = "GEHT"
                        End Select
                    Next
                    'SqlEreignis_xps = "Select * FROM [VisAM-Seg-10]"
                    Dim cmd2 As New SqlCommand(SqlEreignis_xps & SqlWhereEreignis2_xps, cn_chargeprot_xbo)
                    Dim da2 As New SqlDataAdapter With {
            .SelectCommand = cmd2
          }
                    da2.Fill(Ds_Rohdat_xo, "Ereignisse")
                    For Each dr_xp As DataRow In Ds_Rohdat_xo.Tables("Ereignisse").Rows
                        Select Case dr_xp.Item("Status").ToString
                            Case "-N"
                                dr_xp.Item("Status") = "KOMMT"
                            Case "-G"
                                dr_xp.Item("Status") = "GEHT"
                        End Select
                    Next
                End If
            End If
            'Ergebnis der Kurzauswertung ermitteln
            If ProtTyp < 2 Then
                'If AnzDsDatZeitFehler_xpi = 0 And LimitPartikel�berschritten_xpb = False And LimitFlow�berschritten_xpb = False Then
                'NEU Version 1.0.0.1: Fehler bei Kurzauswertung korrigiert
                If AnzDsDatZeitFehler_Setup_xpi = 0 And AnzDsPZ05Fehler_Setup_xpi = 0 And AnzDsPZ5Fehler_Setup_xpi = 0 And AnzDsAlarmFehler_Setup_xpi = 0 Then
                    Kurzauswertung_xps = "Ergebnis: Setup OK"
                Else
                    Kurzauswertung_xps = "Ergebnis: Setup entspricht nicht den Kriterien "
                End If
                If AnzDsDatZeitFehler_prod_xpi = 0 And AnzDsPZ05Fehler_prod_xpi = 0 And AnzDsPZ5Fehler_prod_xpi = 0 And AnzDsAlarmFehler_prod_xpi = 0 Then
                    Kurzauswertung_xps &= " : Produktion OK"
                Else
                    Kurzauswertung_xps &= vbCrLf & "                                                   Produktion entspricht nicht den Kriterien"
                End If
                Kurzauswertung_xps = Now.ToString & ": " & Kurzauswertung_xps


                'Date Tabellen und Datenbankfeld Kurzauswertung ab
                ds_chartprotmdb_xbo.Tables("Chargen").PrimaryKey = New DataColumn() {ds_chartprotmdb_xbo.Tables("Chargen").Columns("Auftragsnummer")}
                Dim drCurrent As DataRow = ds_chartprotmdb_xbo.Tables("Chargen").Rows.Find(Charge)
                drCurrent.BeginEdit()
                drCurrent("Kurzauswertung") = Kurzauswertung_xps
                drCurrent.EndEdit()
                'Date tempor�rtabelle f�r View ab
                Ds_Rohdat_xo.Tables("Chargen").Rows(0).Item(16) = Kurzauswertung_xps

                'Erstelle automatisch Database insert und update befehle f�r die Tabelle Chargen
                Dim objCommandBuilder As New SqlCommandBuilder(Da_chartprot_xbo)
                Try
                    Da_chartprot_xbo.Update(ds_chartprotmdb_xbo, "Chargen")
                Catch ex As Exception
                    If Err.Number = 5 Then
                        MsgBox("Der Datensatz ist von einem anderen User ge�ndert worden." & vbCrLf & "Bitte schliessen Sie das Protokoll Druckenfenster und rufen Sie das Fenster anschliessend neu auf.")
                    Else
                        MsgBox("Laufzeitfehler Nr. " & Err.Number.ToString & ": " & Err.Description)
                    End If
                    'Aktualisiere Datenadapter, damit der grid wieder stimmig ist
                    ds_chartprotmdb_xbo.Tables("Chargen").Clear()
                    Da_chartprot_xbo = New SqlDataAdapter("SELECT * FROM [Chargen];", cn_chargeprot_xbo) '[AuditTrail],[AuditTrail_Detail],,[Benutzer_AuditTrail],[LastDownload]
                    Da_chartprot_xbo.Fill(ds_chartprotmdb_xbo, "Chargen")

                    Return 0
                End Try
                If aufruf_form_xos = "Chargedetail" Then
                    Frm_chrg_prot_detail.tb_kurzauswertung.Text = Kurzauswertung_xps
                End If
            End If
        Catch ex As Exception
            MsgBox("Allgemeiner Laufzeitfehler Nr. " & Err.Number.ToString & ": " & Err.Description)
            Return 0
        End Try

        'XML-Schema wird nur zur Entwicklung der Reports ben�tigt; muss in der Laufzeit nicht enthalten sein.
        'Ds_Rohdat_xo.WriteXmlSchema(Application.StartupPath & "\Datarohset.xml")
        Return -1
    End Function

    Public Function Generiere_pdf_fob() As Boolean

    Try
      ds_chartprotmdb_xbo.Tables("Chargen").Clear()
      Da_chartprot_xbo = New SqlDataAdapter("SELECT * FROM [Chargen];", cn_chargeprot_xbo) '[AuditTrail],[AuditTrail_Detail],,[Benutzer_AuditTrail],[LastDownload]
      Da_chartprot_xbo.Fill(ds_chartprotmdb_xbo, "Chargen")

      Dim Datum As DateTime = Now
      Dim DatZeitbis_xps As String = String.Empty
      DatZeitbis_xps = Format(Datum, "yyyy") & "-"
      DatZeitbis_xps &= Format(Datum, "MM") & "-"
      DatZeitbis_xps &= Format(Datum, "dd")

      DatZeitbis_xps &= " " & Format(Datum, "HH:mm:ss")
      DatZeitbis_xps = "#" & DatZeitbis_xps & "#"
      Dim DatZeitvon_xps As String = String.Empty
      '20070911 00:00:00'
      DatZeitvon_xps = Format(Datum.AddDays(-6), "yyyy") & "-"
      DatZeitvon_xps &= Format(Datum.AddDays(-6), "MM") & "-"
      DatZeitvon_xps &= Format(Datum.AddDays(-6), "dd")

      DatZeitvon_xps &= " " & Format(Datum.AddDays(-6), "HH:mm:ss")
      DatZeitvon_xps = "#" & DatZeitvon_xps & "#"
      Dim verzeichnis_xps As String = String.Empty
      If modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString() <> String.Empty Then
        If System.IO.Directory.Exists(modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString()) Then
          Dim selectdr As DataRow() = ds_chartprotmdb_xbo.Tables("Chargen").Select("[EndZeit] >= " & DatZeitvon_xps & " AND [EndZeit] <= " & DatZeitbis_xps)
          If selectdr.Length > 0 Then
            If modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString().EndsWith("\") Then
              verzeichnis_xps = modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString()
            Else
              verzeichnis_xps = modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString() & "\"
            End If
            'erzeuge neue Dateienfalls nicht vorhanden
            For Each rowcharge As DataRow In selectdr
              Dim pdfDatei_xps As String = FileSystem.Dir(verzeichnis_xps & rowcharge("Auftragsnummer").ToString & "_" & "*.pdf")
              If pdfDatei_xps <> String.Empty Then
                Do While pdfDatei_xps <> String.Empty
                  If (Strings.Left(pdfDatei_xps, pdfDatei_xps.Length - 24)) = rowcharge("Auftragsnummer").ToString Then 'Datei  existiert
                    Exit Do
                  Else
                    'neue datei anlegen
                    Dim DatZeit_xps As String = String.Empty
                    DatZeit_xps = "_" & Format(Datum, "yyyy") & "_"
                    DatZeit_xps &= Format(Datum, "MM") & "_"
                    DatZeit_xps &= Format(Datum, "dd")

                    DatZeit_xps &= "_" & Format(Datum, "HH_mm_ss")
                                        If Frm_Print_Combit.Erzeuge_pdfs_fob(rowcharge("Auftragsnummer").ToString, verzeichnis_xps & rowcharge("Auftragsnummer").ToString & DatZeit_xps & ".pdf", rowcharge("Chargennummer").ToString, 1) = True Then
                                            ' Erzeuge pdf
                                        End If
                                    End If
                                    pdfDatei_xps = Dir()
                Loop
              Else
                Dim DatZeit_xps As String = String.Empty
                DatZeit_xps = "_" & Format(Datum, "yyyy") & "_"
                DatZeit_xps &= Format(Datum, "MM") & "_"
                DatZeit_xps &= Format(Datum, "dd")

                DatZeit_xps &= "_" & Format(Datum, "HH_mm_ss")
                                If Frm_Print_Combit.Erzeuge_pdfs_fob(rowcharge("Auftragsnummer").ToString, verzeichnis_xps & rowcharge("Auftragsnummer").ToString & DatZeit_xps & ".pdf", rowcharge("Chargennummer").ToString, 1) = True Then
                                    'Erzeuge pdf

                                End If
                            End If
            Next
          End If
        End If
      End If
    Catch ex As Exception
      Fehlerupdate_xob = True
      'Application.Exit()
    End Try

    Return True
  End Function

End Module