<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class startfenster_nycomed_frm
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.DataGridView1 = New System.Windows.Forms.DataGridView()
    Me.cmd_neu = New System.Windows.Forms.Button()
    Me.cmd_detail = New System.Windows.Forms.Button()
    Me.cmd_filter = New System.Windows.Forms.Button()
    Me.tb_suchkriterium5 = New System.Windows.Forms.TextBox()
    Me.Cb_operator5 = New System.Windows.Forms.ComboBox()
    Me.Cb_suchfeld5 = New System.Windows.Forms.ComboBox()
    Me.Cb_andor4 = New System.Windows.Forms.ComboBox()
    Me.tb_suchkriterium4 = New System.Windows.Forms.TextBox()
    Me.Cb_operator4 = New System.Windows.Forms.ComboBox()
    Me.Cb_suchfeld4 = New System.Windows.Forms.ComboBox()
    Me.Cb_andor3 = New System.Windows.Forms.ComboBox()
    Me.tb_suchkriterium3 = New System.Windows.Forms.TextBox()
    Me.Cb_operator3 = New System.Windows.Forms.ComboBox()
    Me.Cb_suchfeld3 = New System.Windows.Forms.ComboBox()
    Me.Cb_andor2 = New System.Windows.Forms.ComboBox()
    Me.tb_suchkriterium2 = New System.Windows.Forms.TextBox()
    Me.Cb_operator2 = New System.Windows.Forms.ComboBox()
    Me.Cb_suchfeld2 = New System.Windows.Forms.ComboBox()
    Me.Cb_andor1 = New System.Windows.Forms.ComboBox()
    Me.tb_suchkriterium1 = New System.Windows.Forms.TextBox()
    Me.lbl_suchkriterium = New System.Windows.Forms.Label()
    Me.Cb_operator1 = New System.Windows.Forms.ComboBox()
    Me.lbl_suchvergleichsoperator = New System.Windows.Forms.Label()
    Me.lbl_suchfeld = New System.Windows.Forms.Label()
    Me.Cb_suchfeld1 = New System.Windows.Forms.ComboBox()
    Me.cmd_filter_aufheben = New System.Windows.Forms.Button()
    Me.lbl_gefiltert = New System.Windows.Forms.Label()
    Me.GroupBox1 = New System.Windows.Forms.GroupBox()
    Me.tb_app_version = New System.Windows.Forms.TextBox()
    Me.cmd_close = New System.Windows.Forms.Button()
    Me.cmd_aktualisieren = New System.Windows.Forms.Button()
    Me.Cmd_print = New System.Windows.Forms.Button()
    Me.Lb_Filelist = New System.Windows.Forms.ListBox()
    Me.Lbl_filelist = New System.Windows.Forms.Label()
    CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.GroupBox1.SuspendLayout()
    Me.SuspendLayout()
    '
    'DataGridView1
    '
    Me.DataGridView1.AllowUserToAddRows = False
    Me.DataGridView1.AllowUserToDeleteRows = False
    Me.DataGridView1.AllowUserToOrderColumns = True
    Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
    Me.DataGridView1.Location = New System.Drawing.Point(12, 91)
    Me.DataGridView1.MultiSelect = False
    Me.DataGridView1.Name = "DataGridView1"
    Me.DataGridView1.ReadOnly = True
    Me.DataGridView1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
    Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
    Me.DataGridView1.Size = New System.Drawing.Size(1208, 572)
    Me.DataGridView1.TabIndex = 1
    '
    'cmd_neu
    '
    Me.cmd_neu.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.cmd_neu.Location = New System.Drawing.Point(12, 38)
    Me.cmd_neu.Name = "cmd_neu"
    Me.cmd_neu.Size = New System.Drawing.Size(100, 31)
    Me.cmd_neu.TabIndex = 2
    Me.cmd_neu.Text = "&Neu"
    Me.cmd_neu.UseVisualStyleBackColor = True
    '
    'cmd_detail
    '
    Me.cmd_detail.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.cmd_detail.Location = New System.Drawing.Point(118, 38)
    Me.cmd_detail.Name = "cmd_detail"
    Me.cmd_detail.Size = New System.Drawing.Size(125, 31)
    Me.cmd_detail.TabIndex = 3
    Me.cmd_detail.Text = "&Charge-Detail"
    Me.cmd_detail.UseVisualStyleBackColor = True
    '
    'cmd_filter
    '
    Me.cmd_filter.Location = New System.Drawing.Point(551, 69)
    Me.cmd_filter.Name = "cmd_filter"
    Me.cmd_filter.Size = New System.Drawing.Size(104, 31)
    Me.cmd_filter.TabIndex = 6
    Me.cmd_filter.Text = "&Filter anwenden"
    Me.cmd_filter.UseVisualStyleBackColor = True
    '
    'tb_suchkriterium5
    '
    Me.tb_suchkriterium5.Location = New System.Drawing.Point(373, 190)
    Me.tb_suchkriterium5.Name = "tb_suchkriterium5"
    Me.tb_suchkriterium5.Size = New System.Drawing.Size(148, 20)
    Me.tb_suchkriterium5.TabIndex = 43
    '
    'Cb_operator5
    '
    Me.Cb_operator5.FormattingEnabled = True
    Me.Cb_operator5.Location = New System.Drawing.Point(269, 189)
    Me.Cb_operator5.Name = "Cb_operator5"
    Me.Cb_operator5.Size = New System.Drawing.Size(70, 21)
    Me.Cb_operator5.TabIndex = 42
    '
    'Cb_suchfeld5
    '
    Me.Cb_suchfeld5.FormattingEnabled = True
    Me.Cb_suchfeld5.Location = New System.Drawing.Point(93, 189)
    Me.Cb_suchfeld5.Name = "Cb_suchfeld5"
    Me.Cb_suchfeld5.Size = New System.Drawing.Size(148, 21)
    Me.Cb_suchfeld5.TabIndex = 41
    '
    'Cb_andor4
    '
    Me.Cb_andor4.FormattingEnabled = True
    Me.Cb_andor4.Items.AddRange(New Object() {"AND", "OR"})
    Me.Cb_andor4.Location = New System.Drawing.Point(16, 189)
    Me.Cb_andor4.Name = "Cb_andor4"
    Me.Cb_andor4.Size = New System.Drawing.Size(70, 21)
    Me.Cb_andor4.TabIndex = 40
    '
    'tb_suchkriterium4
    '
    Me.tb_suchkriterium4.Location = New System.Drawing.Point(373, 152)
    Me.tb_suchkriterium4.Name = "tb_suchkriterium4"
    Me.tb_suchkriterium4.Size = New System.Drawing.Size(148, 20)
    Me.tb_suchkriterium4.TabIndex = 39
    '
    'Cb_operator4
    '
    Me.Cb_operator4.FormattingEnabled = True
    Me.Cb_operator4.Location = New System.Drawing.Point(269, 151)
    Me.Cb_operator4.Name = "Cb_operator4"
    Me.Cb_operator4.Size = New System.Drawing.Size(70, 21)
    Me.Cb_operator4.TabIndex = 38
    '
    'Cb_suchfeld4
    '
    Me.Cb_suchfeld4.FormattingEnabled = True
    Me.Cb_suchfeld4.Location = New System.Drawing.Point(93, 151)
    Me.Cb_suchfeld4.Name = "Cb_suchfeld4"
    Me.Cb_suchfeld4.Size = New System.Drawing.Size(148, 21)
    Me.Cb_suchfeld4.TabIndex = 37
    '
    'Cb_andor3
    '
    Me.Cb_andor3.FormattingEnabled = True
    Me.Cb_andor3.Items.AddRange(New Object() {"AND", "OR"})
    Me.Cb_andor3.Location = New System.Drawing.Point(16, 151)
    Me.Cb_andor3.Name = "Cb_andor3"
    Me.Cb_andor3.Size = New System.Drawing.Size(70, 21)
    Me.Cb_andor3.TabIndex = 36
    '
    'tb_suchkriterium3
    '
    Me.tb_suchkriterium3.Location = New System.Drawing.Point(373, 115)
    Me.tb_suchkriterium3.Name = "tb_suchkriterium3"
    Me.tb_suchkriterium3.Size = New System.Drawing.Size(148, 20)
    Me.tb_suchkriterium3.TabIndex = 35
    '
    'Cb_operator3
    '
    Me.Cb_operator3.FormattingEnabled = True
    Me.Cb_operator3.Location = New System.Drawing.Point(269, 114)
    Me.Cb_operator3.Name = "Cb_operator3"
    Me.Cb_operator3.Size = New System.Drawing.Size(70, 21)
    Me.Cb_operator3.TabIndex = 34
    '
    'Cb_suchfeld3
    '
    Me.Cb_suchfeld3.FormattingEnabled = True
    Me.Cb_suchfeld3.Location = New System.Drawing.Point(93, 114)
    Me.Cb_suchfeld3.Name = "Cb_suchfeld3"
    Me.Cb_suchfeld3.Size = New System.Drawing.Size(148, 21)
    Me.Cb_suchfeld3.TabIndex = 33
    '
    'Cb_andor2
    '
    Me.Cb_andor2.FormattingEnabled = True
    Me.Cb_andor2.Items.AddRange(New Object() {"AND", "OR"})
    Me.Cb_andor2.Location = New System.Drawing.Point(16, 114)
    Me.Cb_andor2.Name = "Cb_andor2"
    Me.Cb_andor2.Size = New System.Drawing.Size(70, 21)
    Me.Cb_andor2.TabIndex = 32
    '
    'tb_suchkriterium2
    '
    Me.tb_suchkriterium2.Location = New System.Drawing.Point(373, 79)
    Me.tb_suchkriterium2.Name = "tb_suchkriterium2"
    Me.tb_suchkriterium2.Size = New System.Drawing.Size(148, 20)
    Me.tb_suchkriterium2.TabIndex = 31
    '
    'Cb_operator2
    '
    Me.Cb_operator2.FormattingEnabled = True
    Me.Cb_operator2.Location = New System.Drawing.Point(269, 78)
    Me.Cb_operator2.Name = "Cb_operator2"
    Me.Cb_operator2.Size = New System.Drawing.Size(70, 21)
    Me.Cb_operator2.TabIndex = 30
    '
    'Cb_suchfeld2
    '
    Me.Cb_suchfeld2.FormattingEnabled = True
    Me.Cb_suchfeld2.Location = New System.Drawing.Point(93, 78)
    Me.Cb_suchfeld2.Name = "Cb_suchfeld2"
    Me.Cb_suchfeld2.Size = New System.Drawing.Size(148, 21)
    Me.Cb_suchfeld2.TabIndex = 29
    '
    'Cb_andor1
    '
    Me.Cb_andor1.FormattingEnabled = True
    Me.Cb_andor1.Items.AddRange(New Object() {"AND", "OR"})
    Me.Cb_andor1.Location = New System.Drawing.Point(16, 78)
    Me.Cb_andor1.Name = "Cb_andor1"
    Me.Cb_andor1.Size = New System.Drawing.Size(70, 21)
    Me.Cb_andor1.TabIndex = 28
    '
    'tb_suchkriterium1
    '
    Me.tb_suchkriterium1.Location = New System.Drawing.Point(373, 42)
    Me.tb_suchkriterium1.Name = "tb_suchkriterium1"
    Me.tb_suchkriterium1.Size = New System.Drawing.Size(148, 20)
    Me.tb_suchkriterium1.TabIndex = 27
    '
    'lbl_suchkriterium
    '
    Me.lbl_suchkriterium.AutoSize = True
    Me.lbl_suchkriterium.Location = New System.Drawing.Point(380, 16)
    Me.lbl_suchkriterium.Name = "lbl_suchkriterium"
    Me.lbl_suchkriterium.Size = New System.Drawing.Size(68, 13)
    Me.lbl_suchkriterium.TabIndex = 26
    Me.lbl_suchkriterium.Text = "Suchkriteium"
    '
    'Cb_operator1
    '
    Me.Cb_operator1.FormattingEnabled = True
    Me.Cb_operator1.Location = New System.Drawing.Point(269, 41)
    Me.Cb_operator1.Name = "Cb_operator1"
    Me.Cb_operator1.Size = New System.Drawing.Size(70, 21)
    Me.Cb_operator1.TabIndex = 25
    '
    'lbl_suchvergleichsoperator
    '
    Me.lbl_suchvergleichsoperator.AutoSize = True
    Me.lbl_suchvergleichsoperator.Location = New System.Drawing.Point(268, 16)
    Me.lbl_suchvergleichsoperator.Name = "lbl_suchvergleichsoperator"
    Me.lbl_suchvergleichsoperator.Size = New System.Drawing.Size(71, 13)
    Me.lbl_suchvergleichsoperator.TabIndex = 24
    Me.lbl_suchvergleichsoperator.Text = "Suchoperator"
    '
    'lbl_suchfeld
    '
    Me.lbl_suchfeld.AutoSize = True
    Me.lbl_suchfeld.Location = New System.Drawing.Point(90, 16)
    Me.lbl_suchfeld.Name = "lbl_suchfeld"
    Me.lbl_suchfeld.Size = New System.Drawing.Size(55, 13)
    Me.lbl_suchfeld.TabIndex = 23
    Me.lbl_suchfeld.Text = "SuchFeld:"
    '
    'Cb_suchfeld1
    '
    Me.Cb_suchfeld1.FormattingEnabled = True
    Me.Cb_suchfeld1.Location = New System.Drawing.Point(93, 41)
    Me.Cb_suchfeld1.Name = "Cb_suchfeld1"
    Me.Cb_suchfeld1.Size = New System.Drawing.Size(148, 21)
    Me.Cb_suchfeld1.TabIndex = 22
    '
    'cmd_filter_aufheben
    '
    Me.cmd_filter_aufheben.Location = New System.Drawing.Point(551, 106)
    Me.cmd_filter_aufheben.Name = "cmd_filter_aufheben"
    Me.cmd_filter_aufheben.Size = New System.Drawing.Size(104, 31)
    Me.cmd_filter_aufheben.TabIndex = 44
    Me.cmd_filter_aufheben.Text = "Filter &aufheben"
    Me.cmd_filter_aufheben.UseVisualStyleBackColor = True
    '
    'lbl_gefiltert
    '
    Me.lbl_gefiltert.AutoSize = True
    Me.lbl_gefiltert.BackColor = System.Drawing.SystemColors.ButtonHighlight
    Me.lbl_gefiltert.Location = New System.Drawing.Point(650, 676)
    Me.lbl_gefiltert.Name = "lbl_gefiltert"
    Me.lbl_gefiltert.Size = New System.Drawing.Size(43, 13)
    Me.lbl_gefiltert.TabIndex = 45
    Me.lbl_gefiltert.Text = "Gefiltert"
    Me.lbl_gefiltert.Visible = False
    '
    'GroupBox1
    '
    Me.GroupBox1.Controls.Add(Me.tb_suchkriterium5)
    Me.GroupBox1.Controls.Add(Me.Cb_operator5)
    Me.GroupBox1.Controls.Add(Me.cmd_filter_aufheben)
    Me.GroupBox1.Controls.Add(Me.Cb_suchfeld5)
    Me.GroupBox1.Controls.Add(Me.cmd_filter)
    Me.GroupBox1.Controls.Add(Me.Cb_andor4)
    Me.GroupBox1.Controls.Add(Me.tb_suchkriterium4)
    Me.GroupBox1.Controls.Add(Me.Cb_operator4)
    Me.GroupBox1.Controls.Add(Me.Cb_suchfeld4)
    Me.GroupBox1.Controls.Add(Me.Cb_andor3)
    Me.GroupBox1.Controls.Add(Me.tb_suchkriterium3)
    Me.GroupBox1.Controls.Add(Me.Cb_operator3)
    Me.GroupBox1.Controls.Add(Me.Cb_suchfeld3)
    Me.GroupBox1.Controls.Add(Me.Cb_andor2)
    Me.GroupBox1.Controls.Add(Me.tb_suchkriterium2)
    Me.GroupBox1.Controls.Add(Me.Cb_operator2)
    Me.GroupBox1.Controls.Add(Me.Cb_suchfeld2)
    Me.GroupBox1.Controls.Add(Me.Cb_andor1)
    Me.GroupBox1.Controls.Add(Me.tb_suchkriterium1)
    Me.GroupBox1.Controls.Add(Me.lbl_suchkriterium)
    Me.GroupBox1.Controls.Add(Me.Cb_operator1)
    Me.GroupBox1.Controls.Add(Me.lbl_suchvergleichsoperator)
    Me.GroupBox1.Controls.Add(Me.lbl_suchfeld)
    Me.GroupBox1.Controls.Add(Me.Cb_suchfeld1)
    Me.GroupBox1.Location = New System.Drawing.Point(12, 692)
    Me.GroupBox1.Name = "GroupBox1"
    Me.GroupBox1.Size = New System.Drawing.Size(681, 228)
    Me.GroupBox1.TabIndex = 46
    Me.GroupBox1.TabStop = False
    Me.GroupBox1.Text = "Filter"
    '
    'tb_app_version
    '
    Me.tb_app_version.BorderStyle = System.Windows.Forms.BorderStyle.None
    Me.tb_app_version.Enabled = False
    Me.tb_app_version.Location = New System.Drawing.Point(1131, 27)
    Me.tb_app_version.Name = "tb_app_version"
    Me.tb_app_version.ReadOnly = True
    Me.tb_app_version.Size = New System.Drawing.Size(102, 13)
    Me.tb_app_version.TabIndex = 47
    '
    'cmd_close
    '
    Me.cmd_close.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.cmd_close.Location = New System.Drawing.Point(485, 38)
    Me.cmd_close.Name = "cmd_close"
    Me.cmd_close.Size = New System.Drawing.Size(112, 31)
    Me.cmd_close.TabIndex = 48
    Me.cmd_close.Text = "&Beenden"
    Me.cmd_close.UseVisualStyleBackColor = True
    '
    'cmd_aktualisieren
    '
    Me.cmd_aktualisieren.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.cmd_aktualisieren.Location = New System.Drawing.Point(367, 38)
    Me.cmd_aktualisieren.Name = "cmd_aktualisieren"
    Me.cmd_aktualisieren.Size = New System.Drawing.Size(112, 31)
    Me.cmd_aktualisieren.TabIndex = 49
    Me.cmd_aktualisieren.Text = " &Aktualisieren"
    Me.cmd_aktualisieren.UseVisualStyleBackColor = True
    '
    'Cmd_print
    '
    Me.Cmd_print.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.Cmd_print.Location = New System.Drawing.Point(249, 38)
    Me.Cmd_print.Name = "Cmd_print"
    Me.Cmd_print.Size = New System.Drawing.Size(112, 31)
    Me.Cmd_print.TabIndex = 50
    Me.Cmd_print.Text = "&Drucken"
    Me.Cmd_print.UseVisualStyleBackColor = True
    '
    'Lb_Filelist
    '
    Me.Lb_Filelist.FormattingEnabled = True
    Me.Lb_Filelist.Location = New System.Drawing.Point(877, 692)
    Me.Lb_Filelist.Name = "Lb_Filelist"
    Me.Lb_Filelist.Size = New System.Drawing.Size(343, 225)
    Me.Lb_Filelist.TabIndex = 51
    '
    'Lbl_filelist
    '
    Me.Lbl_filelist.AutoSize = True
    Me.Lbl_filelist.Location = New System.Drawing.Point(759, 692)
    Me.Lbl_filelist.Name = "Lbl_filelist"
    Me.Lbl_filelist.Size = New System.Drawing.Size(112, 13)
    Me.Lbl_filelist.TabIndex = 54
    Me.Lbl_filelist.Text = "erzeugte pdf Datei(en)"
    Me.Lbl_filelist.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
    '
    'startfenster_nycomed_frm
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.AutoSize = True
    Me.ClientSize = New System.Drawing.Size(1245, 943)
    Me.ControlBox = False
    Me.Controls.Add(Me.Lbl_filelist)
    Me.Controls.Add(Me.Lb_Filelist)
    Me.Controls.Add(Me.Cmd_print)
    Me.Controls.Add(Me.cmd_aktualisieren)
    Me.Controls.Add(Me.cmd_close)
    Me.Controls.Add(Me.tb_app_version)
    Me.Controls.Add(Me.GroupBox1)
    Me.Controls.Add(Me.lbl_gefiltert)
    Me.Controls.Add(Me.cmd_detail)
    Me.Controls.Add(Me.cmd_neu)
    Me.Controls.Add(Me.DataGridView1)
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "startfenster_nycomed_frm"
    Me.Text = "Startfenster"
    Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
    CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.GroupBox1.ResumeLayout(False)
    Me.GroupBox1.PerformLayout()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents cmd_neu As System.Windows.Forms.Button
  Friend WithEvents cmd_detail As System.Windows.Forms.Button
  Friend WithEvents cmd_filter As System.Windows.Forms.Button
  Friend WithEvents tb_suchkriterium5 As System.Windows.Forms.TextBox
  Friend WithEvents Cb_operator5 As System.Windows.Forms.ComboBox
  Friend WithEvents Cb_suchfeld5 As System.Windows.Forms.ComboBox
  Friend WithEvents Cb_andor4 As System.Windows.Forms.ComboBox
  Friend WithEvents tb_suchkriterium4 As System.Windows.Forms.TextBox
  Friend WithEvents Cb_operator4 As System.Windows.Forms.ComboBox
  Friend WithEvents Cb_suchfeld4 As System.Windows.Forms.ComboBox
  Friend WithEvents Cb_andor3 As System.Windows.Forms.ComboBox
  Friend WithEvents tb_suchkriterium3 As System.Windows.Forms.TextBox
  Friend WithEvents Cb_operator3 As System.Windows.Forms.ComboBox
  Friend WithEvents Cb_suchfeld3 As System.Windows.Forms.ComboBox
  Friend WithEvents Cb_andor2 As System.Windows.Forms.ComboBox
  Friend WithEvents tb_suchkriterium2 As System.Windows.Forms.TextBox
  Friend WithEvents Cb_operator2 As System.Windows.Forms.ComboBox
  Friend WithEvents Cb_suchfeld2 As System.Windows.Forms.ComboBox
  Friend WithEvents Cb_andor1 As System.Windows.Forms.ComboBox
  Friend WithEvents tb_suchkriterium1 As System.Windows.Forms.TextBox
  Friend WithEvents lbl_suchkriterium As System.Windows.Forms.Label
  Friend WithEvents Cb_operator1 As System.Windows.Forms.ComboBox
  Friend WithEvents lbl_suchvergleichsoperator As System.Windows.Forms.Label
  Friend WithEvents lbl_suchfeld As System.Windows.Forms.Label
  Friend WithEvents Cb_suchfeld1 As System.Windows.Forms.ComboBox
  Friend WithEvents cmd_filter_aufheben As System.Windows.Forms.Button
  Friend WithEvents lbl_gefiltert As System.Windows.Forms.Label
  Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
  Friend WithEvents tb_app_version As System.Windows.Forms.TextBox
  Friend WithEvents cmd_close As System.Windows.Forms.Button
  Friend WithEvents cmd_aktualisieren As System.Windows.Forms.Button
  Friend WithEvents Cmd_print As Button
  Public WithEvents DataGridView1 As DataGridView
  Friend WithEvents Lb_Filelist As ListBox
  Friend WithEvents Lbl_filelist As Label
End Class
