Imports System.Data.SqlClient

Public Class Mdimain

  Private Sub Mdimain_Closing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
    'Schliesse Applikation
    If Rueckgabewert_userlogin_xoi > 1 And Fehlerupdate_xob = False Then
      If (MessageBox.Show("Wollen Sie das Programm beenden?" _
     , "Programm beenden", MessageBoxButtons.YesNo,
    MessageBoxIcon.Question)) = Windows.Forms.DialogResult.No Then
        e.Cancel = True
      End If
    End If
  End Sub

  Private Sub Mdimain_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    'Dim i As Integer
    'For i = 0 To Environment.GetCommandLineArgs().Length - 1
    '  MsgBox(Environment.GetCommandLineArgs(i))
    'Next i

    'Lade ini Datei falls vorhanden, ansonsten beende Programm
    If FileExists(Application.StartupPath & "\konfiguration.xml") = True Then
      ds_konfiguration.ReadXml(Application.StartupPath & "\konfiguration.xml", XmlReadMode.Auto)
    Else
      MsgBox("Die Konfigurationsdatei konfiguration.xml konnte nicht im Programmverzeichnis gefunden werden.")
      Application.Exit()
    End If
    Programmstart_xob = True
    Try
      If modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("LDAP_Server").ToString = String.Empty Then
        MsgBox("Es konnte kein LDAP Server in der Konfigurationsdatei konfiguration.xml gefunden werden. Das Programm wird beendet!", MsgBoxStyle.Critical, "Anwenderhonweis")
        Application.Exit()
      End If
    Catch ex As Exception

    End Try
    Try
      If modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("ChrgProt_UserGroup").ToString = String.Empty Then
        MsgBox("Es konnte keine Benutzergruppe in der Konfigurationsdatei konfiguration.xml gefunden werden. Das Programm wird beendet!", MsgBoxStyle.Critical, "Anwenderhonweis")
        Application.Exit()
      End If
    Catch ex As Exception

    End Try
    Try
      anonymous_xpi = Integer.Parse(modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("testmodus").ToString)
    Catch ex As Exception

    End Try
        Try
            Zeitintervall_Charge_xoi = Integer.Parse(modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("Zeitintervall_Charge").ToString)
        Catch ex As Exception
            Zeitintervall_Charge_xoi = 61

        End Try
        Linienbeschreibung_xos(0) = "0"
        Linienbeschreibung_xos(1) = "1"
        Linienbeschreibung_xos(2) = "2"
    Linienbeschreibung_xos(3) = "3"
    Linienbeschreibung_xos(4) = "4"
    'Falls Chargenprotokollierungsdatei vorhanden, lade dataset und ermittle Datum der letzen erfolgreichen Protokollabholung
    Dim ConStr_xps As String = sqlserver1_xos
    'Name des SQL-Servers hinzuf�gen
    ConStr_xps = ConStr_xps & modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("sqlserver").ToString
    'Name der SQL-Datenbank hinzuf�gen
    ConStr_xps = ConStr_xps & sqlserver2_xos & modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("sqldbname").ToString
        'user und pw hinzuf�gen
        ConStr_xps = ConStr_xps & sqlserver3_xos & "Connection Timeout=90"
        cn_chargeprot_xbo = New SqlConnection(ConStr_xps)

    'Falls Chargenprotokollierungsdatei vorhanden, lade dataset und ermittle Datum der letzen erfolgreichen Protokollabholung

    Try

      cn_chargeprot_xbo.Open() 'benutzer
      Da_chartprot_xbo = New SqlDataAdapter("SELECT * FROM [Chargen];", cn_chargeprot_xbo) '[AuditTrail],[AuditTrail_Detail],,[Benutzer_AuditTrail],[LastDownload]
      Da_chartprot_xbo.Fill(ds_chartprotmdb_xbo, "Chargen")
      Da_audittrail_xbo = New SqlDataAdapter("SELECT * FROM [AuditTrail_Charge];", cn_chargeprot_xbo) ',[AuditTrail_Detail],,[Benutzer_AuditTrail],[LastDownload]
      Da_audittrail_xbo.Fill(ds_chartprotmdb_xbo, "AuditTrail")
      Da_audittrail_detail_xbo = New SqlDataAdapter("SELECT * FROM [AuditTrail_Detail];", cn_chargeprot_xbo) ',,,[Benutzer_AuditTrail],[LastDownload]
      Da_audittrail_detail_xbo.Fill(ds_chartprotmdb_xbo, "AuditTrail_Detail")
    Catch ex As Exception
      MsgBox("Es ist ein Problem bei der Verarbeitung der ChrgProt.mdb aufgetreten!" & vbCrLf & vbCrLf & ex.ToString)
      Application.Exit()
    End Try
    Dim Vergleichstring_xps As String = "--now"
    Try
      If String.Compare(Vergleichstring_xps, Environment.GetCommandLineArgs(1)) = 0 Then
        Generiere_pdf_fob()
      End If
    Catch ex As Exception
      'Kein Aufrufparameter
    End Try
    'Me.Enabled = False
    ' Neue Instanz der DialogForm frmLoginDialog erstellen
    If User_Ckeck() < 1 Then
      Application.Exit()
    End If
    Me.Height = 985
    Me.Width = 1270
    Dim mdichild As New startfenster_nycomed_frm With {
      .MdiParent = Me
    }
    mdichild.Show()
    Programmstart_xob = False
  End Sub

  Public Function User_Ckeck() As Integer
    Dim LoginDlg As New LoginForm1

    If LoginDlg Is Nothing Then
      ' Neue Instanz der Klasse clsLoginData erstellen.
      ' Diese Klasse dient zur �bergabe der Logindaten
      ' von frm LoginDialog zum Aufrufer dieser Dialogform
      LoginDlg = New LoginForm1
    End If

    With LoginDlg
      ' Verweis auf LD an die LoginDialogForm �bergeben

      ' LoginDialogForm anzeigen
      .ShowDialog(Me)
    End With
    Return Rueckgabewert_userlogin_xoi
  End Function
  Public Function Decrypt_password_fos(ByVal encryptetdPasswd_xps As String) As String
    Dim oAesProvider_xpo As New Security.Cryptography.RijndaelManaged

    ' Das 'Salz' wird verwendet um das Passwort zu 'w�rzen'. Es m�ssen
    ' hier mindestens 8 Bytes angegeben werden die einen zus�tzlich
    ' Parameter zur Berechnung des Schl�ssels darstellen. Nur wer das
    ' richtige Passwort und das verwendete Salz kennt, kann die Daten
    ' entschl�sseln.
    Dim btSalt_xpb() As Byte = New Byte() {1, 2, 3, 4, 5, 6, 7, 8}

    Dim oKeyGenerator_xpo As New Security.Cryptography.Rfc2898DeriveBytes("DiesisteineurogardProgrammgeschriebenvonPedro", btSalt_xpb)

    ' Durch die Key und IV (Initialisation vector) Eigenschaften wird
    ' der Algorithmus initialisiert:
    oAesProvider_xpo.Key = oKeyGenerator_xpo.GetBytes(oAesProvider_xpo.Key.Length)
    oAesProvider_xpo.IV = oKeyGenerator_xpo.GetBytes(oAesProvider_xpo.IV.Length)
    'Stream in dem entschl�+sselt wird
    Dim ms_xpo As New IO.MemoryStream
    'Verschl�sselungsstrom
    Dim cs_xpo As New Security.Cryptography.CryptoStream(ms_xpo,
        oAesProvider_xpo.CreateDecryptor,
        Security.Cryptography.CryptoStreamMode.Write)
    Dim btCipher As Byte()
    btCipher = Convert.FromBase64String(encryptetdPasswd_xps)
    cs_xpo.Write(btCipher, 0, btCipher.Length)
    cs_xpo.Close()
    Decrypt_password_fos = System.Text.Encoding.UTF8.GetString(ms_xpo.ToArray())
  End Function
  Private Sub Timer_pdferstellen_Tick(sender As Object, e As EventArgs)
    Generiere_pdf_fob()
  End Sub

End Class