Imports System.Data.SqlClient

Public Class startfenster_nycomed_frm
  Private filteraufheben_xpb As Boolean = False
  Private dummysaustauschen_xcb As Boolean = False

  'Damit l�schen der Filterangaben keine Ereignisse (cb_suchkrieterium) gefeuert Werden
  Private Sub Startfenster_nycomed_frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Dim i_xpi As Integer = 0
    ' Die Buttons kleiner gr�sser und schliessen werden deaktiviert
    Me.ControlBox = False
    'Belege Datagridview mit daten und blende unn�tige Zeile aus
    DataGridView1.DataSource = ds_chartprotmdb_xbo.Tables(0)

    DataGridView1.Columns(0).HeaderText = "Auftrags-Nr."
    DataGridView1.Columns(1).HeaderText = "Produktbezeichnung"
    DataGridView1.Columns(2).HeaderText = "Material-Nr."
    DataGridView1.Columns(3).HeaderText = "Chargen-Nr."
    DataGridView1.Columns(4).HeaderText = "Liniennummer (Tooltip)"
    DataGridView1.Columns(4).Width = 80
    DataGridView1.Columns(9).DefaultCellStyle.Format = "dd.MM.yyyy HH:mm:ss"
    DataGridView1.Columns(9).Width = 110
    DataGridView1.Columns(10).DefaultCellStyle.Format = "dd.MM.yyyy HH:mm:ss"
    DataGridView1.Columns(10).Width = 110
    If DataGridView1.Columns.Count > 18 Then
      'Vorbereitung f�r Isolator P150 hinzugef�gt
      DataGridView1.Columns(18).HeaderText = "Startzeit Setup"
      DataGridView1.Columns(18).DisplayIndex = 7
      DataGridView1.Columns(18).DefaultCellStyle.Format = "dd.MM.yyyy HH:mm:ss"
      DataGridView1.Columns(18).Width = 110
      DataGridView1.Columns(19).HeaderText = "Endzeit Setup"
      DataGridView1.Columns(19).DisplayIndex = 8
      DataGridView1.Columns(19).DefaultCellStyle.Format = "dd.MM.yyyy HH:mm:ss"
      DataGridView1.Columns(19).Width = 130
    End If
    '
    'Tooltip f�r die Linie definieren
    DataGridView1.Columns(4).ToolTipText = "1: E172;" 'f�r das Feld "Linie"

    For i_xpi = 4 To 8
      DataGridView1.Columns(i_xpi).Visible = False
    Next i_xpi

    DataGridView1.Columns(11).Visible = False
    'F�lle Suchfeld komboxen mit Tabelllen�berschriften
    For i_xpi = 0 To 19
      If i_xpi <> 4 And i_xpi <> 5 And i_xpi <> 6 And i_xpi <> 7 And i_xpi <> 8 And i_xpi <> 11 Then 'Messposition pz1 auswerten pz2 auswerten pz3 auswerten und produnktionstyp
        If i_xpi > 4 And i_xpi <= 17 Then
          Me.Cb_suchfeld1.Items.Add(ds_chartprotmdb_xbo.Tables(0).Columns(i_xpi).ColumnName.ToString)
          Me.Cb_suchfeld2.Items.Add(ds_chartprotmdb_xbo.Tables(0).Columns(i_xpi).ColumnName.ToString)
          Me.Cb_suchfeld3.Items.Add(ds_chartprotmdb_xbo.Tables(0).Columns(i_xpi).ColumnName.ToString)
          Me.Cb_suchfeld4.Items.Add(ds_chartprotmdb_xbo.Tables(0).Columns(i_xpi).ColumnName.ToString)
          Me.Cb_suchfeld5.Items.Add(ds_chartprotmdb_xbo.Tables(0).Columns(i_xpi).ColumnName.ToString)
        ElseIf i_xpi > 17 Then
          Me.Cb_suchfeld1.Items.Insert(i_xpi - 13, DataGridView1.Columns(i_xpi).HeaderText)
        Else
          Me.Cb_suchfeld1.Items.Add(DataGridView1.Columns(i_xpi).HeaderText)
          Me.Cb_suchfeld2.Items.Add(DataGridView1.Columns(i_xpi).HeaderText)
          Me.Cb_suchfeld3.Items.Add(DataGridView1.Columns(i_xpi).HeaderText)
          Me.Cb_suchfeld4.Items.Add(DataGridView1.Columns(i_xpi).HeaderText)
          Me.Cb_suchfeld5.Items.Add(DataGridView1.Columns(i_xpi).HeaderText)
        End If
      End If
    Next
    'Operatoren zum Verkn�pfen der Suchklriterien werden mit and vorbelegt
    Me.Cb_andor1.SelectedIndex = 0
    Me.Cb_andor2.SelectedIndex = 0
    Me.Cb_andor3.SelectedIndex = 0
    Me.Cb_andor4.SelectedIndex = 0
    Me.tb_app_version.Text = "Versionsnr. " & Application.ProductVersion.ToString


    If ds_chartprotmdb_xbo.Tables("Chargen").DefaultView.RowFilter = String.Empty Or ds_chartprotmdb_xbo.Tables("Chargen").DefaultView.RowFilter = "1=1" Then
    Else
      Me.lbl_gefiltert.Visible = True
    End If
  End Sub

  Private Sub Cmd_neu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_neu.Click
    'Neue charge anlegen
    neue_charge_xpb = True
    'Leere_Columns_wieder_auffuellen_sob()
    Me.Hide()
    Dim mdichild As New Frm_chrg_prot_detail With {
      .MdiParent = Me.MdiParent
    }
    mdichild.Show()
  End Sub

  Private Sub Cmd_detail_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_detail.Click
    'Zeige Chargendetails an
    If DataGridView1.RowCount = 0 Then
      MsgBox("Es sind noch keine Datens�tze in der Datenbank vorhanden.")
      Exit Sub
    End If
    neue_charge_xpb = False
    'Leere_Columns_wieder_auffuellen_sob()
    chargenname_xos = DataGridView1.Rows(DataGridView1.CurrentRow.Index).Cells(0).Value.ToString
    Me.Hide()
    Dim mdichild As New Frm_chrg_prot_detail With {
      .MdiParent = Me.MdiParent
    }
    mdichild.Show()
  End Sub

  Private Sub DataGridView1_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
    'Doppelclick auf das Datagrid �ffnet entsprechendes Chargendetail
    If DataGridView1.RowCount = 0 Then
      MsgBox("Es sind noch keine Datens�tze in der Datenbank vorhanden.")
      Exit Sub
    End If
    'Leere_Columns_wieder_auffuellen_sob()
    neue_charge_xpb = False
    chargenname_xos = DataGridView1.Rows(DataGridView1.CurrentRow.Index).Cells(0).Value.ToString
    chargennummer_xos = DataGridView1.Rows(DataGridView1.CurrentRow.Index).Cells(3).Value.ToString
    Me.Hide()
    Dim mdichild As New Frm_chrg_prot_detail With {
      .MdiParent = Me.MdiParent
    }
    mdichild.Show()
  End Sub

  Private Sub Cmd_filter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_filter.Click
    'Datens�tze des Dateagridviews filtern
    Dim dv As DataView = ds_chartprotmdb_xbo.Tables("Chargen").DefaultView
    Dim Rowfilter_xps As String = String.Empty
    Dim rueckgaberowfilter_xps As String = String.Empty
    Dim kriterumnummer_xpi As Integer = 0
    dv.RowFilter = Rowfilter_xps
    rueckgaberowfilter_xps = String.Empty
    If Rowfilter_zusammensetzen_fpi(Cb_suchfeld1, Cb_operator1, tb_suchkriterium1, 1, rueckgaberowfilter_xps) = 1 Then
      Rowfilter_xps = rueckgaberowfilter_xps
      rueckgaberowfilter_xps = String.Empty
      If Rowfilter_zusammensetzen_fpi(Cb_suchfeld2, Cb_operator2, tb_suchkriterium2, 2, rueckgaberowfilter_xps) = 1 Then
        If Me.Cb_andor1.SelectedIndex = -1 Then
          MsgBox("Der Verkn�pfungsoperator der Suchkriterien wurde nicht korrekt fetsgelegz, es wird auf AND gesetzt!", MsgBoxStyle.Critical)
          Me.Cb_andor1.SelectedIndex = 0
        End If
        Rowfilter_xps = Rowfilter_xps & " " & Me.Cb_andor1.SelectedItem.ToString & " " & rueckgaberowfilter_xps
      End If
      rueckgaberowfilter_xps = String.Empty
      If Rowfilter_zusammensetzen_fpi(Cb_suchfeld3, Cb_operator3, tb_suchkriterium3, 3, rueckgaberowfilter_xps) = 1 Then
        If Me.Cb_andor2.SelectedIndex = -1 Then
          MsgBox("Der Verkn�pfungsoperator der Suchkriterien wurde nicht korrekt fetsgelegz, es wird auf AND gesetzt!", MsgBoxStyle.Critical)
          Me.Cb_andor2.SelectedIndex = 0
        End If
        Rowfilter_xps = Rowfilter_xps & " " & Me.Cb_andor2.SelectedItem.ToString & " " & rueckgaberowfilter_xps
      End If
      rueckgaberowfilter_xps = String.Empty
      If Rowfilter_zusammensetzen_fpi(Cb_suchfeld4, Cb_operator4, tb_suchkriterium4, 4, rueckgaberowfilter_xps) = 1 Then
        If Me.Cb_andor3.SelectedIndex = -1 Then
          MsgBox("Der Verkn�pfungsoperator der Suchkriterien wurde nicht korrekt fetsgelegz, es wird auf AND gesetzt!", MsgBoxStyle.Critical)
          Me.Cb_andor3.SelectedIndex = 0
        End If
        Rowfilter_xps = Rowfilter_xps & " " & Me.Cb_andor3.SelectedItem.ToString & " " & rueckgaberowfilter_xps
      End If
      rueckgaberowfilter_xps = String.Empty
      If Rowfilter_zusammensetzen_fpi(Cb_suchfeld5, Cb_operator5, tb_suchkriterium5, 5, rueckgaberowfilter_xps) = 1 Then
        If Me.Cb_andor4.SelectedIndex = -1 Then
          MsgBox("Der Verkn�pfungsoperator der Suchkriterien wurde nicht korrekt fetsgelegz, es wird auf AND gesetzt!", MsgBoxStyle.Critical)
          Me.Cb_andor4.SelectedIndex = 0
        End If
        Rowfilter_xps = Rowfilter_xps & " " & Me.Cb_andor4.SelectedItem.ToString & " " & rueckgaberowfilter_xps
      End If
      dv.RowFilter = Rowfilter_xps
      Me.lbl_gefiltert.Visible = True
    End If
  End Sub

  Private Function Rowfilter_zusammensetzen_fpi(ByVal cb_suchfeld As ComboBox, ByVal cb_operator As ComboBox, ByVal tb_suchkriterium As TextBox, ByVal suchkriteriumsnummer_xpi As Integer, ByRef Rowfilter_xps As String) As Integer
    'Kontrolle auf Vollst�ndigkeit und Korrektheit der Eingabe, dann Filter suammensetzen
    Dim s_xps As String = String.Empty
    Dim s_xpb As Boolean = False
    Dim s_xpi As Integer = 0
    Dim s_xpBy As Byte = 0
    Dim s_xpd As Date
    Dim Datum_xps As String = String.Empty
    If (cb_suchfeld.SelectedIndex > -1) And (cb_operator.SelectedIndex > -1) And (tb_suchkriterium.Text <> String.Empty) Then
      'Alle Felder gef�llt, typ�berpr�fung und Filter zusammensetzen
      If ds_chartprotmdb_xbo.Tables("Chargen").Columns(cb_suchfeld.SelectedIndex).DataType Is s_xps.GetType Then
        Rowfilter_xps = cb_suchfeld.SelectedItem.ToString & " " & cb_operator.SelectedItem.ToString & " '*" & tb_suchkriterium.Text & "*'"
        Return 1
      ElseIf ds_chartprotmdb_xbo.Tables("Chargen").Columns(cb_suchfeld.SelectedIndex).DataType Is s_xpb.GetType Then
        If tb_suchkriterium.Text.ToUpper = "TRUE" Or tb_suchkriterium.Text.ToUpper = "FALSE" Then
          Rowfilter_xps = cb_suchfeld.SelectedItem.ToString & " " & cb_operator.SelectedItem.ToString & " " & tb_suchkriterium.Text
          Return 1
        Else
          MsgBox("Als Suchkriterium ist n�r TRUE oder FALSE erlaubt")
          tb_suchkriterium.Focus()
          Return 0
          Exit Function
        End If
      ElseIf ds_chartprotmdb_xbo.Tables("Chargen").Columns(cb_suchfeld.SelectedIndex).DataType Is s_xpd.GetType Then
        If IsDate(tb_suchkriterium.Text) = True Then
          Datum_xps = Format(CDate(tb_suchkriterium.Text), "MM")
          Datum_xps = Datum_xps & "/" & Format(CDate(tb_suchkriterium.Text), "dd")
          Datum_xps = Datum_xps & "/" & Format(CDate(tb_suchkriterium.Text), "yyyy")
          Datum_xps = Datum_xps & " " & Format(CDate(tb_suchkriterium.Text), "HH:mm:ss")
          Rowfilter_xps = cb_suchfeld.SelectedItem.ToString & " " & cb_operator.SelectedItem.ToString & " #" & Datum_xps & "#"
          Return 1
        Else
          MsgBox("Das Suchkriterium muss dem Format 01.01.2006 00:00:00 entsprechen!")
          tb_suchkriterium.Focus()
          Return 0
          Exit Function
        End If
      ElseIf ds_chartprotmdb_xbo.Tables("Chargen").Columns(cb_suchfeld.SelectedIndex).DataType Is s_xpi.GetType Then
        If IsNumeric(tb_suchkriterium.Text) = True Then
          Rowfilter_xps = cb_suchfeld.SelectedItem.ToString & " " & cb_operator.SelectedItem.ToString & " " & tb_suchkriterium.Text
          Return 1
        Else
          MsgBox("Das Suchkriterium muss numerisch sein")
          tb_suchkriterium.Focus()
          Return 0
          Exit Function
        End If
      ElseIf ds_chartprotmdb_xbo.Tables("Chargen").Columns(cb_suchfeld.SelectedIndex).DataType Is s_xpBy.GetType Then
        If IsNumeric(tb_suchkriterium.Text) = True And tb_suchkriterium.TextLength < 4 Then
          If CInt(tb_suchkriterium.Text) < 255 Then
            Rowfilter_xps = cb_suchfeld.SelectedItem.ToString & " " & cb_operator.SelectedItem.ToString & " " & tb_suchkriterium.Text
            Return 1
          Else
            MsgBox("Das Suchkriterium muss kleiner als 255 sein")
            tb_suchkriterium.Focus()
            Return 0
            Exit Function
          End If
        Else
          MsgBox("Das Suchkriterium muss numerisch und kleiner als 255 sein")
          tb_suchkriterium.Focus()
          Return 0
          Exit Function
        End If
      End If
    Else
      If suchkriteriumsnummer_xpi = 1 Then
        ' Das erste Sucgkriterium muss vollst�nbdig sein
        If cb_suchfeld.SelectedIndex = -1 Then
          MsgBox("Sie haben das erste Suchfeld nicht festgelegt!", MsgBoxStyle.Critical)
          cb_suchfeld.Focus()
          Return 0
          Exit Function
        End If
        If cb_operator.SelectedIndex = -1 Then
          MsgBox("Sie haben kein Vergleichsoperator f�r das erste Suchfilter festgelegt!", MsgBoxStyle.Critical)
          cb_operator.Focus()
          Return 0
          Exit Function
        End If
        If tb_suchkriterium.Text = String.Empty Then
          MsgBox("Sie haben kein Suchkriterium f�r den ersten Suchfilter festgelegt!", MsgBoxStyle.Critical)
          tb_suchkriterium.Focus()
          Return 0
          Exit Function
        End If
      Else
        If (cb_suchfeld.SelectedIndex > -1) Or (cb_operator.SelectedIndex > -1) Or (tb_suchkriterium.Text <> String.Empty) Then
          'Suchkriterium 2bis f�nf unvollst�ndig, meldung + l�schen
          MsgBox(" Das " & suchkriteriumsnummer_xpi & ".te Suchkriterium ist nicht vollst�ndug und wird daher nicht ber�cksichtigt!", MsgBoxStyle.Exclamation)
          filteraufheben_xpb = True
          cb_suchfeld.SelectedIndex = -1
          cb_operator.SelectedIndex = -1
          tb_suchkriterium.Text = String.Empty
          filteraufheben_xpb = False
        End If
        Return 0
      End If

      'Nicht komplett einzel�berpr�fen
    End If
  End Function

  Private Function Change_controls_fpi(ByRef cb_suchfeld As ComboBox, ByRef cb_operator As ComboBox, ByRef tb_suchkriterium As TextBox) As Integer
    ' Falls Suchfeld ausgew�hlt, wird abh�ngig vom Datentyp die weiterne Felder belegt
    Dim s_xps As String = String.Empty
    Dim s_xpb As Boolean = False
    Dim s_xpi As Integer = 0
    Dim s_xpBy As Byte = 0
    Dim s_xpd As Date
    cb_operator.Items.Clear()
    If ds_chartprotmdb_xbo.Tables("Chargen").Columns(cb_suchfeld.SelectedIndex).DataType Is s_xps.GetType Then
      cb_operator.Items.Add("LIKE")
      cb_operator.SelectedIndex = 0
      tb_suchkriterium.Text = String.Empty
    ElseIf ds_chartprotmdb_xbo.Tables("Chargen").Columns(cb_suchfeld.SelectedIndex).DataType Is s_xpb.GetType Then
      cb_operator.Items.Add("=")
      cb_operator.SelectedIndex = 0
      tb_suchkriterium.Text = "TRUE"
    ElseIf ds_chartprotmdb_xbo.Tables("Chargen").Columns(cb_suchfeld.SelectedIndex).DataType Is s_xpi.GetType Then
      cb_operator.Items.Add("=")
      cb_operator.Items.Add(">")
      cb_operator.Items.Add("<")
      cb_operator.SelectedIndex = 0
      tb_suchkriterium.Text = String.Empty
    ElseIf ds_chartprotmdb_xbo.Tables("Chargen").Columns(cb_suchfeld.SelectedIndex).DataType Is s_xpBy.GetType Then
      cb_operator.Items.Add("=")
      cb_operator.Items.Add(">")
      cb_operator.Items.Add("<")
      cb_operator.SelectedIndex = 0
      tb_suchkriterium.Text = String.Empty
    ElseIf ds_chartprotmdb_xbo.Tables("Chargen").Columns(cb_suchfeld.SelectedIndex).DataType Is s_xpd.GetType Then
      cb_operator.Items.Add("=")
      cb_operator.Items.Add(">")
      cb_operator.Items.Add("<")
      cb_operator.SelectedIndex = 0
      tb_suchkriterium.Text = Now.ToString
    End If
    Return 1
  End Function

  Private Sub Cb_suchfeld1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_suchfeld1.SelectedIndexChanged
    'Suchefeld1 wurde ge�ndert, passe Weitere Felder an
    If filteraufheben_xpb = False Then
      If Change_controls_fpi(Cb_suchfeld1, Cb_operator1, tb_suchkriterium1) = 1 Then
        'Elemente abge�ndert
      End If
    End If
  End Sub

  Private Sub Cb_suchfeld2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_suchfeld2.SelectedIndexChanged
    'Suchefeld2 wurde ge�ndert, passe Weitere Felder an
    If filteraufheben_xpb = False Then
      If Change_controls_fpi(Cb_suchfeld2, Cb_operator2, tb_suchkriterium2) = 1 Then
        'Elemente abge�ndert
      End If
    End If
  End Sub

  Private Sub Cb_suchfeld3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_suchfeld3.SelectedIndexChanged
    'Suchefeld3 wurde ge�ndert, passe Weitere Felder an
    If filteraufheben_xpb = False Then
      If Change_controls_fpi(Cb_suchfeld3, Cb_operator3, tb_suchkriterium3) = 1 Then
        'Elemente abge�ndert
      End If
    End If
  End Sub

  Private Sub Cb_suchfeld4_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_suchfeld4.SelectedIndexChanged
    'Suchefeld4 wurde ge�ndert, passe Weitere Felder an
    If filteraufheben_xpb = False Then
      If Change_controls_fpi(Cb_suchfeld4, Cb_operator4, tb_suchkriterium4) = 1 Then
        'Elemente abge�ndert
      End If
    End If
  End Sub

  Private Sub Cb_suchfeld5_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cb_suchfeld5.SelectedIndexChanged
    'Suchefeld5 wurde ge�ndert, passe Weitere Felder an
    If filteraufheben_xpb = False Then
      If Change_controls_fpi(Cb_suchfeld5, Cb_operator5, tb_suchkriterium5) = 1 Then
        'Elemente abge�ndert
      End If
    End If
  End Sub

  Private Sub Cmd_filter_aufheben_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_filter_aufheben.Click
    'Filter aufheben
    Dim dv As DataView = ds_chartprotmdb_xbo.Tables("Chargen").DefaultView
    dv.RowFilter = "1=1"
    filteraufheben_xpb = True
    Cb_suchfeld1.SelectedIndex = -1
    Cb_operator1.SelectedIndex = -1
    tb_suchkriterium1.Text = String.Empty
    Cb_suchfeld2.SelectedIndex = -1
    Cb_operator2.SelectedIndex = -1
    tb_suchkriterium2.Text = String.Empty
    Cb_suchfeld3.SelectedIndex = -1
    Cb_operator3.SelectedIndex = -1
    tb_suchkriterium3.Text = String.Empty
    Cb_suchfeld4.SelectedIndex = -1
    Cb_operator4.SelectedIndex = -1
    tb_suchkriterium4.Text = String.Empty
    Cb_suchfeld5.SelectedIndex = -1
    Cb_operator5.SelectedIndex = -1
    tb_suchkriterium5.Text = String.Empty
    Me.Cb_andor1.SelectedIndex = 0
    Me.Cb_andor2.SelectedIndex = 0
    Me.Cb_andor3.SelectedIndex = 0
    Me.Cb_andor4.SelectedIndex = 0
    filteraufheben_xpb = False
    Me.lbl_gefiltert.Visible = False
  End Sub

  Private Sub Cmd_close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_close.Click
    'Version 1.0.0.1 03.05.2006 da Costa
    'Beende Applikation
    Application.Exit()
  End Sub

  Private Sub Cmd_aktualisieren_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd_aktualisieren.Click
    'Version 1.0.0.1 03.05.2006 da Costa
    'Aktualisiere (manuel) Datenadapter, damit das Dataset wieder stimmig ist
    Me.Cursor = System.Windows.Forms.Cursors.WaitCursor
    Try
      ds_chartprotmdb_xbo.Tables("Chargen").Clear()
      Da_chartprot_xbo = New SqlDataAdapter("SELECT * FROM [Chargen];", cn_chargeprot_xbo) '[AuditTrail],[AuditTrail_Detail],,[Benutzer_AuditTrail],[LastDownload]
      Da_chartprot_xbo.Fill(ds_chartprotmdb_xbo, "Chargen")
      ds_chartprotmdb_xbo.Tables("AuditTrail").Clear()
      Da_audittrail_xbo = New SqlDataAdapter("SELECT * FROM [AuditTrail_Charge];", cn_chargeprot_xbo) ',[AuditTrail_Detail],,[Benutzer_AuditTrail],[LastDownload]
      Da_audittrail_xbo.Fill(ds_chartprotmdb_xbo, "AuditTrail")
      ds_chartprotmdb_xbo.Tables("AuditTrail_Detail").Clear()
      Da_audittrail_detail_xbo = New SqlDataAdapter("SELECT * FROM [AuditTrail_Detail];", cn_chargeprot_xbo) ',,,[Benutzer_AuditTrail],[LastDownload]
      Da_audittrail_detail_xbo.Fill(ds_chartprotmdb_xbo, "AuditTrail_Detail")
    Catch ex As Exception
      Me.Cursor = System.Windows.Forms.Cursors.Default
      MsgBox("Ein Fehler ist beim Schreiben auf die Datenbank aufgetreten." & vbCrLf & "Die Applikation wird beendet und es werden keine �nderungen �bernommen." & vbCrLf & "Bitte vermerken Sie das Problem im Kommentarfeld, wenn sie dei Charge erneut speichern.!", MsgBoxStyle.Critical)
      Fehlerupdate_xob = True
      Application.Exit()
    End Try
    Me.Cursor = System.Windows.Forms.Cursors.Default
  End Sub

  Private Sub Cmd_print_Click(sender As Object, e As EventArgs) Handles Cmd_print.Click
    'Report
    If DataGridView1.RowCount = 0 Then
      MsgBox("Es sind noch keine Datens�tze in der Datenbank vorhanden.", MsgBoxStyle.Exclamation, "Anwenderhinweis")
      Exit Sub
    End If
    'Leere_Columns_wieder_auffuellen_sob()
    chargenname_xos = DataGridView1.Rows(DataGridView1.CurrentRow.Index).Cells(0).Value.ToString
    chargennummer_xos = DataGridView1.Rows(DataGridView1.CurrentRow.Index).Cells(3).Value.ToString
    Dim Datum_xps As String = DataGridView1.Rows(DataGridView1.CurrentRow.Index).Cells(9).Value.ToString
    If Datum_xps = String.Empty Then
      MsgBox("Es wurde kein Startdatum festgelegt.", MsgBoxStyle.Exclamation, "Anwenderhinweis")
      Exit Sub
    End If
    Datum_xps = DataGridView1.Rows(DataGridView1.CurrentRow.Index).Cells(10).Value.ToString
    If Datum_xps = String.Empty Then
      MsgBox("Es wurde kein Enddatum festgelegt.", MsgBoxStyle.Exclamation, "Anwenderhinweis")
      Exit Sub
    End If
    Datum_xps = DataGridView1.Rows(DataGridView1.CurrentRow.Index).Cells(18).Value.ToString
    If Datum_xps = String.Empty Then
      MsgBox("Es wurde kein Startdatum Setup festgelegt.", MsgBoxStyle.Exclamation, "Anwenderhinweis")
      Exit Sub
    End If
    Datum_xps = DataGridView1.Rows(DataGridView1.CurrentRow.Index).Cells(19).Value.ToString
    If Datum_xps = String.Empty Then
      MsgBox("Es wurde kein Enddatum Setup festgelegt.", MsgBoxStyle.Exclamation, "Anwenderhinweis")
      Exit Sub
    End If
    aufruf_form_xos = "Startfenster"
    Me.Hide()
    Dim mdichild As New Frm_Print_Combit With {
      .MdiParent = Me.MdiParent
    }
    mdichild.Show()
  End Sub

  Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
    If DataGridView1.RowCount = 0 Then
      MsgBox("Es sind noch keine Datens�tze in der Datenbank vorhanden.")
      Exit Sub
    End If
    Me.Lb_Filelist.Items.Clear()
    If modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString() <> String.Empty Then
      If System.IO.Directory.Exists(modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString()) Then
        Dim verzeichnis_xps As String = String.Empty
        If modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString().EndsWith("\") Then
          verzeichnis_xps = modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString()
        Else
          verzeichnis_xps = modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString() & "\"
        End If
        Dim pdfDatei_xps As String = FileSystem.Dir(verzeichnis_xps & DataGridView1.Rows(DataGridView1.CurrentRow.Index).Cells(0).Value.ToString & "_" & "*.pdf")

        If pdfDatei_xps <> String.Empty Then

          Do While pdfDatei_xps <> String.Empty
            If (Strings.Left(pdfDatei_xps, pdfDatei_xps.Length - 24)) = DataGridView1.Rows(DataGridView1.CurrentRow.Index).Cells(0).Value.ToString Then
              Me.Lb_Filelist.Items.Add(pdfDatei_xps)
            End If
            pdfDatei_xps = Dir()
          Loop


        End If
      End If
    End If
  End Sub

  Private Sub Lb_Filelist_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Lb_Filelist.SelectedIndexChanged
    Try
      Dim verzeichnis_xps As String = String.Empty
      If modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString().EndsWith("\") Then
        verzeichnis_xps = modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString()
      Else
        verzeichnis_xps = modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("pdffilespath").ToString() & "\"
      End If
      Dim p As New System.Diagnostics.Process
      Dim s As New System.Diagnostics.ProcessStartInfo(verzeichnis_xps & Lb_Filelist.SelectedItems(0).ToString) With {
        .UseShellExecute = True,
        .WindowStyle = ProcessWindowStyle.Normal
      }
      p.StartInfo = s
      p.Start()

    Catch ex As Exception

    End Try
  End Sub
End Class