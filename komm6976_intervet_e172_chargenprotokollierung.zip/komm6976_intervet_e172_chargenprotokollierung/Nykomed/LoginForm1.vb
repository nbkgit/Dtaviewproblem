Imports System.DirectoryServices
Imports System.Collections
Public Class LoginForm1
    Private Fehlermeldung_xcs As String = String.Empty
    ' TODO: Code zum Durchführen der benutzerdefinierten Authentifizierung mithilfe des angegebenen Benutzernamens und des Kennworts hinzufügen 
    ' (Siehe http://go.microsoft.com/fwlink/?LinkId=35339).  
    ' Der benutzerdefinierte Prinzipal kann anschließend wie folgt an den Prinzipal des aktuellen Threads angefügt werden: 
    '     My.User.CurrentPrincipal = CustomPrincipal
    ' wobei CustomPrincipal die IPrincipal-Implementierung ist, die für die Durchführung der Authentifizierung verwendet wird. 
    ' Anschließend gibt My.User Identitätsinformationen zurück, die in das CustomPrincipal-Objekt eingekapselt sind,
  ' z.B. den Benutzernamen, den Anzeigenamen usw.


    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
    'Wenn ok geklickt wurde, selektiere den ausgewählten Daatensatz
    If VerifyLDAPUser(modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("LDAP_Server").ToString, Me.TB_Benutzer.Text, Me.PasswordTextBox.Text) Then
      Username_xos = TB_Benutzer.Text
      Rueckgabewert_userlogin_xoi = -1
      For i_xpi As Integer = 0 To Gruppenliste_xos.Length - 1
        If Trim(Gruppenliste_xos(i_xpi)) = Trim(modul_globalvar.ds_konfiguration.Tables("Applicationpaths").Rows(0).Item("ChrgProt_UserGroup").ToString) Then
          Rueckgabewert_userlogin_xoi = 2
        End If
      Next
      If Rueckgabewert_userlogin_xoi = -1 Then
        If MsgBox("Anmeldung fehlgeschlagen." & vbCrLf & Fehlermeldung_xcs & vbCrLf & "Wollen Sie im Testmodus weitermachen?", MsgBoxStyle.YesNo, "Anwenderhinweis") = MsgBoxResult.Yes Then
          Username_xos = "Unknown"
          If Dlg_passwort.ShowDialog = Windows.Forms.DialogResult.OK Then
            Rueckgabewert_userlogin_xoi = 1
          Else
            Rueckgabewert_userlogin_xoi = -1
          End If
        End If
      End If
    Else
      Dim textausgabe_xps As String = String.Empty
      If anonymous_xpi = 1 Then
        textausgabe_xps = "Anmeldung fehlgeschlagen." & vbCrLf & Fehlermeldung_xcs & vbCrLf & "Wollen Sie im Testmodus weitermachen?"
      Else
        Rueckgabewert_userlogin_xoi = -1
        MsgBox("Anmeldung fehlgeschlagen." & vbCrLf & Fehlermeldung_xcs, MsgBoxStyle.OkOnly, "Anwenderhinweis")
      End If

      If anonymous_xpi = 1 Then


        If MsgBox(textausgabe_xps, MsgBoxStyle.YesNo, "Anwenderhinweis") = MsgBoxResult.Yes Then
          Username_xos = "Unknown"
          If Dlg_passwort.ShowDialog = Windows.Forms.DialogResult.OK Then
            Rueckgabewert_userlogin_xoi = 1
          Else
            Rueckgabewert_userlogin_xoi = -1
          End If
        Else
          Rueckgabewert_userlogin_xoi = -1
        End If
      End If
    End If
    'Filter entfernen für userverwaltung
    Me.Close()
  End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
    'Es wurde Abbrechen Gedrückt
    Rueckgabewert_userlogin_xoi = -1
    Me.Close()
    End Sub


  Private Sub LoginForm1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    'TODO: Diese Codezeile lädt Daten in die Tabelle "ChrgProtDataSet.Benutzer". Sie können sie bei Bedarf verschieben oder entfernen.
    Rueckgabewert_userlogin_xoi = -1
    Username_xos = ""
  End Sub
   Public Function VerifyLDAPUser(ByVal Domaene_xps As String, ByVal user_xps As String, ByVal pwd_xps As String) As Boolean
  Dim userVerifiziert_xpb As Boolean = False


  Dim dEntry As System.DirectoryServices.DirectoryEntry = Nothing
  Dim nativeObject As Object = Nothing
  Dim result_xpo As System.DirectoryServices.SearchResult = Nothing
  Dim securePwd As System.Security.SecureString = Nothing 'Verschlüsseltes Passwort
  Dim pwdPtr As IntPtr = IntPtr.Zero  'Rückgabewert verschlüsseltes Passwort
  Dim Gruppenliste_xps As System.Collections.Generic.List(Of String) = New System.Collections.Generic.List(Of String) 'Arrays der zum User gehörenden Gruppennamen 
  Dim DebugMeldung_xps As String = String.Empty
  Try
    securePwd = New System.Security.SecureString()
    If pwd_xps IsNot Nothing AndAlso pwd_xps <> String.Empty Then
        For Each c As Char In pwd_xps
            securePwd.AppendChar(c)
        Next c
    End If 'pwd IsNot Nothing AndAlso pwd <> String.Empty
    securePwd.MakeReadOnly()
    pwdPtr = System.Runtime.InteropServices.Marshal.SecureStringToBSTR(securePwd)
    DebugMeldung_xps = "Anmeldung am LDAP Server"
    dEntry = New DirectoryServices.DirectoryEntry("LDAP://" & Domaene_xps, user_xps, System.Runtime.InteropServices.Marshal.PtrToStringBSTR(pwdPtr)) ',pwd)
    nativeObject = dEntry.NativeObject
    userVerifiziert_xpb = True
    'DebugMeldung_xps = "Suche vollständigen Namen"
    Dim searcher_Fullname_xpo As System.DirectoryServices.DirectorySearcher = New System.DirectoryServices.DirectorySearcher(dEntry)
    With searcher_Fullname_xpo
      .Filter = "(&(objectClass=User) (sAMAccountName=" & user_xps & "))"
      .PropertiesToLoad.Add("displayName")
    End With
    vollstaendigerName_xos = String.Empty
    result_xpo = searcher_Fullname_xpo.FindOne
    If result_xpo.Properties("displayName").Count > 0 Then
      If result_xpo.Properties("displayName")(0) IsNot Nothing Then
        vollstaendigerName_xos = result_xpo.Properties("displayName")(0).ToString().Trim()
      End If
    End If
    'DebugMeldung_xps = "Suche Gruppen"
    Dim searcher_Gruppen_xpo As System.DirectoryServices.DirectorySearcher = New System.DirectoryServices.DirectorySearcher(dEntry)
    With searcher_Gruppen_xpo
      .Filter = "(&(objectClass=User) (sAMAccountName=" & user_xps & "))"
      .PropertiesToLoad.Add("MemberOf")
    End With

    result_xpo = searcher_Gruppen_xpo.FindOne
    Dim propertyCount_xpi As Integer = result_xpo.Properties("MemberOf").Count
    Dim dn As String = String.Empty
    Dim equalsIndex_xpi As Integer = 0, commaIndex_Xpi As Integer = 0
    For propertyCounter_xpi As Integer = 0 To propertyCount_xpi - 1
      dn = CType(result_xpo.Properties("MemberOf")(propertyCounter_xpi), String)

      equalsIndex_xpi = dn.IndexOf("=", 1)
      commaIndex_Xpi = dn.IndexOf(",", 1)
      If (equalsIndex_xpi = -1) Then
        Return Nothing
      End If

      Gruppenliste_xps.Add(dn.Substring((equalsIndex_xpi + 1), (commaIndex_Xpi - equalsIndex_xpi) - 1))
      If Gruppenliste_xps IsNot Nothing AndAlso Gruppenliste_xps.Count > 0 Then Gruppenliste_xos = Gruppenliste_xps.ToArray()
    Next
    Fehlermeldung_xcs = String.Empty
  Catch ex As System.Exception
    userVerifiziert_xpb = False
    Fehlermeldung_xcs = "Fehlermeldung: " & ex.Message
  End Try

  Return userVerifiziert_xpb
End Function
End Class
